# 📥 00_Raw - 사용자 원시 데이터 유입창구 (Source of Truth)

## 📌 개요
`00_Raw/`는 사용자가 전달하는 모든 비구조화된 원시 메모, 논문 발췌문, 실험 노트, 아이디어 스케치가 저장되는 **불변(Immutable) 보관소**입니다.

## 📂 폴더 구조 규칙
- 날짜별 폴더: `00_Raw/YYYY-MM-DD/` (예: `00_Raw/2026-10-08/`)
- 사용자가 원시 메모 파일(`raw_note.md` 또는 텍스트)을 이 폴더에 투입하면, **P-Reinforce 자율 정원사(The Autonomous Gardener)**가 자동으로 읽어 들입니다.

## 🔄 처리 워크플로우
1. **수집(Ingestion)**: `00_Raw/` 내의 신규 원시 문서를 감지
2. **분류(Classification)**: 의미론적 코사인 유사도($\ge 85\%$) 및 상위 개념 도출
3. **지식 합성(Synthesis)**: Karpathy 영속적 위키 템플릿(한 줄 통찰, 구조화된 지식, 모순/업데이트, 양방향 링크)으로 정제하여 `10_Wiki/` 내 적절한 폴더에 배치
4. **그래프 갱신(Graph Update)**: `20_Meta/Graph.json` 및 `20_Meta/Index.md` 동기화
5. **정책 갱신(Policy Update)**: 보상 계산 및 `20_Meta/Policy.md` 기록
6. **버전 관리(Git Sync)**: `git add .` $\to$ `git commit -m "[P-Reinforce] ..."` $\to$ 타임라인 보존

---
*Created by P-Reinforce Engine on 2026-10-08*
