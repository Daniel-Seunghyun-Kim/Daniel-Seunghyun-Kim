# [[PC1_및_PC2_하드웨어_클러스터_시뮬레이션_배치_및_스웜_실행_로드맵]]

## 📌 Brief Summary
본 문서는 노트북(마스터 오케스트레이터), PC1(RTX 4070 Ti 워크스테이션), 그리고 PC2(Dual RTX 4090 / 128GB RAM 초고사양 클러스터)를 결합하여 **DFT, 대규모 LAMMPS NEMD, ShengBTE, Elmer FEM, OpenFOAM, 3D FNO를 분산 무인 자동화로 연동 구동하기 위한 하드웨어 환경 세팅, Docker/WSL2 컨테이너 파이프라인, 그리고 멀티 노드 스웜(Swarm) 실행 프로토콜**을 완비한 실무 엔지니어링 로드맵입니다.

---

## 🏛️ 1. 3단계 하드웨어 노드 역할 분담 아키텍처

```
  [노트북 (Laptop): Master Controller]
    - 사용자 인터페이스, 논문 작성, 연구 계획 수립
    - 작업 큐(Job Queue) 분배 (SSH / Celery) 및 GPR 액티브러닝 서브스크리닝
              │
              ├────────────────────────────────────────┐
              ▼                                        ▼
  [PC1 노드: Standard Simulation Engine]     [PC2 노드: Heavy Multi-GPU Cluster]
  - CPU: 16C/32T / RAM: 32~64GB              - CPU: 32C/64T / RAM: 128GB 이상
  - GPU: RTX 4070 Ti (12GB)                  - GPU: Dual RTX 4090 (24GB x 2 = 48GB)
  - 담당:                                    - 담당:
    1. Quantum ESPRESSO DFT 원시셀 완화        1. LAMMPS 백만 원자 Kokkos 대규모 NEMD
    2. ShengBTE 3-포논 산란율 산출             2. DeepMD 머신러닝 포텐셜 분산 훈련
    3. Elmer FEM 3D 단위셀 열-응력            3. 1,000만 노드 풀 다이 OpenFOAM CHT
    4. PyTorch 단일 GPU PINN 학습              4. 48GB VRAM 대규모 3D FNO 텐서 학습
```

---

## 💻 2. 노드별 환경 세팅 및 실행 명령어 가이드

### 2.1 PC1 노드 (RTX 4070 Ti) 작업 구동 가이드
- **설치 환경**: Windows 11 + WSL2 Ubuntu 22.04 LTS (NVIDIA 드라이버 + CUDA 12.x)
- **1) Quantum ESPRESSO 16스레드 MPI 병렬 실행**:
  ```bash
  # WSL Ubuntu 환경
  export OMP_NUM_THREADS=1
  mpirun -np 16 pw.x -nk 4 -in AlN_vc_relax.in > AlN_vc_relax.out
  ```
- **2) Elmer FEM 3D 멀티피직스 실행**:
  ```bash
  ElmerGrid 14 2 cu_aln_mesh.msh -autoclean
  ElmerSolver case.sif
  ```
- **3) PC1 스웜 데몬 런치 (백그라운드 자동 수신)**:
  ```powershell
  # Windows PowerShell (관리자)
  powershell -ExecutionPolicy Bypass -File D:\AlN_Simulation_Core\start_swarm_daemon.ps1
  ```

---

### 2.2 PC2 노드 (Dual RTX 4090 / 128GB) 대규모 클러스터 구동 가이드
- **설치 환경**: Ubuntu Server 22.04 Native 권장 (또는 전용 고성능 WSL2), NVIDIA Container Toolkit, NCCL.

#### 1) LAMMPS 백만 원자 대규모 NEMD (Dual 4090 Kokkos 가속)
```bash
# 2개 GPU 모두 활성화 (GPU당 CUDA 코어 16,384개 풀가동)
export CUDA_VISIBLE_DEVICES=0,1

mpirun -np 2 lmp -k on g 2 -sf kk -in in.cu_aln_nemd_1M_atoms \
  -pk kokkos neigh half comm device binsize 2.8
```
- `-k on g 2`: Kokkos 라이브러리를 통해 2개의 RTX 4090 GPU를 직접 할당.
- `-sf kk`: 모든 연산(Force, Neighbor list, Time integration)을 Kokkos GPU 커널로 오프로딩.
- **성능**: 100만 개 원자 시스템을 **하루에 $35\,\text{ns}$ 이상 고속 적분**.

#### 2) DeepMD-kit 멀티 GPU 분산 훈련 (DDP)
```bash
# PyTorch Horovod / DDP 기반 Dual 4090 병렬 학습
horovodrun -np 2 -H localhost:2 dp train input.json
```
- 배치 사이즈를 4배로 확장하여 학습 시간을 1/4로 단축($< 2$시간 내 수렴).

#### 3) OpenFOAM 32코어 MPI 병렬 켤레 열전달 (1,000만 노드)
```bash
decomposePar -case ./full_chip_microchannel
mpirun -np 32 chtMultiRegionFoam -parallel -case ./full_chip_microchannel > log.cht &
```

#### 4) 3D Fourier Neural Operator (FNO) 48GB VRAM 훈련
```bash
python -m torch.distributed.launch --nproc_per_node=2 train_3d_fno.py \
  --batch_size 16 --resolution 128x128x64 --modes 16
```

---

## 🔄 3. 노트북 $\leftrightarrow$ PC1 $\leftrightarrow$ PC2 무인 자동화 연동 파이프라인

```
  [1. 노트북: 파라미터 생성]
      DOE 직교배열 생성 (Python GPR Active Learning)
        │
        ▼ (SSH / SCP 자동 전송)
  [2. PC1: 전처리 & DFT/BTE]
      - QE로 완화 구조 및 2차/3차 힘상수 추출
      - ShengBTE로 박막 k(t) 계산
        │
        ▼ (고정밀 결함 및 계면 데이터 전송)
  [3. PC2: 대규모 멀티 GPU 연산]
      - Dual 4090으로 백만 원자 LAMMPS NEMD 계면 TBR 산출
      - 3D 전신 Elmer FEM 및 OpenFOAM 초정밀 유동장 연성 해석
      - 3D FNO 대리 모델 가중치 훈련
        │
        ▼ (결과 텐서 및 CSV 축소 전송)
  [4. 노트북: 최종 분석 및 논문 시각화]
      - 디지털 트윈 대시보드 업데이트 & 논문 수록 그래프 출력
```

---

## 🔗 Knowledge Connections
- [[반도체_열관리_및_공정_전체_시뮬레이션_포트폴리오_총람 (All Simulation Portfolio)]] : 전체 포트폴리오 마스터
- [[제1원리_DFT_전자구조_및_포논_시뮬레이션_가이드 (DFT & Phonon QE VASP)]] : PC1 담당 DFT 가이드
- [[분자동역학_MD_계면_TBR_및_머신러닝포텐셜_시뮬레이션 (LAMMPS & DeepMD)]] : PC2 담당 LAMMPS Kokkos 가이드
- [[연속체_3D_FEM_열응력_및_CFD_미세유체_시뮬레이션 (Elmer FEM & OpenFOAM)]] : PC1/PC2 담당 FEM/CFD 가이드
- [[2단계_PC1_스웜데몬_런치_및_실행가이드]] : PC1 단독 스웜 데몬 가이드

*Last updated: 2026-10-07*
