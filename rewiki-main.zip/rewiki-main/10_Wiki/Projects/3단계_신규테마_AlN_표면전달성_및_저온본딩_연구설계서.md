# [[3단계_신규테마_AlN_표면전달성_및_저온본딩_연구설계서]]

## 📌 Brief Summary
본 연구설계서는 3단계 작업으로, 2026년 10월 2일자 선행문헌 검토록(`D:\New_Theme\RESEARCH_REVIEW_20261002.md`)에서 도출된 최상위 5대 벤치마크 논문(S10 Perez, S11 Nieminen, S12 Tuchman, S13 Singh, Huang 2026)을 기반으로 수립한 **"AlN 하부막 $\rightarrow$ 상부 금속 표면 조도 $\rightarrow$ 저온 직접 접합(Al-Al, Cu-Cu) 품질 전달관계 및 계면 열저항 식별성 규명"** 신규 연구 테마 기획서입니다.

---

## 🎯 1. 연구 배경 및 핵심 가설 (Hypothesis Formulation)

```
[AlN 하부 버퍼층] ──(결정성/조도 전이)──► [상부 Al/Cu 박막 표면] ──(Ar 플라즈마 활성화)──► [저온 직접 접합 & 계면 TBC]
 (두께 50~200 nm)                             (RMS < 2.5 nm)                             (접합률 >99%, TBR 최소화)
```

### 💡 핵심 과학적 가설 (3대 가설)
1. **가설 1 (성장-표면 전달관계 / Transfer Function):**
   - 하부 AlN 박막의 두께($50 \sim 200\,\text{nm}$) 및 스퍼터 결정 배향($c$축 배향도)이 상부 증착되는 Al 또는 Cu 금속 박막의 결정립 크기(Grain size)와 표면 거칠기(RMS Roughness)를 직접적으로 결정짓는다.
2. **가설 2 (물리적 활성화 메커니즘 / Ar vs O₂ Plasma):**
   - $\text{O}_2$ 플라즈마가 화학적 산화 피막을 형성하여 접합 강도를 저해하는 것과 달리, **Ar 플라즈마 물리적 이온 충격**은 금속 표면 조도를 $12\,\text{nm} \to 2.85\,\text{nm}$ 이하로 평탄화하고 자연산화막을 제거하여 $300^\circ\text{C}$ 이하 저온 직접 접합 면적률을 **$>99\%$**로 극대화한다.
3. **가설 3 (계면 열저항 vs 박막 체적 저항 식별성 / TBC Resolution):**
   - $100\,\text{nm}$ 이하 초박막 영역에서는 AlN 자체의 박막 열전도도($k \approx 18.7\,\text{W/mK}$)보다 접합 계면의 TBC($G_{\text{bonded}} \approx 100\,\text{MW/m}^2\text{K}$)가 전체 열저항의 $85\%$ 이상을 지배하므로, 접합면 거칠기 개선이 패키지 전체의 방열 병목을 해소하는 결정적 변수가 된다.

---

## 🔬 2. 실험 계획 및 직교 배열 매트릭스 (DOE Matrix)

| 시료 군 (Group) | AlN 하부막 두께 | 상부 금속층 (100 nm) | 표면 활성화 조건 | 본딩 온도 / 압력 | 핵심 분석 및 측정 항목 |
| :---: | :---: | :---: | :---: | :---: | :--- |
| **Group A (Al 계열)** | $50\,\text{nm}$<br>$100\,\text{nm}$<br>$200\,\text{nm}$ | **Al 박막**<br>(스퍼터 증착) | • Non-treated<br>• Ar plasma (물리 활성화)<br>• $\text{O}_2$ plasma (화학 활성화) | $200^\circ\text{C}$ / $1\,\text{MPa}$<br>$250^\circ\text{C}$ / $1\,\text{MPa}$<br>$300^\circ\text{C}$ / $1\,\text{MPa}$ | 1. **AFM:** 증착 직후 및 플라즈마 후 표면 거칠기 ($R_q$)<br>2. **XPS:** 금속 표면 산화막 잔류 두께<br>3. **C-SAM:** 접합 후 보이드(Void) 면적률<br>4. **Die Shear:** 접합 전단 강도 ($>15\,\text{MPa}$ 목표)<br>5. **TDTR:** 접합 계면 열전도도 ($G_{\text{bonded}}$ 추출) |
| **Group B (Cu 계열)** | $50\,\text{nm}$<br>$100\,\text{nm}$<br>$200\,\text{nm}$ | **Cu 박막**<br>(Ti seed 10 nm) | 동일 조건 비교 | $250^\circ\text{C}$ / $5\,\text{MPa}$<br>$300^\circ\text{C}$ / $5\,\text{MPa}$ |

---

## 💻 3. BSPDN (후면 전력공급망) 3D FEM 시뮬레이션 연계

- **목표:** IBM Research(Singh et al., IITC 2025) 모델을 벤치마크하여, 초박형 후면 전력 공급망에서 AlN 접합 라이너의 열적 이점 정량화.
- **해석 모델:**
  - 하부 Si 파워 레일 $\rightarrow$ AlN/Al접합층 ($50 \sim 200\,\text{nm}$) $\rightarrow$ 상부 활성 로직 소자 핫스팟 ($10\,\text{MW/m}^2$).
  - 비교 대상: 표준 $\text{SiO}_2$ 본딩 vs AlN 직접 본딩 vs AlN+Cap 본딩.
- **도출 데이터:** 소자 접션 온도($T_j$) 감소폭, 유효 열저항 $R_{\text{th}}$, 열팽창 응력 텐서.

---

## 📅 4. 신규 테마 추진 로드맵

```mermaid
gantt
    title AlN 표면전달성 및 저온 직접접합 신규 테마 실행 일정
    dateFormat  YYYY-MM
    section 실험 준비 및 증착
    AlN 두께별 박막 증착 및 AFM 표면 조도 분석 :2026-10, 2026-11
    Ar/O2 플라즈마 활성화 조건 최적화          :2026-11, 2026-12
    section 접합 및 특성 평가
    저온 직접 접합 (200~300°C) 및 SAM 보이드 분석 :2026-12, 2027-01
    TDTR 계면 열전도도 측정 및 역피팅           :2027-01, 2027-02
    section 논문 작성
    BSPDN 3D FEM 시뮬레이션 결과 결합 및 투고    :2027-02, 2027-03
```

---
*Last updated: 2026-10-07*
