# [[포논_BTE_및_메조스케일_열수송_몬테카를로_시뮬레이션 (ShengBTE & OpenBTE)]]

## 📌 Brief Summary
본 문서는 서브 마이크론 및 나노 박막(AlN 두께 $10\text{--}500\,\text{nm}$)에서 발생하는 경계 산란(Boundary Scattering)과 포논 평균자유행로(MFP) 누적 스펙트럼, 그리고 두께 의존 유효 열전도도 $k(t)$를 계산하기 위한 **포논 볼츠만 수송 방정식(BTE) 수치해석, ShengBTE 및 OpenBTE 툴체인, 그리고 PC1 vs PC2 하드웨어 스케일링**을 다룬 전문 지식 노트입니다.

---

## 🔬 1. BTE 열수송 지배 방정식과 수치해석 해법

포논 볼츠만 수송 방정식 (Phonon Boltzmann Transport Equation):
$$\mathbf{v}_g(\lambda) \cdot \nabla f_\lambda = \left( \frac{\partial f_\lambda}{\partial t} \right)_{scatt}$$

```
  [이완시간 근사 (RTA: Relaxation Time Approximation)]
  우변 산란항: (∂f/∂t)_scatt ≈ - (f_λ - f_0) / τ_λ
  열전도도 텐서: k_αβ = (1/V) ∑_λ C_λ v_α(λ) v_β(λ) τ_λ
               │
               ▼ (AlN 같은 고열전도체에서는 RTA가 10~20% 과소평가)
  [완전 반복 수치해법 (Full Iterative Solution)]
  정상 산란(Normal process)과 역전 산란(Umklapp process)을 구분하여 자기일관적 행렬 수렴
```

---

## 💻 2. 대표 BTE 시뮬레이션 툴체인 비교

1. **ShengBTE**:
   - DFT에서 도출된 2차 및 3차 원자간 힘상수(IFC)를 직접 입력받아 RTA 및 Iterative 해법으로 벌크 및 박막의 열전도도를 해석.
   - 포논 누적 열전도도 $k_{accum}(\Lambda)$ 스펙트럼 출력 $\to$ 방열에 기여하는 주요 포논 파장대 분석.
2. **OpenBTE**:
   - BTE를 임의의 2D/3D 형상 메쉬(Gmsh)에 대해 유한체적법(FVM) 또는 유한요소법(FEM)으로 이산화하여 해석.
   - **Cu@AlN 코어-쉘 나노와이어**나 다공성 나노구조체에서 기하학적 형상 효과(Geometric Confinement)에 의한 탄도 포논 억제 효과 해석에 최적.
3. **almaBTE**:
   - 초격자(Superlattice) 및 복합 다층 박막 계면에서의 포논 투과/반사 연동 BTE 해석 지원.

---

## ⚙️ 3. PC1 vs PC2 하드웨어 연산 도약 정량 비교

BTE 연산은 수만 개의 q-포인트 간 3-포논 산란 위상 공간(Phase Space) 적분을 수행하므로 **고용량 메모리(RAM)와 CPU 부동소수점 병렬 연산(AVX-512, OpenMP/MPI)**이 지배적입니다.

| 평가 항목 | PC1 워크스테이션 (32GB RAM / 16C) | PC2 클러스터 (128GB RAM / 32C+) |
| :--- | :--- | :--- |
| **브릴루앙 영역 q-mesh** | $16\times 16\times 12$ 표준 그리드 | **$32\times 32\times 24$ 초정밀 그리드 (수렴도 99.9%)** |
| **BTE 해법** | RTA 근사 위주 (Iterative는 메모리 한계) | **Full Iterative 자기일관 반복 수치해 완주** |
| **박막 두께 범위 해석** | $50\text{--}500\,\text{nm}$ 단일 축 박막 | **$5\text{--}1,000\,\text{nm}$ 전 범위 + 비등방 2D 박막** |
| **OpenBTE 3D 메쉬 셀수** | $\sim 50,000$ 노드 | **$\sim 500,000$ 노드 (Cu@AlN 나노와이어 3D 전신)** |
| **소요 시간 (Iterative)** | $6\sim 12$ 시간 (스왑 메모리 병목) | **$< 1.5$ 시간 (순수 RAM 내 초고속 병렬)** |

---

## 📝 4. ShengBTE 제어 파일 (CONTROL) 핵심 템플릿

```fortran
&allocations
    nelements = 2
    natoms    = 4
    ngrid(:)  = 24 24 18     ! PC1/PC2 q-point 그리드
/
&crystal
    lfactor   = 0.1          ! 나노미터 단위 변환
    lattvec(:,1) = 3.111  0.000  0.000
    lattvec(:,2) = -1.555 2.694  0.000
    lattvec(:,3) = 0.000  0.000  4.980
    elements  = 'Al' 'N'
    types     = 1 1 2 2
    positions(:,1) = 0.333333 0.666667 0.000000
    ...
/
&parameters
    T         = 300.0        ! 상온 300 K
    scaleint  = 1.0
/
&flags
    nonanalytic = .TRUE.     ! 광학 포논 LO-TO 분열 반영 (중요)
    isotopes    = .TRUE.     ! 동위원소 산란 반영
    onlyread    = .FALSE.
/
```

---

## 🔗 Knowledge Connections
- [[반도체_열관리_및_공정_전체_시뮬레이션_포트폴리오_총람 (All Simulation Portfolio)]] : 전체 포트폴리오
- [[제1원리_DFT_전자구조_및_포논_시뮬레이션_가이드 (DFT & Phonon QE VASP)]] : ShengBTE의 필수 입력 힘상수(IFC) 제공
- [[크누센 수와 탄도 열수송 (Knudsen Number & Ballistic Transport)]] : BTE 해석의 핵심 물리인 탄도 포논 수송
- [[Wurtzite AlN 결정성 및 포논 수송 메커니즘]] : AlN 포논 분산 이론

*Last updated: 2026-10-07*
