# [[연속체_3D_FEM_열응력_및_CFD_미세유체_시뮬레이션 (Elmer FEM & OpenFOAM)]]

## 📌 Brief Summary
본 문서는 3D 적층 하이브리드 본딩 패키지, Cu@AlN 코어-쉘 수직 인터커넥트 어레이, 온칩 마이크로채널 냉각판의 거시적 물리 거동을 규명하기 위한 **오픈소스 유한요소(Elmer FEM) 열-응력 연성 해석, 전산유체역학(OpenFOAM) 켤레열전달(CHT) 및 이상유동(VOF) 시뮬레이션 기법, 그리고 PC1 vs PC2 하드웨어 스케일링**을 다룬 전문 지식 노트입니다.

---

## 🏛️ 1. 멀티피직스 연속체 해석의 목적 및 지배 방정식

```
  [열전도 방정식 (Elmer FEM HeatSolver)]
  ρ c_p (∂T/∂t) = ∇ · (k(T) ∇T) + Q_active
        │
        ▼ (열팽창 미스매치 ΔCTE에 의한 열응력 연성)
  [열탄소성 구조방정식 (Elmer FEM StressAnalysis)]
  ∇ · σ = 0,   σ = D : (ε - α ΔT - ε_plastic)
        │
        ▼ (외부 냉각수 대류 경계조건 결합)
  [켤레 열전달 CHT (OpenFOAM chtMultiRegionFoam)]
  고체 계면 연속성: T_solid = T_fluid,   -k_s (∂T_s/∂n) = -k_f (∂T_f/∂n)
```

---

## ⚙️ 2. PC1 vs PC2 하드웨어 연산 도약 정량 비교

유한요소(FEM) 및 유한체적(CFD) 메쉬 연산은 대규모 희소 행렬(Sparse Matrix) 솔버(BiCGStab, MUMPS, GAMG)를 구동하므로 **메모리 대역폭과 RAM 용량**이 해석 가능 모델의 크기를 결정합니다.

| 평가 항목 | PC1 워크스테이션 (32GB RAM / 16C) | PC2 클러스터 (128GB RAM / 32C+ / Dual 4090) |
| :--- | :--- | :--- |
| **최대 메쉬 요소수 (Mesh Elements)** | $\sim 300,000 \text{--} 500,000$ 노드 | **$10,000,000$ 노드 이상 (1천만 개 초대형 메쉬)** |
| **해석 지오메트리 범위** | 단일 단위 셀 ($1\times 1$ 또는 $2\times 2$ 범프) | **실제 3D 칩 전체 ($100\times 100$ 범프 어레이 풀 다이)** |
| **열-응력 연성 비선형 수렴** | 선형 탄성 위주 (소성 해석 시 메모리 부족) | **Cu 소성 변형 및 AlN 계면 박리 비선형 접촉 해석** |
| **CFD 이상유동 (Two-Phase VOF)** | 2D 평면 또는 조대 메쉬 한정 | **3D 마이크로채널 기포 핵생성 및 슬러그 비등 과도 해석** |
| **해석 소요 시간** | 과도 해석 1회당 수 시간~반나절 | **MPI 32코어 병렬화로 $20\sim 40$분 내 초고속 완료** |

---

## 📝 3. Elmer FEM 솔버 제어 파일 (case.sif) 핵심 템플릿

Cu@AlN 코어쉘 구조의 줄열 발열 및 3D 열전도 해석을 위한 Elmer SIF 구성입니다:

```fortran
Header
  CHECK KEYWORDS Warn
  Mesh DB "." "cu_aln_mesh"
  Include Path ""
  Results Directory "results"
End

Simulation
  Max Output Level = 5
  Coordinate System = Cartesian
  Coordinate Mapping(3) = 1 2 3
  Simulation Type = Steady State
  Steady State Max Iterations = 1
  Output Intervals = 1
End

Constants
  Stefan Boltzmann = 5.670374e-08
End

Body 1
  Target Bodies(1) = 1    ! Cu Core
  Name = "Cu_Core"
  Equation = 1
  Material = 1
  Body Force = 1          ! Joule Heating
End

Body 2
  Target Bodies(1) = 2    ! AlN Shell
  Name = "AlN_Shell"
  Equation = 1
  Material = 2
End

Material 1
  Name = "Copper"
  Heat Conductivity = 398.0
  Density = 8960.0
  Heat Capacity = 385.0
End

Material 2
  Name = "AlN_ThinFilm"
  Heat Conductivity = 35.0  ! BTE 산출 두께 유효 k(t)
  Density = 3260.0
  Heat Capacity = 740.0
End

Body Force 1
  Name = "JouleHeatingSource"
  Heat Source = 1.0e11     ! 10^11 W/m^3 초고열유속
End

Equation 1
  Name = "Heat_Conduction"
  Active Solvers(1) = 1
End

Solver 1
  Equation = Heat Equation
  Procedure = "HeatSolve" "HeatSolver"
  Variable = Temperature
  Exec Solver = Always
  Linear System Solver = Iterative
  Linear System Iterative Method = BiCGStab
  Linear System Max Iterations = 500
  Linear System Convergence Tolerance = 1.0e-08
  Linear System Preconditioning = ILU1
  Steady State Convergence Tolerance = 1.0e-06
End

Boundary Condition 1
  Target Boundaries(1) = 1  ! Bottom Substrate
  Name = "HeatSinkBoundary"
  Temperature = 300.0       ! 300 K 방열판 경계
End
```

---

## 🔗 Knowledge Connections
- [[반도체_열관리_및_공정_전체_시뮬레이션_포트폴리오_총람 (All Simulation Portfolio)]] : 전체 포트폴리오
- [[포논_BTE_및_메조스케일_열수송_몬테카를로_시뮬레이션 (ShengBTE & OpenBTE)]] : BTE 산출 $k(t)$를 FEM 물성에 입력
- [[미세유체역학 및 반도체 마이크로채널 냉각 (Microfluidics & On-Chip Microchannels)]] : OpenFOAM CHT 쿨링 해석
- [[상변화 열전달과 증기챔버 및 비등 냉각 (Two-Phase Heat Transfer, Vapor Chamber & Boiling)]] : OpenFOAM VOF 비등 모델

*Last updated: 2026-10-07*
