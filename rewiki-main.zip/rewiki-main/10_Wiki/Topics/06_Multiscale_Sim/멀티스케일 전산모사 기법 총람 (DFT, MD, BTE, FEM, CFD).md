# [[멀티스케일 전산모사 기법 총람 (DFT, MD, BTE, FEM, CFD)]]

## 📌 Brief Summary
본 문서는 반도체 소자의 양자 격자 진동(0.1 nm)부터 3D 패키지 및 냉각 시스템(10 cm)에 이르는 **5단계 멀티스케일 전산모사(DFT $\to$ MD $\to$ BTE $\to$ FEM $\to$ CFD)의 지배 방정식, 수치해석 알고리즘, 대표 오픈소스/상용 툴체인, 그리고 스케일 간 파라미터 전달 핸드셰이크(Handshake)**를 정밀 정리한 기술 지식 노트입니다.

---

## 🔬 1. 스케일별 전산모사 기법 심층 분석

```
  [0.1 nm ~ 1 nm]    제1원리 전자구조 (DFT / DFPT)  ──► 포논 분산, 3차 힘상수 (IFC)
         │
  [1 nm ~ 50 nm]     분자동역학 (MD / NEMD)         ──► 계면 열경계저항 (TBR / Kapitza)
         │
  [50 nm ~ 10 μm]    포논 볼츠만 수송 (BTE)         ──► 두께별 박막 유효 열전도도 k(t)
         │
  [10 μm ~ 10 mm]    유한요소 열-응력 (FEM)         ──► 3D 칩 열확산, 패키지 휨/열응력
         │
  [1 mm ~ 100 mm]    전산유체역학 (CFD / CHT)       ──► 마이크로채널, 2상 비등, 냉각판
```

---

### 1.1 제1원리 전자구조 계산: DFT (Density Functional Theory)
- **공간 스케일**: $0.1 \sim 1\,\text{nm}$ (원자 수십~수백 개)
- **지배 원리**: Kohn-Sham 방정식 및 밀도범함수 섭동이론(DFPT)
  $$\left( -\frac{\hbar^2}{2m} \nabla^2 + V_{eff}(\mathbf{r}) \right) \psi_i(\mathbf{r}) = \varepsilon_i \psi_i(\mathbf{r})$$
- **열전달 연구 목적**:
  - 완벽한 결정 격자(AlN, Si, Cu, GaN)의 동역학적 행렬(Dynamical Matrix) 계산.
  - 음향 포논(LA, TA) 및 광학 포논(LO, TO) 분산 곡선 $\omega(\mathbf{q})$ 도출.
  - 3차 비조화 원자간 힘상수(3rd-order Interatomic Force Constants, IFC) 계산 $\to$ 포논-포논 Umklapp 산란율 및 벌크 고유 열전도도 $k_{bulk}$ 산출.
- **주요 도구**: **Quantum ESPRESSO (`pw.x`, `ph.x`)**, VASP, Phonopy, thirdorder.py.

---

### 1.2 원자 분자동역학: MD (Molecular Dynamics)
- **공간 스케일**: $1 \sim 50\,\text{nm}$ (원자 수만~수백만 개, 시간 스케일: 피코~나노초)
- **지배 방정식**: 뉴턴 운동 제2법칙 (원자간 경험적/기계학습 포텐셜 $U(\mathbf{r}_{ij})$ 기반)
  $$m_i \frac{d^2 \mathbf{r}_i}{dt^2} = -\nabla_i U(\mathbf{r}_1, \mathbf{r}_2, \dots, \mathbf{r}_N)$$
- **열전달 연구 목적 (TBR 도출)**:
  1. **평형 분자동역학 (EMD, Green-Kubo 공식)**:
     열유속 자기상관함수(HCACF) 적분을 통해 부피 $V$의 균일 벌크 열전도도 도출:
     $$k_{\alpha\beta} = \frac{1}{V k_B T^2} \int_0^\infty \langle J_\alpha(0) J_\beta(t) \rangle dt$$
  2. **비평형 분자동역학 (NEMD)**:
     Cu와 AlN 접합 모델의 양 끝에 열원(Heat Source)과 냉원(Heat Sink)을 배치하고, 계면에서의 온도 불연속 단차 $\Delta T_{interface}$ 측정:
     $$G_{interface} = \frac{q''}{\Delta T_{interface}} = \frac{1}{\text{TBR}}$$
  3. 원자 스케일 표면 거칠기($R_q \approx 0.2\text{--}1.0\,\text{nm}$) 및 계면 공공(Vacancy)이 포논 투과율에 미치는 영향 정량화.
- **주요 도구**: **LAMMPS**, GROMACS, ASE(Atomic Simulation Environment).

---

### 1.3 메조스케일 포논 수송: BTE (Boltzmann Transport Equation)
- **공간 스케일**: $10\,\text{nm} \sim 10\,\mu\text{m}$ (원자 격자보다 크고 연속체보다 작음)
- **지배 방정식**: 포논 볼츠만 수송 방정식 (RTA 이완시간 근사)
  $$\mathbf{v}_g \cdot \nabla f_\lambda = -\frac{f_\lambda - f_0}{\tau_\lambda}$$
- **열전달 연구 목적**:
  - 두께 $10\text{--}500\,\text{nm}$의 박막에서 경계 산란(Boundary Scattering)으로 인한 열전도도 급감 현상 모델링:
    $$\frac{1}{\tau_{total}} = \frac{1}{\tau_{bulk}} + \frac{1}{\tau_{boundary}} = \frac{1}{\tau_{bulk}} + \frac{2 |\mathbf{v}_{g,z}|}{t} \left(\frac{1-p}{1+p}\right)$$
  - 포논 누적 열전도도 $k_{accum}(\Lambda)$ 스펙트럼 도출 $\to$ 어떤 평균자유행정($\Lambda$)을 갖는 포논이 열을 주로 운반하는지 분석.
- **주요 도구**: **ShengBTE**, almaBTE, OpenBTE, BTE-BEM.

---

### 1.4 연속체 거시 열-응력 유한요소 해석: FEM (Finite Element Method)
- **공간 스케일**: $1\,\mu\text{m} \sim 50\,\text{mm}$ (칩, 패키지 기판, PCB 전체)
- **지배 방정식**:
  1. 열전도 방정식: $\rho c_p \frac{\partial T}{\partial t} = \nabla \cdot (k \nabla T) + \dot{q}_{gen}$
  2. 열탄소성 구조 방정식: $\nabla \cdot \boldsymbol{\sigma} = 0, \quad \boldsymbol{\sigma} = \mathbf{D} : (\boldsymbol{\varepsilon} - \boldsymbol{\alpha}\Delta T - \boldsymbol{\varepsilon}_{pl})$
- **열전달/패키징 연구 목적**:
  - 3차원 적층 칩(Cu 패드 + AlN 절연막)의 국소 핫스팟 발열 시 3D 열확산 저항($R_{sp}$) 및 접션 온도($T_j$) 평가.
  - Cu($\text{CTE} \approx 16.5\times 10^{-6}/\text{K}$)와 AlN($\text{CTE} \approx 4.5\times 10^{-6}/\text{K}$), Si($2.6\times 10^{-6}/\text{K}$) 간의 극심한 열팽창 불일치로 인한 접합 계면 전단 응력($\tau_{shear}$) 및 칩 휨(Warpage) 해석.
- **주요 도구**: **Elmer FEM (오픈소스 멀티피직스)**, ANSYS Mechanical, COMSOL Multiphysics, LS-DYNA.

---

### 1.5 전산유체역학 및 켤레 열전달: CFD (Computational Fluid Dynamics)
- **공간 스케일**: $50\,\mu\text{m} \sim 200\,\text{mm}$ (마이크로채널, 콜드플레이트, 시스템 섀시)
- **지배 방정식**: Navier-Stokes 방정식 + 에너지 보존 방정식 (켤레 열전달 CHT 연성)
- **열전달 연구 목적**:
  - 마이크로채널 및 매니폴드(MMC) 내 냉각수 유동장, 압력 손실($\Delta P$), 국소 대류 열전달 계수($h(x,y)$) 산출.
  - 증기챔버(Vapor Chamber) 내부 다공성 위크 모세관 침투 및 VOF(Volume of Fluid) 기반 2상 증발/응축 해석.
- **주요 도구**: **OpenFOAM**, ANSYS Fluent, Flow-3D.

---

## 🔄 2. 스케일 간 상호 연동(Handshake) 파이프라인

멀티스케일 시뮬레이션의 성패는 하위 스케일의 결과를 상위 스케일의 물성 파라미터로 무손실 전달하는 파이프라인 구성에 있습니다:

```
[Level 1: DFT] ──► (IFC 힘상수, 포논 분산 ω(q)) ──► [Level 2: BTE]
                                                          │
  ┌───────────────────────────────────────────────────────┘
  ▼
(두께별 k_eff(t), 포논 MFP 분포) 
  │
  ├─► [Level 3: NEMD] ──► (계면 TBR / G_c, 파괴에너지 G_int)
  │                            │
  └────────────┬───────────────┘
               ▼
[Level 4: FEM / CFD (Elmer FEM, Fluent)]
  - 재료 물성: k_bulk 대신 BTE 산출 k_eff(t) 입력
  - 접합 계면: 완벽 접촉 대신 NEMD 산출 Kapitza 저항(R_c = 1/G_c) 접촉 경계조건 부여
  - 구조 물성: DFT 산출 탄성계수(C_ij) 및 열팽창계수(CTE) 주입
```

---

## 💻 3. 대학 연구실(Lab-scale) 오픈소스 기반 시뮬레이션 구축 가이드

고가의 상용 라이선스(ANSYS, VASP) 없이 대학교 및 중소 연구실에서 PC1(RTX 4070 Ti) 또는 리눅스 워크스테이션으로 구축 가능한 풀 오픈소스 파이프라인:

1. **원자/포논 물성**:
   - `Quantum ESPRESSO` (WSL / Ubuntu) + `Phonopy` + `thirdorder.py`
   - 순수 오픈소스만으로 AlN wurtzite 결정 격자의 3-Phonon IFC 및 벌크 $k$ 계산 가능.
2. **나노 계면 TBR**:
   - `LAMMPS` (MPI 병렬 빌드) + `Tersoff / Vashishta 포텐셜`
   - Cu/AlN 및 AlN/Si 계면 NEMD 온도 단차 시뮬레이션 수행.
3. **거시 3D 열-응력**:
   - 형상/메시: `Gmsh` (Python API)
   - 유한요소 솔버: `Elmer FEM` (멀티피직스 열전도-탄성체 연성)
   - 후처리: `ParaView`
4. **유체 및 냉각판**:
   - `OpenFOAM (chtMultiRegionFoam)` 기반 마이크로채널 켤레 열전달 해석.

---

## 🔗 Knowledge Connections
- [[반도체_열관리_멀티스케일_시뮬레이션_및_디지털트윈_통합_총람]] : 마스터 개요
- [[물리기반 차수축소모델(ROM)과 PINN 및 서스테인 AI 서베이]] : FEM/CFD의 AI 초고속 대리 모델화
- [[포논 볼츠만 수송 방정식 (BTE)]] : BTE 수치해석 심층 이론
- [[카피차 저항 및 계면 열전도도 (Kapitza Resistance & TBC)]] : MD 기반 TBR 산출 이론
- [[전달현상 지배방정식과 나비에-스톡스-에너지-연속 방정식 (Navier-Stokes & Energy Equation)]] : CFD 연속체 지배식

*Last updated: 2026-10-07*
