# [[제1원리_DFT_전자구조_및_포논_시뮬레이션_가이드 (DFT & Phonon QE VASP)]]

## 📌 Brief Summary
본 문서는 반도체 열관리 핵심 소재인 Wurtzite AlN, Cu, GaN의 결정 구조 완화(Relaxation), 전자 상태밀도(DOS), 포논 분산 곡선 $\omega(\mathbf{q})$, 그리고 3차 비조화 원자간 힘상수(IFC)를 추출하기 위한 **제1원리 밀도범함수론(DFT) 및 밀도범함수 섭동이론(DFPT) 시뮬레이션 가이드와 PC1 vs PC2 하드웨어 스케일링 프로토콜**을 담은 기술 지식 노트입니다.

---

## 🔬 1. DFT 열수송 시뮬레이션의 목적과 지배 방정식

포논 열전도도 $k_{bulk}$를 결정하는 기본 입력값(음향 포논 군속도 $\mathbf{v}_g$, 포논 산란 수명 $\tau$)은 원자 스케일 제1원리 계산으로부터 얻어집니다.

1. **Kohn-Sham 전자 바닥상태 방정식**:
   $$\left( -\frac{\hbar^2}{2m}\nabla^2 + V_{ion}(\mathbf{r}) + V_H[\rho](\mathbf{r}) + V_{xc}[\rho](\mathbf{r}) \right) \psi_i(\mathbf{r}) = \varepsilon_i \psi_i(\mathbf{r})$$
2. **DFPT (Density Functional Perturbation Theory)**:
   원자 변위 섭동에 대한 2차 동역학 행렬(Dynamical Matrix $D_{\alpha\beta}(\mathbf{q})$)을 자기일관적으로 계산:
   $$\det\left| \frac{1}{\sqrt{M_\kappa M_{\kappa'}}} D_{\kappa\alpha, \kappa'\beta}(\mathbf{q}) - \omega^2(\mathbf{q}) \mathbf{I} \right| = 0$$
   이를 통해 감마점($\Gamma$) 및 브릴루앙 영역 전역의 **포논 분산 곡선 $\omega(\mathbf{q})$ 및 포논 상태밀도(DOS)** 도출.
3. **3차 비조화 힘상수 (3rd-order IFCs, $\Phi_{\alpha\beta\gamma}(0, l, l'))$**:
   포논-포논 Umklapp 3차 산란율을 계산하기 위한 원자 변위 초격자 섭동 계산.

---

## 💻 2. 오픈소스 툴체인 워크플로우 (Quantum ESPRESSO + Phonopy)

```
  [1. pw.x (scf / vc-relax)]  ──► 격자 상수 완화 (AlN: a=3.11 Å, c=4.98 Å)
             │
             ▼
  [2. ph.x (DFPT q-mesh)]    ──► 2차 힘상수 행렬 및 포논 분산 계산 (Phonopy 연동)
             │
             ▼
  [3. thirdorder.py]         ──► 슈퍼셀 내 유한 변위(Finite Displacement) 생성
             │
             ▼
  [4. pw.x 대량 단발 계산]   ──► 변위 구조별 원자 작용력(Force) 추출 ──► ShengBTE 입력
```

---

## ⚙️ 3. 하드웨어별(PC1 vs PC2) 연산 용량 및 실행 스케일링

| 구분 | 현재 노트북 (i5 / 1650 Ti) | PC1 워크스테이션 (RTX 4070 Ti / 32GB) | PC2 클러스터 (Dual RTX 4090 / 128GB) |
| :--- | :--- | :--- | :--- |
| **최대 원자수 (Supercell)** | $4$ 원자 (원시셀 완화만 간신히 가능) | $36\sim 72$ 원자 ($3\times 3\times 2$ 슈퍼셀) | **$200\sim 500$ 원자 거대 결함 슈퍼셀** |
| **k-point 그리드** | $4\times 4\times 4$ | $8\times 8\times 6$ (고정밀 수렴) | $12\times 12\times 10$ (초정밀 Fermi 면 해석) |
| **포논 연산 가능 영역** | 2차 포논 감마점 $\Gamma$ 전용 | 2차 전 브릴루앙 영역 DFPT 완주 | **3차 비조화 IFC 대량 변위 병렬 완주** |
| **결함/합금 모델링** | 불가 | AlN 순수 단결정 전용 | AlN 내 산소 불순물($\text{O}_N$), 공공($V_{Al}$) 결함 |
| **소요 시간 (2차 DFPT)** | 수십 시간 이상 (발열 쓰로틀링) | $2\sim 4$ 시간 (16-thread MPI) | **$< 30$ 분 (초고속 병렬)** |

---

## 📝 4. Quantum ESPRESSO 실행 인풋 템플릿 (AlN vc-relax)

```fortran
&CONTROL
    calculation   = 'vc-relax'
    restart_mode  = 'from_scratch'
    prefix        = 'AlN_wurtzite'
    pseudo_dir    = './pseudo/'
    outdir        = './tmp/'
    forc_conv_thr = 1.0D-4
    etot_conv_thr = 1.0D-5
/
&SYSTEM
    ibrav       = 4
    celldm(1)   = 5.877      ! a = 3.11 Å (Bohr 단위)
    celldm(3)   = 1.601      ! c/a ratio ≈ 1.601
    nat         = 4
    ntyp        = 2
    ecutwfc     = 80.0       ! 파동함수 Cutoff (Ry)
    ecutrho     = 640.0      ! 전하밀도 Cutoff (Ry)
    occupations = 'fixed'
/
&ELECTRONS
    conv_thr    = 1.0D-8
    mixing_beta = 0.7
/
&IONS
/
&CELL
    cell_dofree = 'all'
/
ATOMIC_SPECIES
  Al  26.9815  Al.pbe-n-kjpaw_psl.1.0.0.UPF
  N   14.0067  N.pbe-n-kjpaw_psl.1.0.0.UPF
ATOMIC_POSITIONS (crystal)
  Al  0.333333333  0.666666667  0.000000000
  Al  0.666666667  0.333333333  0.500000000
  N   0.333333333  0.666666667  0.382100000
  N   0.666666667  0.333333333  0.882100000
K_POINTS (automatic)
  8 8 6 0 0 0
```

---

## 🔗 Knowledge Connections
- [[반도체_열관리_및_공정_전체_시뮬레이션_포트폴리오_총람 (All Simulation Portfolio)]] : 전체 포트폴리오
- [[포논_BTE_및_메조스케일_열수송_몬테카를로_시뮬레이션 (ShengBTE & OpenBTE)]] : DFT 출력 IFC를 받는 BTE
- [[분자동역학_MD_계면_TBR_및_머신러닝포텐셜_시뮬레이션 (LAMMPS & DeepMD)]] : DFT 데이터 기반 DeepMD 학습
- [[Wurtzite AlN 결정성 및 포논 수송 메커니즘]] : AlN 분산 물성 이론

*Last updated: 2026-10-07*
