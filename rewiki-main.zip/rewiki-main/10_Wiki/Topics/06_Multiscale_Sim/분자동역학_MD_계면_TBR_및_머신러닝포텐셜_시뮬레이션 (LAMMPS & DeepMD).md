# [[분자동역학_MD_계면_TBR_및_머신러닝포텐셜_시뮬레이션 (LAMMPS & DeepMD)]]

## 📌 Brief Summary
본 문서는 Cu-AlN 및 AlN-Si 이종 접합 계면의 카피차 열경계저항(TBR / $G_c$)과 계면 결합 파괴 에너지를 계산하기 위한 **원자 분자동역학(MD / NEMD / EMD)의 지배 원리, LAMMPS Kokkos GPU 가속 기술, DeepMD 머신러닝 포텐셜 적용법, 그리고 PC1(RTX 4070 Ti) vs PC2(Dual RTX 4090 / 128GB) 하드웨어 스케일링**을 다룬 전문 기술 노트입니다.

---

## 🔬 1. 비평형 분자동역학 (NEMD) 기반 계면 TBR 산출 원리

접합 계면을 사이에 두고 시스템 양단에 열원(Heat Source)과 냉원(Heat Sink)을 Langevin 서모스탯으로 제어하여 정상상태 1차원 열유속 $q''$을 강제 인가합니다.

```
  [히터 Langevin (+q)] ──► [Cu 영역] ──► [Cu/AlN 계면: ΔT 발생] ──► [AlN 영역] ──► [쿨러 Langevin (-q)]
                                                │
                                                ▼
                             계면 열컨덕턴스 G = q'' / ΔT  (W/m²K)
                             계면 열경계저항 TBR = 1 / G    (m²K/W)
```

1. **시간 적분 및 앙상블**:
   - 시간 간격: $\Delta t = 0.5\sim 1.0\,\text{fs}$ ($10^{-15}\,\text{s}$).
   - NPT(압력·온도 완화, 200 ps) $\to$ NVE(에너지 보존 계통에서 열원/냉원 인가, $2\sim 5\,\text{ns}$) 과도 상태를 거쳐 통계적 정상상태 도달 후 계면 온도 단차 $\Delta T$ 시간 평균.
2. **원자간 포텐셜 (Interatomic Potentials)**:
   - Cu-Cu: EAM (Embedded Atom Method, Foiles-Daw-Baskes).
   - Al-N: Tersoff 또는 Vashishta 다체 포텐셜.
   - Cu-Al-N 계면: MEAM (Modified EAM) 또는 Lennard-Jones/Morse 파라미터화.

---

## 🧠 2. 차세대 머신러닝 포텐셜 (DeepMD-kit & NEP)

경험적 포텐셜(Tersoff/MEAM)은 계면의 화학 결합 변화나 미세 결함 상태를 표현하는 데 한계가 있습니다. **DeepMD-kit (Deep Molecular Dynamics)**은 DFT 계산 데이터를 딥러닝하여 **DFT 수준의 양자역학적 정확도로 고속 MD를 수행**합니다.

- **원자 에너지 신경망**:
  $$E = \sum_i E_i, \quad E_i = \mathcal{N}_\theta(\mathcal{R}_i)$$
  ($\mathcal{R}_i$: 원자 $i$의 국소 회전·병진 불변 좌표 디스크립터)
- **효과**: 기존 고전 포텐셜 대비 계면 포논 산란 투과율 예측 오차를 $20\%$에서 **$2\%$ 이내로 압축**.

---

## ⚡ 3. PC1 vs PC2 하드웨어 연산 도약 정량 비교

| 평가 항목 | PC1 워크스테이션 (RTX 4070 Ti 12GB) | PC2 클러스터 (Dual RTX 4090 48GB / 128GB) |
| :--- | :--- | :--- |
| **최대 원자수 (Atom Count)** | $\sim 50,000 \text{--} 100,000$ 원자 | **$1,000,000 \sim 3,000,000$ 원자 (백만 개 이상 대규모)** |
| **계면 모델 형상** | 완벽히 평평한 2D 이상적 계면 전용 | **실제 표면 조도 ($R_q \approx 0.5\text{--}1.0\,\text{nm}$) 3D 조도 직접 모사** |
| **LAMMPS Kokkos 가속** | 단일 GPU 가속 ($12\,\text{GB}$) | **Dual GPU 분산 가속 (32,768 CUDA 코어)** |
| **적분 속도 (Speed)** | $\sim 3\text{--}6\,\text{ns/day}$ (EAM 기준) | **$\sim 30\text{--}60\,\text{ns/day}$ (10배 이상 초고속)** |
| **DeepMD 훈련/추론** | 배치 사이즈 제한, 장시간 훈련 소요 | **Dual 24GB VRAM을 통한 고속 분산 훈련** |

---

## 📝 4. LAMMPS NEMD 인풋 스크립트 핵심 템플릿

```lammps
# Cu-AlN Interface NEMD Thermal Conductance Calculation
units           metal
dimension       3
boundary        p p f
atom_style      atomic

read_data       cu_aln_interface.data

# 포텐셜 설정 (MEAM / Tersoff)
pair_style      hybrid meam tersoff
pair_coeff      * * meam library.meam Cu Al N CuAlN.meam Cu Al N
pair_coeff      * * tersoff AlN.tersoff NULL Al N

# 시간 간격: 1 fs
timestep        0.001

# 1단계: NPT 등온등압 완화 (300 K, 1 bar)
velocity        all create 300.0 12345 mom yes rot yes
fix             1 all npt temp 300.0 300.0 0.1 x 0.0 0.0 1.0 y 0.0 0.0 1.0
run             200000
unfix           1

# 2단계: Langevin 열원/냉원 인가 (NEMD)
group           hot_region id 1:500
group           cold_region id 4500:5000
fix             nve_all all nve
fix             f_hot hot_region langevin 350.0 350.0 0.1 54321 tally yes
fix             f_cold cold_region langevin 250.0 250.0 0.1 98765 tally yes

# 온도 프로파일 1D 빈(bin) 분할 측정
compute         ke all ke/atom
variable        temp atom c_ke/(1.5*8.61733e-5)
fix             ave_chunk all ave/chunk 10 1000 10000 z_chunk temp file temp_profile.dat

run             2000000
```

---

## 🔗 Knowledge Connections
- [[반도체_열관리_및_공정_전체_시뮬레이션_포트폴리오_총람 (All Simulation Portfolio)]] : 마스터 총람
- [[제1원리_DFT_전자구조_및_포논_시뮬레이션_가이드 (DFT & Phonon QE VASP)]] : DeepMD 학습용 DFT 데이터 제공
- [[카피차 저항 및 계면 열전도도 (Kapitza Resistance & TBC)]] : MD로 계산하는 이론적 물리
- [[계면 열경계 저항과 AMM DMM 역사 (History of TBR AMM DMM)]] : 음향부합모델(AMM)과 MD 비교

*Last updated: 2026-10-07*
