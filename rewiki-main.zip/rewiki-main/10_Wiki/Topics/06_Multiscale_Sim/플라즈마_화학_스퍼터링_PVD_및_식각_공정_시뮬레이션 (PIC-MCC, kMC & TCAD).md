# [[플라즈마_화학_스퍼터링_PVD_및_식각_공정_시뮬레이션 (PIC-MCC, kMC & TCAD)]]

## 📌 Brief Summary
본 문서는 반도체 제조 공정에서 반응성 마그네트론 스퍼터링(AlN PVD)의 플라즈마 방전 특성, 스퍼터 입자 수송, 타깃 피독, 그리고 금속 건식 식각(Cu/Co)의 측벽 재증착 및 단차 피복성(Step Coverage)을 예측하기 위한 **플라즈마 입자 해석(PIC-MCC), 기체 희박 유동(DSMC), 표면 동역학 몬테카를로(kMC), 형상 진화 TCAD 시뮬레이션 및 PC1 vs PC2 하드웨어 스케일링**을 다룬 전문 지식 노트입니다.

---

## ⚗️ 1. 스퍼터링 & 식각 공정 시뮬레이션 다계층 아키텍처

```
  [1. 챔버 플라즈마 해석 (PIC-MCC)] ──► 전자-이온 쉬스 형성, 타깃 충돌 IEDF 도출
                │
                ▼
  [2. 중성 입자 기체 수송 (DSMC)]    ──► 타깃 스퍼터 Al/Cu 원자 충돌 산란, 기판 도달각
                │
                ▼
  [3. 나노 패턴 형상 진화 (kMC/TCAD)] ──► 박막 스텝커버리지, 식각 측벽 재증착(Redeposition)
```

---

## 🔬 2. 기법별 지배 원리 및 대표 도구

### 2.1 플라즈마 입자 해석: PIC-MCC (Particle-in-Cell with Monte Carlo Collisions)
- **지배 원리**:
  로렌츠 힘 $\mathbf{F} = q(\mathbf{E} + \mathbf{v} \times \mathbf{B})$에 의해 가속되는 전하 입자의 운동방정식을 메쉬 상에서 풀고, 이온-중성종 간의 탄성 충돌 및 이온화 충돌을 몬테카를로 확률로 처리.
- **출력 데이터**: 타깃 표면에 충돌하는 $\text{Ar}^+$ 및 $\text{N}_2^+$ 이온의 **에너지-각도 분포 함수 (IEDF / IADF)**.
- **주요 도구**: **XOOPIC**, VSim, VPIC.

### 2.2 중성종 희박 기체 수송: DSMC (Direct Simulation Monte Carlo)
- **지배 원리**:
  챔버 내부 압력이 낮아($Kn > 0.1$) 연속체 나비에-스톡스가 파탄나는 진공 영역에서 볼츠만 기체 분자 충돌을 직접 모사.
- **스퍼터링 연계**:
  타깃에서 뜯겨 나온 고에너지 금속 원자(Al, Cu)가 배경 Ar 가스와 충돌하며 열화(Thermalization)되어 기판에 입사하는 3차원 공간 플럭스 맵핑.
- **주요 도구**: **SPARTA (Sandia National Lab 오픈소스)**.

### 2.3 표면 반응 및 패턴 형상 진화: kMC (Kinetic Monte Carlo) & Level-Set
- **지배 원리**:
  흡착, 탈착, 표면 확산, 화학 반응의 활성화 에너지($E_a$) 기반 천이 속도 $r = \nu_0 \exp(-E_a/k_B T)$를 계산하여 패턴 프로파일 진화 추적.
- **식각 연계**:
  Cu 식각 시 비휘발성 $\text{CuCl}$ 생성물 입자가 마스크 측벽에 물리적으로 튕겨 달라붙는 **재증착(Redeposition) 형상 및 마이크로 트렌칭(Micro-trenching)** 정확한 예측.
- **주요 도구**: **KMCLib**, SPPARKS, Silvaco Victory Topography.

---

## ⚙️ 3. PC1 vs PC2 하드웨어 연산 도약 정량 비교

PIC-MCC 및 DSMC는 수천만 개 이상의 의사 입자(Super-particles)를 3차원 공간에서 추적하므로 **GPU 메모리 대역폭과 대규모 병렬 스레드 수**가 필수적입니다.

| 평가 항목 | PC1 워크스테이션 (RTX 4070 Ti 12GB) | PC2 클러스터 (Dual RTX 4090 48GB / 128GB) |
| :--- | :--- | :--- |
| **PIC-MCC 모사 차원** | 2D 축대칭(2D-RZ) 플라즈마 쉬스 해석 | **3D 챔버 전체 마그네트론 자기장-플라즈마 해석** |
| **추적 입자수 (Particle Count)** | $\sim 10^6$ 개 수퍼 파티클 | **$5\times 10^7$ 개 이상 (초고정밀 통계 노이즈 제거)** |
| **DSMC 3D 진공 챔버 해석** | 조대 격자 스퍼터링 분포 맵핑 | **타깃 피독-게터링 연동 3D 전역 가스압 해석** |
| **kMC 나노 패턴 형상 진화** | 단일 트렌치 2D 프로파일 | **3D AAO 고종횡비($AR > 10$) 나노포어 내부 전착 모사** |
| **소요 시간** | $12\sim 24$ 시간 | **Dual 4090 CUDA 병렬화로 $1\sim 2$ 시간 내 완료** |

---

## 🔗 Knowledge Connections
- [[반도체_열관리_및_공정_전체_시뮬레이션_포트폴리오_총람 (All Simulation Portfolio)]] : 전체 포트폴리오
- [[반응성_스퍼터링과_타깃_피독_메커니즘_및_논문_총람 (Reactive Sputtering & Target Poisoning)]] : 공정 시뮬레이션의 물리적 대상
- [[구리_식각_연구_논문_및_화학반응_총람 (Cu Dry Etch & ALE Literature)]] : Cu 식각 재증착 메커니즘
- [[전기도금과 AAO 나노템플릿 공정 원리 (Electroplating & AAO Templates)]] : AAO 내부 물질수송 kMC

*Last updated: 2026-10-07*
