# [[반도체 자가발열과 열폭주 메커니즘 (Self-Heating & Thermal Runaway)]]

## 📌 Brief Summary
자가발열(Self-Heating Effect, SHE)은 반도체 트랜지스터(FinFET, GAAFET, HEMT 등) 채널 내부를 전자가 고속으로 통과할 때, 격자 원자와 충돌하여 줄열(Joule heating)을 발생시키고 소자 자체의 온도가 급상승하는 현상입니다. 발생한 열이 적절히 방출되지 못하면 온도가 오를수록 누설전류가 급증하고, 이 전류가 다시 발열을 가속화하여 소자가 영구 파괴되는 악순환을 **열폭주(Thermal Runaway)**라고 합니다.

## 📖 Core Content

### 1. 트랜지스터 내부 발열 메커니즘 (Joule Heating)
- 소자 내부 전력 소모 $P$는 동적 전력과 정적 누설 전력의 합으로 정의됩니다:
  $$P = P_{\text{dynamic}} + P_{\text{static}} = \alpha C V_{dd}^2 f + I_{\text{leak}} V_{dd}$$
- **국소 핫스팟 발열 밀도:**
  - $3\,\text{nm}$ 이하 미세 노드에서는 채널 단면적이 수십 $\text{nm}^2$에 불과하여 국소 발열 밀도가 **$10 \sim 100\,\text{MW/m}^2$** ($1,000 \sim 10,000\,\text{W/cm}^2$)에 달합니다 (태양 표면 열유속의 수 배 수준).

### 2. 열폭주(Thermal Runaway)의 양의 피드백 루프 (Positive Feedback Loop)
```
[트랜지스터 동작 & 줄열 발생] ──► [국소 온도 상승 (T ↑)]
               ▲                              │
               │                              ▼
[발열량 급증 (P = I_leak × V ↑)] ◄── [누설전류 지수적 폭증 (I_leak ∝ exp(-Eg/2kT) ↑)]
```
1. 온도가 상승하면 실리콘 내부 열적 전자-정공 쌍 생성이 증가하여 접합 역방향 누설전류와 서브스레숄드 누설전류($I_{\text{sub}}$)가 지수함수적으로 증가:
   $$I_{\text{leak}} \propto T^2 \exp\left(-\frac{q V_{\text{th}}}{m k_B T}\right)$$
2. 증가한 누설전류가 추가 줄열을 발생시켜 온도를 더 상승시킴 $\rightarrow$ 임계 온도($\approx 150 \sim 175^\circ\text{C}$)를 넘어서면 열폭주로 게이트 산화막이나 금속 배선이 용융 파괴됨.

### 3. 온도가 소자 성능과 신뢰성에 미치는 3대 치명적 영향
1. **캐리어 이동도 저하 (연산 속도 감속):**
   - 온도가 오르면 포논 산란이 증가하여 전자의 이동도가 급감함: $\mu(T) \propto T^{-3/2}$. 클럭 주파수가 $10 \sim 20\%$ 저하됨.
2. **일렉트로마이그레이션(Electromigration, EM) 가속화 (배선 단선):**
   - 금속 원자가 전자의 충격에 의해 밀려나 배선이 끊어지는 현상으로, 블랙의 방정식(Black's Equation)에 따라 수명이 온도에 반비례함:
     $$\text{MTTF} = \frac{A}{J^n} \exp\left(\frac{E_a}{k_B T}\right)$$
   - 온도가 $20^\circ\text{C}$ 상승하면 수명이 $1/4$ 수준으로 급감함.
3. **열팽창 불일치(CTE Mismatch) 응력 및 박리 (Warpage & Delamination):**
   - 구리($16.5 \times 10^{-6}/\text{K}$)와 실리콘($2.6 \times 10^{-6}/\text{K}$)의 열팽창 차이로 인해 본딩 접합면이 찢어지거나 크랙이 발생함.

## 🔗 Knowledge Connections
- **Parent/Higher Topic:** [[열전도도와 푸리에 법칙 기초 (Thermal Conductivity & Fourier Law)]]
- **Sub-Concepts (더 쉬운 개념):** [[전기-열 상사성과 열저항 회로 (Thermal Resistance Network)]]
- **Advanced Transition (심화 전이):** [[BSPDN 후면 전력공급망 열관리 아키텍처]], [[3D 적층 패키징의 진화: 와이어본딩부터 하이브리드 본딩까지 (Packaging Evolution)]]

---
*Last updated: 2026-10-07*
