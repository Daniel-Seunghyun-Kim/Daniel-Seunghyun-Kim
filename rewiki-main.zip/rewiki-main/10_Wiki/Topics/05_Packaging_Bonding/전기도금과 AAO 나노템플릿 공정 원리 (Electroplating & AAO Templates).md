# [[전기도금과 AAO 나노템플릿 공정 원리 (Electroplating & AAO Templates)]]

## 📌 Brief Summary
전기도금(Electrodeposition)은 외부 전원을 인가하여 전해액 내부의 금속 이온을 환원시켜 전도성 음극 표면에 금속 고체를 석출시키는 전기화학 공정입니다. Anodic Aluminum Oxide(AAO) 템플릿은 알루미늄을 산성 수용액에서 전기화학적으로 산화시킬 때 자가조직화(Self-organization)에 의해 육방정계로 고밀도 정렬되는 수직 원통형 나노기공 박막으로, 1995년 마스다(Masuda) 교수의 2단계 양극산화법 발명 이래 나노와이어/나노필러 어레이 제조의 핵심 표준 기술입니다.

## 📖 Core Content

### 1. 패러데이 법칙과 전기도금 속도
음극에서 환원 석출되는 금속의 질량 $m$ (Faraday's Law of Electrolysis):
$$m = \frac{Q \cdot M}{z \cdot F} = \frac{I \cdot t \cdot M}{z \cdot F}$$
- $Q$: 총 통과 전하량 ($I \cdot t$)
- $M$: 구리의 몰질량 ($63.55\,\text{g/mol}$)
- $z$: 구리 이온의 가수 ($Cu^{2+} \to z = 2$)
- $F$: 패러데이 상수 ($96,485\,\text{C/mol}$)
- **도금 두께 성장률 계산:**
  기공 면적비와 전류밀도($J = 1 \sim 3\,\text{A/dm}^2$)에 따라 21.43분 만에 목표 높이인 **$750 \pm 50\,\text{nm}$의 구리 나노필러**를 오차 $\pm 5\%$ 이내로 정밀 성장 제어.

### 2. 펄스 도금(Pulse Electroplating)의 공극(Void) 억제 원리
- 고종횡비 나노기공 내부에서는 $Cu^{2+}$ 이온의 확산 속도가 제한되어, 연속 DC 전압을 인가하면 입구 쪽만 빨리 막혀 내부에 거대한 공극(Void)이 생김.
- **Pulse 전기도금 ($T_{\text{on}} / T_{\text{off}}$ 듀티 사이클):**
  - $T_{\text{on}}$: 전류를 흘려 기공 바닥에서 구리 핵생성 및 성장.
  - $T_{\text{off}}$: 전류를 차단하여 전해액 속의 $Cu^{2+}$ 이온이 기공 바닥까지 충분히 농도 구배에 의해 재확산(Replenishment)할 시간을 부여.
  - 상향식(Bottom-up) 완전 무결점 충진 달성.

### 3. Masuda 2단계 양극산화법 (Two-Step Anodization, 1995년)
1. **1차 양극산화:** 알루미늄 포일을 옥살산($\text{H}_2\text{C}_2\text{O}_4$) 또는 인산 용액에서 수십 V 전압으로 산화 $\rightarrow$ 불규칙한 초기 기공 형성.
2. **선택적 용해:** 불규칙한 산화막을 산 혼합액으로 제거 $\rightarrow$ Al 금속 표면에 오목한 육방격자 나노 딤플(Dimple) 패턴 잔존.
3. **2차 양극산화:** 딤플을 씨앗 삼아 재산화 $\rightarrow$ 완벽하게 정렬된 수직 원통형 나노기공 어레이(피치 $500\,\text{nm}$, 기공 직경 $100 \sim 200\,\text{nm}$) 완성.

## 🔗 Knowledge Connections
- **Parent/Higher Topic:** [[반도체_나노열관리_마인드맵_총괄_지식지도]]
- **Sub-Concepts:** [[비휘발성 금속 식각과 재증착 제어 (Non-volatile Metal Etching & Redeposition)]]
- **Advanced Transition:** [[스퍼터링 PVD 공정의 기본 원리와 플라즈마 (Sputtering & Plasma Basics)]], [[3D 적층 패키징의 진화: 와이어본딩부터 하이브리드 본딩까지 (Packaging Evolution)]]

---
*Last updated: 2026-10-07*
