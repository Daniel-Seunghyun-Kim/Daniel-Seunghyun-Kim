# [[반도체 직접 접합과 표면 활성화 연대기 (Direct Bonding History 1986-2026)]]

## 📌 Brief Summary
직접 접합(Direct Bonding)은 접착제나 중간 솔더 매개체 없이 두 평탄화된 고체 표면의 원자간 결합을 유도하는 혁신적인 접합 기술입니다. 1986년 도시바(Toshiba)의 실리콘-실리콘 친수성 접합에서 시작하여, 2000년대 플라즈마 표면 활성화, 2010년대 Ziptronix/Sony의 하이브리드 본딩 상용화, 그리고 2026년 저온 물리 플라즈마 활성화 질화물 직접 접합에 이르기까지 40년간의 발전 역사를 체계적으로 조망합니다.

## 📖 Core Content

### 1. 1986년~1990년대: 친수성(Hydrophilic) 실리콘 직접 접합의 개막
1. **1986년 (Shimbo et al. / Lasky et al. - 동시 독립 발견):**
   - 불산/황산으로 세정한 거울면 실리콘 웨이퍼 두 장을 상온에서 맞닿게 하면 자발적으로 밀착하여 붙는 현상 발견.
   - 고온 열처리($1,000 \sim 1,100^\circ\text{C}$)를 통해 $\text{Si}-\text{O}-\text{Si}$ 공유결합 완성.
   - 한계: $1,000^\circ\text{C}$ 이상의 극한 고온이 필요하여 금속 배선이 형성된 소자 웨이퍼에는 적용 불가.
2. **1990년대 중반 (Tong & Gösele - 저온화 연구):**
   - 듀크 대학의 Gösele 교수 그룹이 표면 수산화기($-\text{OH}$) 밀도를 제어하여 접합 온도를 $400^\circ\text{C}$ 수준으로 낮추는 메커니즘 체계화.

### 2. 2000년대: 플라즈마 활성화 저온 본딩(Plasma Activated Bonding) 혁신
1. **O₂ 플라즈마 표면 개질:**
   - 대기압/저압 산소 플라즈마 처리를 통해 표면 유기물을 제거하고 초친수성 비정질 산화막 층을 형성하여, $200 \sim 300^\circ\text{C}$ 저온 어닐링만으로 벌크 실리콘 파괴 강도($> 2\,\text{J/m}^2$) 수준의 접합 에너지 달성.
2. **소수성(Hydrophobic) 접합:**
   - HF 침적으로 $\text{Si}-\text{H}$ 종단을 형성하여 계면에 산화막이 전혀 없는 순수 Si-Si 접합 구현.

### 3. 2010년대: 금속-유전체 동시 하이브리드 본딩 (DBI) 상용화
1. **Ziptronix 사의 DBI (Direct Bond Interconnect) 특허:**
   - 유전체($\text{SiO}_2$)와 금속(Cu)이 평면에 공존하는 웨이퍼를 동시에 접합하는 기술.
   - 상온에서 $\text{SiO}_2$가 먼저 분자간 힘으로 결합 $\rightarrow 200 \sim 250^\circ\text{C}$ 열처리 시 Cu가 열팽창하여 마이크로 디싱(Dishing) 틈새를 메우며 원자간 금속 결합 완성.
2. **Sony CMOS 이미지 센서(CIS) 최초 양산 적용 (2016년):**
   - 화소 칩과 로직 칩을 하이브리드 본딩으로 3D 적층하여 대량 양산에 성공, 스마트폰 카메라 혁명 촉발.

### 4. 2020년대~2026년: 차세대 이종 접합 (AlN, BSPDN, 저온 물리 활성화)
1. **2023~2025년 (Perez / Nieminen / Tuchman / Singh - IBM):**
   - 저전도성 $\text{SiO}_2$를 대체하여 고열전도성 AlN 박막을 직접 접합 인터페이스 및 BSPDN에 통합하려는 연구 폭발.
2. **2026년 (Huang et al., *Surfaces & Interfaces*):**
   - $\text{O}_2$ 플라즈마의 산화물 장벽 한계를 극복하기 위해 **Ar 플라즈마 물리적 이온 활성화**를 도입, 표면 거칠기 $2.85\,\text{nm}$ 및 $300^\circ\text{C}$ 이하에서 $>99\%$ 무결점 AlN 직접 접합 실현.

## 🔗 Knowledge Connections
- **Parent/Higher Topic:** [[저온 직접 접합 및 플라즈마 표면 활성화]]
- **Sub-Concepts:** [[스퍼터링 PVD 공정의 기본 원리와 플라즈마 (Sputtering & Plasma Basics)]]
- **Advanced Transition:** [[3D 적층 패키징의 진화: 와이어본딩부터 하이브리드 본딩까지 (Packaging Evolution)]], [[BSPDN 후면 전력공급망 열관리 아키텍처]]

---
*Last updated: 2026-10-07*
