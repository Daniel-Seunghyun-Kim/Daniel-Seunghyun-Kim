# [[BSPDN 후면 전력공급망 열관리 아키텍처]]

## 📌 Brief Summary
후면 전력 공급망(Backside Power Delivery Network, BSPDN)은 트랜지스터 전면(Frontside)에 집중되어 있던 전력선(Power rail)과 신호선(Signal lines)을 물리적으로 분리하여, 웨이퍼 후면으로 전력망을 재배치하는 차세대 $2\,\text{nm}$ 이하 최첨단 로직 반도체 표준 아키텍처입니다. 신호 간섭(RC 지연)과 IR 드롭을 획기적으로 개선하지만, 웨이퍼 후면 박막화($< 1\,\mu\text{m}$)와 매립 전력선(BPR) 구조로 인해 열류가 분산되지 못하고 국소 핫스팟이 심화되는 극한의 열관리 난제를 안고 있습니다.

## 📖 Core Content

### 1. BSPDN 구조의 핵심 요소와 동작 원리
- **전면(Frontside):** 초미세 나노시트(GAAFET / CFET) 로직 트랜지스터 및 고밀도 신호 인터커넥트(BEOL) 배치.
- **후면(Backside):** 대면적 파워 레일, 후면 배선층(BS-BEOL).
- **연결 매개체:**
  - **매립형 전력선 (Buried Power Rail, BPR):** 트랜지스터 하부에 직접 매립되는 저저항 텅스텐(W) 또는 루테늄(Ru) 배선.
  - **나노 TSV (Nano-Through Silicon Via):** 후면 파워 레일과 BPR을 수직으로 연결하는 초미세 관통 비아 (직경 $< 100\,\text{nm}$, 깊이 수백 nm).

### 2. 열적 병목 (Thermal Bottleneck) 심화 원인
1. **벌크 실리콘 방열 경로 소실:** 전력 공급을 위해 기판 실리콘을 수백 nm 수준으로 극단적으로 얇게 연마(Thinning)하므로, 기판 자체의 우수한 열확산(In-plane spreading, Si $k \approx 148\,\text{W/mK}$) 능력이 상실됨.
2. **트랜지스터 핫스팟의 열고립 (Thermal Confinement):** 전면과 후면 양쪽이 얇은 유전체 산화막($\text{SiO}_2$, $k \approx 1.3\,\text{W/mK}$)으로 둘러싸여 소자 작동 시 발생하는 열이 빠져나가지 못하고 갇히는 현상 발생.
3. **IR 드롭 개선 vs 자가발열 상승의 상충:** 전력 밀도가 상승하면서 접션 최고 온도가 최대 $15 \sim 25^\circ\text{C}$ 이상 추가 상승함.

### 3. AlN 본딩 라이너(Dielectric Liner)의 파괴적 혁신
- **IBM Research 모델 (Singh et al., IITC 2025):**
  - 저전도성 $\text{SiO}_2$ 라이너 대신 **고열전도성 AlN 박막 ($k \ge 40\,\text{W/mK}$)**을 후면 본딩 층 및 BPR 절연막으로 도입.
  - AlN 라이너가 핫스팟 직하부에서 수평 열확산(In-plane spreading) 통로 역할을 수행하여, 후면 나노 TSV와 파워 레일로의 열류 전달 효율을 극대화함.
  - 시뮬레이션 및 예비 실험 결과, 전체 소자 핫스팟 온도를 $10 \sim 15\,\text{K}$ 이상 억제하는 뛰어난 방열 개선 입증.

## 🔗 Knowledge Connections
- **Related Topics:** [[열확산 저항 (Spreading Resistance)]], [[카피차 저항 및 계면 열전도도 (Kapitza Resistance & TBC)]], [[Wurtzite AlN 결정성 및 포논 수송 메커니즘]]
- **Projects/Contexts:** [[3단계_신규테마_AlN_표면전달성_및_저온본딩_연구설계서]], [[D드라이브_통합연구자산_마스터플랜_2026]]
- **Contradictions/Notes:**
  - AlN의 높은 유전율($\kappa \approx 9$)이 신호 배선의 기생 커패시턴스를 증가시킬 수 있으므로, 신호선 영역은 Low-k 유전체를 유지하고 파워 레일 및 후면 방열 계면에만 AlN을 국소 배치하는 하이브리드 유전체 설계가 필수적임.

---
*Last updated: 2026-10-07*
