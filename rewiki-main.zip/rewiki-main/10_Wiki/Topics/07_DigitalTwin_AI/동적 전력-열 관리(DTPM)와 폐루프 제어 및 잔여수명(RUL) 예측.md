# [[동적 전력-열 관리(DTPM)와 폐루프 제어 및 잔여수명(RUL) 예측]]

## 📌 Brief Summary
본 문서는 반도체 소자의 실시간 안전 동작과 수명 극대화를 위한 **디지털 트윈 기반 동적 전력-열 관리(DTPM), 칼만 필터 상태 추정, 오프라인 강화학습(Offline RL) 자율 제어 루프, 그리고 Coffin-Manson 및 Black 식을 결합한 실시간 잔여 수명(RUL) 예지 진단 알고리즘**을 정립한 기술 지식 노트입니다.

---

## 🎯 1. 반도체 동적 전력-열 관리 (DTPM) 개요 및 제어 목적

AI 가속기(GPU/NPU) 및 3D HBM 적층 칩은 연산 부하에 따라 밀리초($\text{ms}$) 단위로 발열량이 급변합니다. 

```
                                [ 최적화 제어 목적식 ]
  Maximize   J = \sum_{t} \text{Performance (Throughput)} - \alpha \cdot \text{Pumping Power}
  Subject to:
    1. 최대 접션 온도 제약:   T_{junction, max}(t) \le T_{crit} \quad (\approx 105^\circ\text{C})
    2. 칩 평면 열구배 제약:   \Delta T_{die}(t) = T_{max}(t) - T_{min}(t) \le \Delta T_{crit} \quad (\approx 15^\circ\text{C})
    3. 온도 변화율 제약:       |dT/dt| \le \dot{T}_{max} \quad (열충격 방지)
```

---

## 🔄 2. 폐루프 디지털 트윈 제어 파이프라인 (Closed-Loop Pipeline)

```
┌────────────────────────────────────────────────────────────────────────┐
│ 1. 실물 칩 관측 (Sensing): DTS 센서 전압 측정값 z_k                    │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ 2. 상태 추정기 (UKF): 잡음 제거 및 미계측 3D 전신 온도장 \hat{x}_k 복원 │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ 3. 자율 제어기 (Offline RL / MPC): 최적 제어 지령 u_k 산출              │
│    - DVFS (코어별 전압/주파수 스케일링)                                │
│    - 스레드 스케줄링 (핫스팟 다이 회피)                                 │
│    - 마이크로 냉각수 펌프 유량 Q_pump 조절                              │
└──────────────────┬────────────────────────────────┬────────────────────┘
                   │ (제어 지령 적용)               │ (열 이력 전달)
                   ▼                                ▼
┌───────────────────────────────────┐ ┌──────────────────────────────────┐
│ 실물 반도체 칩 / 냉각 시스템      │ │ 4. 잔여 수명(RUL) 예지 엔진      │
│ (온도 하강 및 열폭주 방지 달성)   │ │    - 누적 열피로 손상도 갱신     │
└───────────────────────────────────┘ └──────────────────────────────────┘
```

---

## 📐 3. 핵심 수리 알고리즘

### 3.1 무향 칼만 필터 (Unscented Kalman Filter, UKF) 상태 추정
선형 칼만 필터는 비선형 열전도 및 대리 모델에서 발산하므로, 비선형 확률 분포를 정확히 추적하는 UKF를 적용합니다:
1. 상태 벡터 $\mathbf{x}_k \in \mathbb{R}^n$ (칩 전체 주요 블록 온도장).
2. 공분산 $\mathbf{P}_k$로부터 $2n+1$개의 시그마 포인트 $\boldsymbol{\chi}_i$ 생성:
   $$\boldsymbol{\chi}_0 = \hat{\mathbf{x}}_k, \quad \boldsymbol{\chi}_i = \hat{\mathbf{x}}_k \pm \sqrt{(n+\lambda)\mathbf{P}_k}_i$$
3. 초고속 대리 모델(PINN/ROM) $\mathbf{f}(\cdot)$을 통해 각 포인트를 미래 1스텝 전파:
   $$\boldsymbol{\chi}_{i, k+1|k} = \mathbf{f}(\boldsymbol{\chi}_{i, k}, \mathbf{u}_k)$$
4. 실제 온칩 DTS 센서 관측치 $\mathbf{z}_{k+1}$와의 잔차(Innovation)를 계산하여 최적 상태 $\hat{\mathbf{x}}_{k+1}$ 및 불확실성 $\mathbf{P}_{k+1}$ 갱신.

### 3.2 오프라인 강화학습 (Offline RL) 자율 제어
실제 칩에서 온라인 탐색(Exploration)을 수행하면 오버히팅으로 칩이 파괴될 위험이 있으므로, 사전 수집된 시뮬레이션 로그 데이터셋만을 이용해 학습하는 **보수적 Q-러닝(Conservative Q-Learning, CQL)**을 적용합니다.
- 상태 $s_t$: 현재 3D 온도장 $\hat{\mathbf{x}}_t$, 연산 큐(Queue) 대기열, 냉각수 온도.
- 행동 $a_t$: $[V_{core}, f_{core}, \dot{V}_{pump}]^T$.
- 보상 함수:
  $$r(s_t, a_t) = \text{Throughput} - w_1 \cdot \text{Power} - w_2 \cdot \max(0, T_{j,max} - 100^\circ\text{C})^2$$
- 학습된 오프라인 정책 신경망 $\pi_\theta(a|s)$은 $0.1\,\text{ms}$ 내에 최적 냉각 및 DVFS 행동을 결정합니다.

---

## ⏳ 4. 신뢰성 예지(PHM) 및 실시간 잔여 수명 (RUL) 진단

디지털 트윈은 칩이 당장 작동하더라도, 현재의 발열 패턴이 장기적인 칩 수명에 미치는 타격을 실시간 누적 평가합니다.

### 4.1 Coffin-Manson 열피로 손상 모델 (마이크로범프 및 AlN 계면)
온도 순환 $\Delta T$에 따른 소성 변형률 진폭 $\Delta \varepsilon_p$:
$$N_f = C \cdot (\Delta \varepsilon_p)^{-m} \approx C' \cdot (\Delta T)^{-m} \cdot \exp\left( \frac{E_a}{k_B T_{max}} \right)$$
- Palmgren-Miner 선형 누적 손상 법칙:
  $$D(t) = \sum_{i=1}^{K} \frac{n_i}{N_{f,i}} \quad (D=1.0 \text{ 도달 시 계면 박리 및 크랙 파괴})$$
- **잔여 유효 수명 (RUL)**:
  $$\text{RUL}(t) = \frac{1 - D(t)}{\dot{D}_{recent}}$$

### 4.2 전자기이동(EM) 및 열이동(TM) 결합 원자 고갈 진단
핫스팟 직하부 인터커넥트에서의 원자 드리프트 속도:
$$v_{drift} = \frac{D_0 \exp(-E_a/k_B T)}{k_B T} \left( Z^* e \rho J - \frac{Q^*}{T} \nabla T \right)$$
보이드 임계 부피 $V_{crit}$에 도달하기까지의 시간 $\tau_{fail}$을 실시간 적분하여 배선 단선 위험도를 운영 대시보드에 퍼센트(%)로 표시합니다.

---

## 🔗 Knowledge Connections
- [[반도체_열관리_멀티스케일_시뮬레이션_및_디지털트윈_통합_총람]] : 마스터 총람
- [[반도체 열관리 디지털 트윈 5대 핵심 아키텍처 및 구현 기술]] : 시스템 구조 및 소프트웨어 스택
- [[물리기반 차수축소모델(ROM)과 PINN 및 서스테인 AI 서베이]] : 상태 추정기에 탑재되는 실시간 대리 모델
- [[반도체 자가발열과 열폭주 메커니즘 (Self-Heating & Thermal Runaway)]] : 열폭주 방지 제어 임계치
- [[계면 물질전달과 박막 증착 및 전기도금 확산 (Mass Transfer, Thin Film Deposition & Electroplating Diffusion)]] : EM 및 TM 원자 이동 수식

*Last updated: 2026-10-07*
