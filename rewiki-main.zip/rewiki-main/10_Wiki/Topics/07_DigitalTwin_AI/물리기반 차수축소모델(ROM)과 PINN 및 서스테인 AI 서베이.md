# [[물리기반 차수축소모델(ROM)과 PINN 및 서스테인 AI 서베이]]

## 📌 Brief Summary
본 문서는 반도체 열관리 디지털 트윈의 핵심 병목인 고정밀 3D FEM 시뮬레이션의 계산 비용을 해결하기 위한 **차수축소모델(Reduced Order Modeling, ROM: POD-Galerkin), 물리정보 신경망(PINN), 신경 연산자(FNO/DeepONet), 가우시안 프로세스(GPR)의 수학적 원리, 추론 속도($< 1\,\text{ms}$), 데이터 요구량 및 정량 비교**를 다룬 기술 서베이 노트입니다.

---

## ⚡ 1. 실시간 대리 모델(Surrogate Model)의 필요성

3차원 고밀도 3D IC 및 이종 집적(Heterogeneous Integration) 패키지의 유한요소(FEM) 열해석은 $10^6 \sim 10^7$개의 격자 노드를 포함하며, 1회 과도(Transient) 해석에 **수십 분~수 시간**이 소요됩니다. 

그러나 실제 반도체 운영 환경에서의 동적 열 관리(DTM)와 폐루프 제어 루프는 **$1\text{--}10\,\text{ms}$ 이내의 실시간 응답**을 요구합니다. 따라서 고정밀 물리 시뮬레이션의 정확도를 $98\%$ 이상 유지하면서 추론 시간을 $10^5$배 단축시키는 **서스테인 AI / 차수축소(ROM) 기술**이 디지털 트윈의 핵심 엔진이 됩니다.

---

## 📐 2. 4대 핵심 대리 모델링 기법 심층 분석

```
                        [ 대리 모델링 기술 스펙트럼 ]
  [ 고전적 투영 기반 ROM ]                           [ 순수 데이터 기반 AI ]
       (POD-Galerkin)                                      (MLP, CNN)
             │                                                 │
             └─────────────► [ 물리기반 AI (Physics-AI) ] ◄────┘
                               - PINN (물리정보 신경망)
                               - FNO (푸리에 신경 연산자)
                               - GPR (가우시안 프로세스)
```

---

### 2.1 고전적 차수축소: POD-Galerkin (Proper Orthogonal Decomposition)
- **수학적 원리**:
  1. $N$개의 시간/조건별 3D 온도장 스냅샷 행렬 $\mathbf{S} = [\mathbf{T}_1, \mathbf{T}_2, \dots, \mathbf{T}_N] \in \mathbb{R}^{M \times N}$ 구축 ($M \sim 10^6$: 격자수).
  2. 특이값 분해(SVD): $\mathbf{S} = \mathbf{U} \boldsymbol{\Sigma} \mathbf{V}^T$ 수행 후, 에너지가 큰 상위 $r$개의 직교 기저 벡터 $\boldsymbol{\Phi} = [\mathbf{u}_1, \dots, \mathbf{u}_r] \in \mathbb{R}^{M \times r}$ ($r \ll M$, 보통 $r \approx 10\text{--}30$) 선택.
  3. 온도장을 기저의 선형 결합으로 축소 근사: $\mathbf{T}(t) \approx \boldsymbol{\Phi} \mathbf{a}(t)$.
  4. 거대 열전도 지배 행렬식 $\mathbf{C} \dot{\mathbf{T}} + \mathbf{K} \mathbf{T} = \mathbf{F}$에 Galerkin 투영:
     $$(\boldsymbol{\Phi}^T \mathbf{C} \boldsymbol{\Phi}) \dot{\mathbf{a}}(t) + (\boldsymbol{\Phi}^T \mathbf{K} \boldsymbol{\Phi}) \mathbf{a}(t) = \boldsymbol{\Phi}^T \mathbf{F}(t)$$
     $$\implies \mathbf{C}_r \dot{\mathbf{a}}(t) + \mathbf{K}_r \mathbf{a}(t) = \mathbf{F}_r(t) \quad (r \times r \text{ 크기의 극소형 연립방정식})$$
- **장점**: 엄밀한 수학적 오차 상한 보장, 물리량 보존성 $100\%$.
- **한계**: 비선형 물성($k(T)$)이나 복잡한 경계조건 변화 시 기저 재구성이 필요.

---

### 2.2 물리정보 신경망: PINN (Physics-Informed Neural Networks)
- **수학적 원리**:
  신경망 $\mathcal{N}_\theta(\mathbf{x}, t) \approx T(\mathbf{x}, t)$을 구성하고, 자동 미분(Automatic Differentiation, AD)을 통해 열전도 편미분방정식(PDE) 잔차를 손실함수에 직접 부과:
  $$\mathcal{L}_{total}(\theta) = w_{data}\mathcal{L}_{data} + w_{pde}\mathcal{L}_{pde} + w_{bc}\mathcal{L}_{bc}$$
  $$\mathcal{L}_{pde} = \frac{1}{N_{pde}} \sum_{i=1}^{N_{pde}} \left\| \rho c_p \frac{\partial \hat{T}}{\partial t} - \nabla \cdot (k \nabla \hat{T}) - \dot{q} \right\|^2_{\mathbf{x}_i, t_i}$$
- **반도체 디지털 트윈에서의 혁신적 가치**:
  - **희소 센서 보간(Sparse Sensor Inversion)**: 실물 칩 표면에 온도 센서가 단 4~8개만 존재하더라도, 내부 실리콘 층 전 영역에서 열전도 PDE를 만족하는 유일한 3D 온도 분포를 수학적으로 역추정 복원 가능.
  - 비선형 열전도도 $k(T) = \frac{1}{a + bT}$를 자연스럽게 수용.

---

### 2.3 신경 연산자: FNO (Fourier Neural Operator) & DeepONet
- **수학적 원리**:
  단순한 입력 벡터 간의 매핑이 아닌, **무한 차원 함수 공간 간의 연산자(Operator) 매핑**:
  $$\mathcal{G}_\theta: \dot{q}(x, y, z) \longmapsto T(x, y, z)$$
  - FNO는 푸리에 공간에서 합성곱(Convolution)을 수행하여 전역적(Global) 열확산 패턴을 포착:
    $$\mathbf{v}_{l+1}(\mathbf{x}) = \sigma \left( \mathbf{W} \mathbf{v}_l(\mathbf{x}) + \mathcal{F}^{-1} \left( \mathbf{R} \cdot \mathcal{F}(\mathbf{v}_l) \right)(\mathbf{x}) \right)$$
- **장점**:
  - **메쉬 비의존성(Zero-shot Super-resolution)**: 거친 격자에서 학습한 모델이 고밀도 미세 격자에서도 재학습 없이 즉각 고해상도 온도장 출력.
  - 다양한 발열 맵(Power Map) 변화에 대해 단 **$0.2\,\text{ms}$**의 추론 속도 달성.

---

### 2.4 가우시안 프로세스 회귀: GPR (Gaussian Process Regression)
- **수학적 원리**:
  커널 함수(RBF, Matérn) 기반 비모수 베이지안 회귀:
  $$T(\mathbf{x}) \sim \mathcal{GP}\left( m(\mathbf{x}), k(\mathbf{x}, \mathbf{x}') \right)$$
  예측값과 함께 예측의 **사후 분산(불확실성, $\sigma^2(\mathbf{x})$)**을 동시 산출.
- **역할**: 디지털 트윈의 안전 모니터링(예측 불확실성이 큰 비정상 발열 상태 탐지) 및 능동 학습(Active Learning) 탐색 기준.

---

## 📊 3. 4대 대리 모델링 기법 정량 비교표

| 평가 항목 | POD-Galerkin (ROM) | PINN | FNO / DeepONet | GPR (베이지안) |
| :--- | :--- | :--- | :--- | :--- |
| **추론 속도 (Latency)** | $\sim 1\text{--}5\,\text{ms}$ | $\sim 0.5\text{--}1\,\text{ms}$ | **$< 0.2\,\text{ms}$ (초고속)** | $\sim 2\text{--}10\,\text{ms}$ |
| **오프라인 학습 시간** | 없음 (SVD 1회, 수 분) | 수 시간 (GPU 최적화) | 수 시간~수일 | 수 분 (데이터 $N<10^3$) |
| **필요 데이터 수** | 중규모 스냅샷 ($10^2$) | 무데이터(PDE만으로 가능) | 대규모 시뮬레이션 ($10^3\text{--}10^4$) | 극소규모 ($10\text{--}500$) |
| **물리 법칙 보존성** | $100\%$ (투영 기반) | 매우 높음 (손실함수 강제) | 중간 (데이터 분포 기반) | 낮음 (통계적 상관관계) |
| **불확실성 정량화** | 잔차 기반 가능 | 불가 (별도 앙상블 필요) | 불가 (별도 UQ 필요) | **자체 내장 ($\pm 2\sigma$)** |
| **반도체 디지털 트윈 주 적용처** | 선형 구조/열해석 축소 | 희소 센서 기반 3D 역복원 | 다양한 파워맵 실시간 열해석 | 공정창 최적화 & 이상 진단 |

---

## 🔗 Knowledge Connections
- [[반도체_열관리_멀티스케일_시뮬레이션_및_디지털트윈_통합_총람]] : 마스터 총람
- [[반도체 열관리 디지털 트윈 5대 핵심 아키텍처 및 구현 기술]] : 디지털 트윈 아키텍처
- [[동적 전력-열 관리(DTPM)와 폐루프 제어 및 잔여수명(RUL) 예측]] : 대리 모델을 탑재한 실시간 제어
- [[반도체_공정_머신러닝_종류_적용방법_및_데이터규모별_학습이론_총람]] : 데이터 규모별 ML/PINN 이론
- [[전달현상 지배방정식과 나비에-스톡스-에너지-연속 방정식 (Navier-Stokes & Energy Equation)]] : PINN 손실함수의 원형 PDE

*Last updated: 2026-10-07*
