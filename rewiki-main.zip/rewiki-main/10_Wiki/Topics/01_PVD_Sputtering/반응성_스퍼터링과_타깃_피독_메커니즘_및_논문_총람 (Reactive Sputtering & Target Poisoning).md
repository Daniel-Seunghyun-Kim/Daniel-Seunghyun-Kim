# [[반응성_스퍼터링과_타깃_피독_메커니즘_및_논문_총람 (Reactive Sputtering & Target Poisoning)]]

## 📌 Brief Summary
본 문서는 AlN, TiN, $\text{Al}_2\text{O}_3$ 등 화합물 박막 증착의 핵심 PVD 공정인 **반응성 스퍼터링(Reactive Sputtering)과 타깃 피독(Target Poisoning) 간의 비선형 결합 메커니즘, Berg 모델에 기초한 히스테리시스(Hysteresis) 물리, 아킹(Arcing) 이상 방전 현상, PEM 기반 폐루프 공정 제어, 그리고 고전부터 2026년 최신 문헌까지의 핵심 학술 논문군**을 집대성한 종합 총람입니다.

---

## ⚗️ 1. 반응성 스퍼터링과 타깃 피독의 본질적 상관관계

금속 타깃(예: 고순도 Al)에 비활성 스퍼터 가스(Ar)와 반응성 가스($\text{N}_2$ 또는 $\text{O}_2$)를 동시에 주입하여 화합물 박막(AlN)을 합성하는 반응성 마그네트론 스퍼터링에서, **타깃 피독(Target Poisoning)은 반응성 가스 분압 증가에 따라 타깃 표면이 순수 금속에서 절연성 화합물층으로 변질되는 현상**입니다.

```
[반응 가스 N2 유량 증가] ──► [타깃 표면에 AlN 화합물층 형성 (Target Poisoning)]
                                       │
      ┌────────────────────────────────┴────────────────────────────────┐
      ▼                                                                 ▼
[스퍼터 수율 Y 폭락 (Y_AlN << Y_Al)]                        [타깃 표면 전하 축적 (절연체)]
      │                                                                 │
      ▼                                                                 ▼
[증착 속도 Deposition Rate 1/5~1/10 급감]                  [마이크로 아킹 Micro-arcing 발생]
      │                                                                 │
      └────────────────────────────────┬────────────────────────────────┘
                                       ▼
             [비선형 히스테리시스 루프 (Hysteresis Loop) 형성]
```

### 1.1 3대 작동 모드와 히스테리시스 거동
1. **금속 모드 (Metallic Mode, 낮은 $Q_{N2}$)**:
   - 주입된 질소 분자가 챔버 벽면 및 기판에 증착되는 순수 Al 원자에 의해 전부 게터링(Gettering)되어 소비됨.
   - 타깃 표면은 순수 Al 상태를 유지하므로 스퍼터 수율이 높고 증착 속도가 매우 빠름.
   - **단점**: 질소 결핍 상태(Sub-stoichiometric $\text{AlN}_{1-x}$) 박막 형성 $\to$ 불량한 절연 및 결정성.
2. **천이 모드 (Transition Mode, 임계 유량 영역)**:
   - 양론비(Stoichiometric AlN) 박막이 형성되는 최적의 공정창(Process Window).
   - 그러나 비선형 양의 피드백(Positive Feedback)으로 인해 매우 불안정하여, 외부 제어 없이는 순식간에 피독 모드로 전락함.
3. **피독 모드 / 화합물 모드 (Poisoned / Compound Mode, 높은 $Q_{N2}$)**:
   - 타깃 표면 전체가 AlN 화합물층으로 덮임.
   - 화합물의 스퍼터 수율($Y_{compound}$)은 순수 금속 수율($Y_{metal}$)보다 $1/5 \sim 1/10$ 수준으로 낮음 ($Y_{AlN} \ll Y_{Al}$).
   - 타깃에서 튀어나오는 Al 원자 수가 급감하여 질소를 게터링하지 못하므로, 챔버 내 잔류 질소 분압이 수직 상승함.
   - **비가역성**: 질소 유량을 다시 줄여도 타깃 표면의 AlN 층이 완전히 스퍼터되어 벗겨질 때까지 금속 모드로 돌아가지 않아 **히스테리시스 루프**가 발생.

---

## 📐 2. 버그 모델 (Berg's Model)의 수학적 정식화

S. Berg 교수가 1987년 정립한 반응성 스퍼터링의 세계 표준 정상상태 질량 보존 방정식입니다.

### 2.1 타깃 표면 화합물 피복률 ($\theta_t$)
타깃 표면($A_t$)에서 화합물이 차지하는 분율 $\theta_t$ ($0 \le \theta_t \le 1$):
$$\frac{d\theta_t}{dt} = 2 \alpha_t F (1 - \theta_t) - \frac{J}{e} Y_c \theta_t = 0 \quad (\text{정상상태})$$
$$\implies \theta_t = \frac{2 \alpha_t F}{2 \alpha_t F + \frac{J}{e} Y_c}$$
- $\alpha_t$: 타깃 표면 반응성 가스 부착 계수 (Sticking coefficient)
- $F$: 반응성 가스 분자 플럭스 ($F = \frac{P_{reactive}}{\sqrt{2\pi m k_B T}}$)
- $J$: 타깃 이온 전류 밀도, $Y_c$: 화합물 스퍼터 수율

### 2.2 기판/벽면 게터링 및 총 질량 보존
타깃에서 방출된 금속 플럭스가 기판 및 챔버 벽면($A_s$)에 도달하여 반응성 가스를 소모하는 게터링 면적 피복률 $\theta_s$:
$$Q_{in} = Q_{pump} + Q_{target} + Q_{substrate/wall}$$
$$Q_{in} = S_p P + \alpha_t F (1 - \theta_t) A_t + \alpha_s F (1 - \theta_s) A_s$$
- $S_p$: 진공 펌프 배기 속도.
- 타깃이 피독되면 $A_s$에 도달하는 금속 플럭스가 급감하여 게터링 소비량($Q_{substrate}$)이 0에 수렴 $\to$ 잔류 압력 $P$의 급격한 불연속 점프(Hysteresis Jump) 발생.

---

## ⚡ 3. 피독 상태에서의 아킹(Arcing) 및 방전 불안정성

AlN이나 $\text{Al}_2\text{O}_3$ 같은 절연체 화합물이 타깃 표면에 형성되면 DC 스퍼터링 시 심각한 방전 파괴가 일어납니다.

1. **전하 축적 (Charge Accumulation)**:
   - 절연층에 양이온($\text{Ar}^+$)이 충돌하면서 전하가 빠져나가지 못하고 국소적으로 축적됨.
2. **절연 파괴 및 마이크로 아킹 (Micro-Arcing)**:
   - 절연 박막의 전계가 유전 파괴 강도($> 10^6\,\text{V/cm}$)를 초과하여 국소 아크 방전 발생.
   - 아크 충격으로 타깃 표면에서 거대 액적(Droplet / Flake)이 비산되어 증착 중인 박막에 핀홀 및 파티클 결함 유발.
3. **해결 솔루션**:
   - **Pulsed DC Sputtering (중주파 펄스 DC)**: $50\sim 350\,\text{kHz}$ 주파수로 전압을 주기적으로 역전(Reverse bias $+10\sim +50\,\text{V}$)시켜 전자를 끌어당겨 축적된 양전하를 실시간 중화.
   - **RF Magnetron Sputtering (13.56 MHz)**: 완벽한 자기 바이어스 형성으로 절연 파괴 억제.

---

## 📚 4. 타깃 피독 및 반응성 스퍼터링 핵심 논문군 총람

### 4.1 고전적 기초 이론 및 모델링 논문 (Foundational Berg Model)
1. **Berg et al. (1987)**, *J. Vac. Sci. Technol. A* 5, 202:
   - *"Modeling of reactive sputtering of compound materials"*
   - 반응성 가스 분압-유량 히스테리시스를 표면 피복률과 게터링으로 설명한 최초의 수학적 모델.
2. **Berg & Nyberg (2005)**, *Thin Solid Films* 476, 215:
   - *"Fundamental understanding and modeling of reactive sputtering"*
   - 20년간의 버그 모델 확장판. 타깃 피독의 다원계(Multicomponent) 시스템 및 동적 거동 총정리.
3. **Depla & Gryse (2004)**, *Surf. Coat. Technol.* 183, 184 / **Depla et al. (2006)**:
   - *"Target poisoning during reactive magnetron sputtering: Part I & II"*
   - 단순 표면 흡착을 넘어, 고에너지 반응성 이온의 타깃 내부 주입(Implantation)과 녹아웃(Knock-out) 현상을 규명한 RSD (Reactive Sputter Deposition) 모델 정립.

### 4.2 아킹 방지 및 고속 펄스 공정 논문 (Pulsed DC & PEM Control)
4. **Schiller, Goedicke et al. (1993)**, *Surf. Coat. Technol.* 61, 331:
   - *"Pulsed magnetron sputtering: a new technique for long-term stable deposition of highly insulating stoichiometric films"*
   - 반응성 스퍼터링 시 중주파 펄스 방전을 통한 아킹 방지 기술 최초 실용화.
5. **Sproul et al. (2005)**, *Thin Solid Films* 491, 1:
   - *"Control of reactive sputtering processes"*
   - 플라즈마 발광 분석기(PEM: Plasma Emission Monitoring)를 이용한 광학 피드백 제어로 천이 모드(Transition Mode) 고속 증착 유지 기술 정립.
6. **Musil et al. (2000)**, *Surf. Coat. Technol.* 125, 322:
   - *"Unbalanced and pulsed magnetron sputtering"*
   - 반응성 스퍼터링 박막의 응력 제어 및 결정성 제어.

### 4.3 AlN 특화 반응성 스퍼터링 및 열전도도 연계 논문 (AlN Sputtering Literature)
7. **Ishihara et al. (1998)**, *Thin Solid Films* 316, 152:
   - *"High-rate deposition of AlN thin films by DC reactive sputtering"*
   - $\text{N}_2$ 분압과 타깃-기판(T-S) 거리가 타깃 피독 상태 및 AlN (002) c-축 배향성에 미치는 영향 규명.
8. **Iriarte et al. (2010)**, *J. Cryst. Growth* 312, 2769:
   - *"Effect of process parameters on the c-axis orientation of AlN thin films"*
   - 2~3 mTorr 극저압 공정창에서 타깃 피독 직전의 천이 모드 최적화로 고결정성 AlN 확보.
9. **Vaziri et al. (2025)**, *Adv. Funct. Mater.*:
   - *"Ultralow-Temperature DC Sputtered AlN Thin Films with High Thermal Conductivity"*
   - $200^\circ\text{C}$ 이하 저온 DC 반응성 스퍼터링에서 타깃 상태 제어를 통해 박막 열전도도 $K_\perp \approx 90\text{--}92\,\text{W/mK}$ 달성 실증.

---

## 📊 5. 타깃 상태별 공정 파라미터 대조표

| 타깃 상태 | 질소 분압 ($P_{N2}$) | 방전 전압 ($V_{target}$) | 증착 속도 (Rate) | 박막 화학조성 | 결정성 및 열전도도 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **금속 모드 (Metallic)** | 극히 낮음 ($< 10^{-5}\,\text{Torr}$) | 높음 (금속 $\gamma_{se}$ 기준) | 최고 ($100\%$) | 금속 과잉 ($\text{Al}$-rich) | 비정질/금속성, 절연성 파괴 |
| **천이 모드 (Transition)** | 중간 (임계 문턱치) | 급변 구간 | 중간 ($40\sim 60\%$) | **이상적 화학양론비 (Al:N = 1:1)** | **고결정성 (002) 배향, 최고 열전도도** |
| **피독 모드 (Poisoned)** | 급상승 ($> 10^{-3}\,\text{Torr}$) | 강하 또는 상승 (화합물 물성 의존) | 최저 ($10\sim 20\%$) | 질소 과잉 ($\text{N}$-rich AlN) | 결정립 미세화, 마이크로 아크 결함 다발 |

---

## 🔗 Knowledge Connections
- [[스퍼터링 PVD 공정의 기본 원리와 플라즈마 (Sputtering & Plasma Basics)]] : PVD 플라즈마 기초
- [[Wurtzite AlN 결정성 및 포논 수송 메커니즘]] : 반응성 스퍼터링으로 성장된 AlN 결정성
- [[3단계_신규테마_AlN_표면전달성_및_저온본딩_연구설계서]] : DOE 직교배열 표면 조도 및 스퍼터 파라미터
- [[반도체_나노열관리_전체_지식노트_주제별_연계_클러스터_총람 (Knowledge Concept Clusters)]] : 전체 볼트 지식 클러스터링

*Last updated: 2026-10-07*
