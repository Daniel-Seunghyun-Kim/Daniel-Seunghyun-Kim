# [[타깃_피독_물리화학_메커니즘_및_재료_영향_분석 (Target Poisoning Physics)]]

## 📌 Brief Summary
본 문서는 스퍼터링 공정에서 타깃 피독(Target Poisoning)이 발생하는 **원자단위 표면/서브서피스(Sub-surface) 물리화학 기작, 금속 vs 화합물 간 결합에너지($U_0$)와 스퍼터 수율($Y$) 폭락 메커니즘, 이차전자 방출 계수($\gamma_{se}$) 변화에 따른 방전 임피던스 변동, 그리고 마그네트론 레이스웨이(Raceway)의 국소 불균일 피독 거동**을 정밀 분석한 전문 지식 노트입니다.

---

## 🔬 1. 타깃 피독의 2대 원자적 메커니즘: 흡착 vs 이온 주입

타깃 피독은 단순한 기체 분자의 화학 흡착(Chemisorption)에 국한되지 않으며, 플라즈마 양이온 충돌에 의한 복합 현상입니다. (D. Depla et al., RSD 모델)

```
       [ 경로 1: 화학 흡착 (Chemisorption) ]
       N2 분자 ──► 타깃 최외각 1개 원자층 (Monolayer) 해리 흡착

       [ 경로 2: 반응성 이온 주입 (Reactive Ion Implantation) ]
       N+ / N2+ 이온 (300~500 eV) ──► 타깃 격자 내부 1~5 nm 깊이 투입 ──► Sub-surface 피독층 형성
```

1. **표면 화학 흡착**:
   - 타깃 표면의 미결합 금속 원자와 비행 중인 반응성 가스 분자가 충돌하여 화학 반응:
     $$\text{Al (surface)} + \frac{1}{2}\text{N}_2 \longrightarrow \text{AlN (surface)} \quad (\Delta H_f^\circ = -318\,\text{kJ/mol})$$
   - 자발적인 강한 발열 반응으로 타깃 최상층에 단분자층(Monolayer) 화합물 형성.
2. **반응성 이온 주입 (Ion Implantation)**:
   - 플라즈마 쉬스(Sheath) 전압($300\sim 600\,\text{V}$)에 의해 가속된 $\text{N}^+$ 및 $\text{N}_2^+$ 이온이 타깃 격자 내부로 충돌 진입.
   - 침투 깊이(Projected Range) $R_p \approx 1\text{--}3\,\text{nm}$ 영역에 질소 원자가 박혀 격자 내에서 금속 원자와 결합하여 **수 나노미터 두께의 서브서피스 화합물층**을 형성.

---

## 📉 2. 스퍼터 수율 ($Y$) 폭락의 물리: 결합 에너지 ($U_0$) 차이

지그문트(Sigmund)의 선형 충돌 캐스케이드(Collision Cascade) 이론에 따르면, 수직 입사 이온에 의한 스퍼터 수율 $Y$는 표면 결합 에너지(Surface Binding Energy, $U_0$)에 반비례합니다:
$$Y(E) = \frac{3}{4\pi^2} \frac{\alpha S_n(E)}{U_0}$$
- $S_n(E)$: 탄성 핵 저지능 (Nuclear Stopping Power)
- $U_0$: 원자가 표면을 탈출하기 위해 극복해야 하는 승화열/결합 에너지

```
  [순수 Al 금속 타깃]  금속 결합 (Al-Al)  ──► 결합 에너지 U_0 ≈ 3.39 eV ──► Y_Al ≈ 1.15 atoms/ion
  [피독된 AlN 타깃]   공유/이온 결합 (Al-N) ──► 결합 에너지 U_0 ≈ 11.5 eV  ──► Y_AlN ≈ 0.18 atoms/ion
```
- **스퍼터 수율 85% 이상 폭락**:
  타깃 표면이 질화(피독)되는 순간 표면 원자를 뜯어내는 데 필요한 에너지가 3배 이상 증가하므로, 동일한 $\text{Ar}^+$ 이온 전류가 부딪혀도 방출되는 Al 원자 플럭스가 **$1/6 \sim 1/10$로 급감**합니다.

---

## ⚡ 3. 이차전자 방출 계수 ($\gamma_{se}$)와 플라즈마 전압 거동

타깃에 이온이 충돌할 때 튀어나오는 전자(Secondary Electron)의 비율 $\gamma_{se}$는 플라즈마 유지 및 타깃 방전 전압을 결정합니다.

1. **타깃 음전압 공식 ($V_{target}$)**:
   정전력(Constant Power) 스퍼터링 전원 구동 시:
   $$I_{discharge} = I_{ion} (1 + \gamma_{se}) \quad \implies \quad V_{target} = \frac{P_{discharge}}{I_{ion} (1 + \gamma_{se})}$$
2. **재료별 거동 차이**:
   - **산화물 스퍼터링 ($\text{Al}_2\text{O}_3$, $\text{TiO}_2$)**:
     - 금속보다 산화물의 $\gamma_{se}$가 훨씬 큼 ($\gamma_{se, oxide} \gg \gamma_{se, metal}$).
     - 피독 시 방전 전류 $I$가 증가하므로, 동일 전력 공급 시 **타깃 전압 $|V_{target}|$이 $50\sim 150\,\text{V}$ 급감(Drop)**.
   - **질화물 스퍼터링 (AlN, TiN)**:
     - AlN의 경우 유전율 및 밴드갭 특성에 따라 전압이 상승하거나 감소하는 특이 변곡점을 형성하므로, **타깃 전압 변화를 실시간 타깃 피독 감지 센서(In-situ Sensor)**로 활용 가능.

---

## 🎯 4. 레이스웨이 (Raceway)의 공간적 불균일 피독

마그네트론 영구자석 배열로 인해 타깃 표면의 이온 충돌 밀도는 균일하지 않습니다.

```
       [ Non-erosion Zone (외곽) ]  ──► 플라즈마 밀도 낮음 ──► 100% 완전 피독 (두꺼운 AlN 형성)
       [ Raceway Erosion Track (중앙) ]──► 초고밀도 Ar+ 스퍼터 ──► 금속/천이 상태 유지 (지속적 에칭)
       [ Non-erosion Zone (중심) ]  ──► 플라즈마 밀도 낮음 ──► 100% 완전 피독 (두꺼운 AlN 형성)
```
- **불균일 피독의 악영향**:
  레이스웨이 중심부는 강력한 스퍼터링으로 금속 표면이 드러나 있지만, 스퍼터링 침식이 덜 일어나는 **타깃 외곽 및 중심 비침식 영역(Non-erosion area)은 완전히 피독되어 두꺼운 절연체 화합물이 누적**됩니다.
- 이 비침식 영역의 두꺼운 절연막에서 전하 축적에 의한 **기생 마이크로 아킹(Parasitic Arcing)**이 집중 발생하여 파티클의 주 공급원이 됩니다.

---

## 🔗 Knowledge Connections
- [[반응성_스퍼터링과_타깃_피독_메커니즘_및_논문_총람 (Reactive Sputtering & Target Poisoning)]] : 마스터 총람
- [[반응성_스퍼터링_공정제어_및_히스테리시스_극복_기술 (Reactive Sputtering Process Control)]] : 피독 제어를 위한 PEM 기술
- [[스퍼터링 PVD 공정의 기본 원리와 플라즈마 (Sputtering & Plasma Basics)]] : Sigmund 스퍼터링 이론 기초
- [[Wurtzite AlN 결정성 및 포논 수송 메커니즘]] : AlN 반응성 증착 박막의 포논 결정성

*Last updated: 2026-10-07*
