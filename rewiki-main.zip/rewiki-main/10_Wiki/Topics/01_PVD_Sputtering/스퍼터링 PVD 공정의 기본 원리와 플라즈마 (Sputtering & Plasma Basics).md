# [[스퍼터링 PVD 공정의 기본 원리와 플라즈마 (Sputtering & Plasma Basics)]]

## 📌 Brief Summary
스퍼터링(Sputtering)은 물리 기상 증착(Physical Vapor Deposition, PVD)의 대표적인 방식으로, 진공 챔버 내에서 불활성 가스(주로 아르곤, Ar)를 이온화하여 생성된 고에너지 플라즈마 이온이 음극 타깃(Target)을 물리적으로 강타할 때, 타깃 원자가 튀어나와(Sputtered) 대향하는 기판(Substrate)에 증착되어 박막을 형성하는 고진공 박막 제조 공정입니다.

## 📖 Core Content

### 1. 직관적 이해: 당구공 충돌 비유
- 큐대로 흰 공(고에너지 $\text{Ar}^+$ 이온)을 강하게 쳐서 당구대 위의 모여 있는 공(타깃 금속/세라믹 원자)을 맞히면, 맞은 공들이 사방으로 튕겨 나가는 탄성 충돌 과정입니다.
- 튕겨 나온 타깃 원자들이 날아가 맞은편 기판 표면에 달라붙어 원자 한 층 한 층 고밀도 박막을 쌓아 올립니다.

### 2. 스퍼터링 공정의 4대 핵심 구성 요소
1. **고진공 챔버 (Base Pressure):** 불순물 산소 및 수분을 배제하기 위해 초기 기저 진공도를 $10^{-6} \sim 10^{-7}\,\text{Torr}$ 수준으로 배기.
2. **플라즈마 방전 가스 (Working Gas):**
   - 불활성 가스: 아르곤(Ar, 압력 $1 \sim 10\,\text{mTorr}$).
   - 반응성 가스(질화물 증착 시): 질소($\text{N}_2$)를 혼합하여 반응성 스퍼터링(Reactive Sputtering) 수행 $\rightarrow \text{Al} + \frac{1}{2}\text{N}_2 \to \text{AlN}$.
3. **타깃 음극(Cathode)과 마그네트론(Magnetron):**
   - 타깃 뒤편에 영구자석을 배치하여 로렌츠 힘($\mathbf{F} = q(\mathbf{E} + \mathbf{v} \times \mathbf{B})$)으로 전자를 타깃 표면에 나선형으로 포획(Trap).
   - 플라즈마 이온화율을 수백 배 증가시켜 저압에서도 고속 증착을 실현.
4. **전원 방식:**
   - DC 스퍼터링: 전기 전도성이 있는 금속(Cu, Ti, Al) 증착에 적용.
   - RF 스퍼터링 (13.56 MHz): 전하 축적(Charging effect)을 방지하여 세라믹 절연체(AlN, $\text{SiO}_2$) 증착에 필수.

### 3. 기판 바이어스(Substrate Bias)와 재스퍼터링(Resputtering) 메커니즘
- 일반 평면 스퍼터링은 입사 방향이 수직에 가까워 고종횡비 나노필러의 측벽 피복(Step coverage)이 매우 취약함(그늘 효과, Shadowing).
- **RF 기판 바이어스 인가 (15~30 W):**
  - 기판 쪽에 음의 직류 자기 바이어스($V_{\text{bias}}$)를 유도하여, 플라즈마 내 $\text{Ar}^+$ 이온을 수직으로 가속시켜 기판을 때리게 만듦.
  - 나노필러 상단 모서리에 과도하게 쌓인 AlN을 모서리 효과로 강하게 **재스퍼터링(Resputtering)**하여 튕겨내고, 튕겨난 원자가 수직 측벽으로 날아가 **물리적 재분포(Redistribution)**됨.
  - 이 독창적 기법을 통해 승현 연구원님의 연구에서 **기판 틸트 없이 측벽 스텝 커버리지 $>85\%$**를 달성함.

## 🔗 Knowledge Connections
- **Parent/Higher Topic:** [[반도체_나노열관리_마인드맵_총괄_지식지도]]
- **Sub-Concepts:** [[Wurtzite AlN 결정성 및 포논 수송 메커니즘]]
- **Advanced Transition:** [[저온 직접 접합 및 플라즈마 표면 활성화]], [[비휘발성 금속 식각과 재증착 제어 (Non-volatile Metal Etching & Redeposition)]]

---
*Last updated: 2026-10-07*
