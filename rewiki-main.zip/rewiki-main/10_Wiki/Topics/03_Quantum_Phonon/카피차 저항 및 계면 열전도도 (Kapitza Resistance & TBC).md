# [[카피차 저항 및 계면 열전도도 (Kapitza Resistance & TBC)]]

## 📌 Brief Summary
카피차 저항(Kapitza Resistance, $R_K$) 또는 열경계 저항(Thermal Boundary Resistance, TBR)은 서로 다른 두 물질의 접합 계면에서 음향 포논의 격자 진동 불일치(Acoustic Mismatch) 및 비탄성 산란으로 인해 열류 통과 시 불연속적인 온도 강하($\Delta T$)가 발생하는 미시 계면 현상입니다. 그 역수를 계면 열전도도(Thermal Boundary Conductance, TBC 또는 $G$)라고 부릅니다.

## 📖 Core Content

### 1. 기본 관계식 및 물리적 정의
접합 계면을 통과하는 열유속 $q''$과 계면 양단에서의 온도 불연속 강하 $\Delta T_{\text{interface}}$의 선형 관계:
$$q'' = G \cdot \Delta T_{\text{interface}} = \frac{1}{\text{TBR}} \Delta T_{\text{interface}}$$
- 단위:
  - $\text{TBC}\ (G): \text{MW}/(\text{m}^2\cdot\text{K})$ 또는 $\text{W}/(\text{m}^2\cdot\text{K})$
  - $\text{TBR}\ (R_K): \text{m}^2\cdot\text{K}/\text{GW}$ 또는 $\text{m}^2\cdot\text{K}/\text{W}$

### 2. 고전적 계면 투과율 예측 모델 (AMM vs DMM)
1. **음향 불일치 모델 (Acoustic Mismatch Model, AMM):**
   - 계면이 원자 수준에서 완벽하게 평탄(Specula interface)하여 포논이 굴절 및 반사 법칙(스넬의 법칙)을 그대로 따른다고 가정.
   - 포논 투과 확률 $\alpha_{1 \to 2}$:
     $$\alpha_{1 \to 2} = \frac{4 Z_1 Z_2 \cos \theta_1 \cos \theta_2}{(Z_1 \cos \theta_2 + Z_2 \cos \theta_1)^2}$$
     (여기서 $Z = \rho v$는 음향 임피던스). 극저온($< 30\,\text{K}$)에서만 성립.
2. **확산 불일치 모델 (Diffuse Mismatch Model, DMM):**
   - 상온 이상에서는 계면의 거칠기 및 원자 무질서도로 인해 포논이 계면에서 모든 방향으로 완전히 난반사(Diffusive scattering)된다고 가정.
   - 포논 상태밀도(DOS, Density of States)의 중첩도에 따라 투과율 결정:
     $$\alpha_{1 \to 2} = \frac{\sum_j v_{2,j} D_2(\omega)}{\sum_j v_{1,j} D_1(\omega) + \sum_j v_{2,j} D_2(\omega)}$$

### 3. 비대칭 계면 전도도 ($G_1 \neq G_2$)의 실제적 중요성
- 샌드위치 구조($\text{Si} / \text{AlN} / \text{Si}$)나 3D 본딩 구조에서:
  - 하부 계면 ($G_1$): 기판 위에 직접 스퍼터/ALD로 증착되어 화학 결합이 강함 ($G_1 \approx 95 \sim 150\,\text{MW/m}^2\text{K}$).
  - 상부 계면 ($G_2$): 기계적 접합 및 열압착(Bonding)을 거치며 미세 보이드나 산화막이 개재되어 결합력이 다름 ($G_2 \approx 25 \sim 105\,\text{MW/m}^2\text{K}$).
- 문헌 실측치 (Nieminen et al., 2024): $720\,\text{nm}$ 스퍼터 AlN-Si 직접 접합에서 $G_1 = 95 \pm 19$, $G_2 = 105 \pm 17\,\text{MW/m}^2\text{K}$로 명확히 분리 보고됨.

### 4. 나노박막에서의 계면 지배 현상 (Interface Dominance)
총 등가 박막 저항:
$$R_{\text{total}} = \frac{1}{G_1} + \frac{t}{k(t)} + \frac{1}{G_2}$$
- 고열전도성 AlN의 경우 박막 두께 $t \le 100\,\text{nm}$에서 체적 저항($t/k$)이 전체의 $10\%$ 미만에 불과하며, **계면 저항($1/G_1 + 1/G_2$)이 전체 열저항의 $90\%$ 이상을 지배**함.
- 따라서 AlN 연구의 본질은 "박막 열전도도 향상"이 아니라 **"계면 결함 제어 및 TBC 극대화(Surface Activation)"**에 있음.

## 🔗 Knowledge Connections
- **Related Topics:** [[포논 볼츠만 수송 방정식 (BTE)]], [[Wurtzite AlN 결정성 및 포논 수송 메커니즘]], [[저온 직접 접합 및 플라즈마 표면 활성화]]
- **Projects/Contexts:** [[01_Literature_Verification_Report]], [[Reserach1_향후_연구개발_계획서]]
- **Contradictions/Notes:**
  - 통상적인 시뮬레이션에서는 계면을 연속체($T_1 = T_2$)로 가정하여 Kapitza 점프를 누락시키는 치명적 오류를 범함.

---
*Last updated: 2026-10-07*
