# [[크누센 수와 탄도 열수송 (Knudsen Number & Ballistic Transport)]]

## 📌 Brief Summary
크누센 수(Knudsen Number, $\mathrm{Kn}$)는 열 운반체(포논 또는 전자)의 평균 자유 행로($\Lambda$)와 시스템의 물리적 특성 길이($L$)의 비율입니다. $\mathrm{Kn} \ll 0.1$인 거시 세계에서는 입자들이 무수히 충돌하며 '확산(Diffusion)'하지만, $\mathrm{Kn} \gg 0.1$인 나노스케일에서는 입자가 충돌 없이 직진하는 **탄도 수송(Ballistic Transport)**이 지배하여 기존 푸리에 열전도 법칙이 완전히 붕괴합니다. 2000년대 Gang Chen 교수의 나노 열전달 연구로 정립되었습니다.

## 📖 Core Content

### 1. 크누센 수의 수학적 정의와 3대 수송 영역
$$\mathrm{Kn} = \frac{\Lambda}{L}$$
- **$\mathrm{Kn} < 0.1$ (확산 영역, Diffusive Regime):**
  - 입자 간의 충돌 거리가 박막 두께보다 훨씬 짧음.
  - 열류는 국소적인 온도 구배에 비례함: $q'' = -k \nabla T$ (푸리에 법칙 성립).
- **$0.1 \le \mathrm{Kn} \le 10$ (준탄도 영역, Quasi-Ballistic Regime):**
  - 입자가 일부는 충돌하고 일부는 경계면까지 직진함.
  - 박막 두께에 따라 유효 열전도율이 깎여나가는 크기 효과(Size Effect) 발생.
- **$\mathrm{Kn} > 10$ (순수 탄도 영역, Ballistic Regime):**
  - 입자가 물질 내부에서 단 한 번도 산란되지 않고 고온벽에서 저온벽으로 다이렉트 비행함.
  - 열류는 온도 '기울기'가 아니라 양단 절대 온도의 차이에 직접 비례함.

### 2. 왜 탄도 수송에서는 푸리에 법칙이 파탄나는가?
- 푸리에 법칙의 대전제: "국소적인 열평형 상태(Local Thermal Equilibrium)가 존재하여 공간마다 정의 가능한 온도 $T(x)$가 연속적으로 존재한다."
- 하지만 탄도 수송 영역에서는 포논이 내부에서 산란되지 않으므로, 국소 온도라는 개념 자체가 성립하지 않습니다.
- **란다우어-다트릭(Landauer-Datta) 열수송 식:**
  $$q''_{\text{ballistic}} = \frac{1}{2} C_v v_g (T_{\text{hot}} - T_{\text{cold}})$$
  여기서 열류량은 두께($L$)에 전혀 반비례하지 않으며, 두께를 아무리 얇게 줄여도 열류가 무한대로 가지 못하는 **양자 접촉 컨덕턴스 한계(Quantum limit of thermal conductance)**에 도달합니다.

### 3. 반도체 패키징에서의 의미
- **Wurtzite AlN 나노박막:** 상온 포논 평균 자유 행로가 $\Lambda \approx 110\,\text{nm}$에 달하므로, 두께가 $50\,\text{nm}$인 하이브리드 본딩 박막은 $\mathrm{Kn} = 110 / 50 = 2.2 \gg 0.1$로 **완전한 준탄도/탄도 영역**에 들어섭니다.
- 따라서 AlN 박막을 시뮬레이션할 때 상용 FEM의 단순 푸리에 전도 솔버를 사용하면 심각한 물리적 할루시네이션이 발생합니다.

## 🔗 Knowledge Connections
- **Parent/Higher Topic:** [[포논 산란 기작의 역사와 마티센 규칙 (Phonon Scattering Mechanisms)]]
- **Sub-Concepts:** [[포논 볼츠만 수송 방정식 (BTE)]]
- **Advanced Transition:** [[계면 열경계 저항과 AMM DMM 역사 (History of TBR AMM DMM)]], [[Wurtzite AlN 결정성 및 포논 수송 메커니즘]]

---
*Last updated: 2026-10-07*
