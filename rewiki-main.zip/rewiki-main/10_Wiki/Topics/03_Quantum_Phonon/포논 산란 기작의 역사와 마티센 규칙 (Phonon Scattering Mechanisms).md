# [[포논 산란 기작의 역사와 마티센 규칙 (Phonon Scattering Mechanisms)]]

## 📌 Brief Summary
고체 내부에서 전파되는 포논은 무한히 달릴 수 없으며, 불순물, 결정립계, 그리고 다른 포논과의 충돌에 의해 진로가 방해받습니다. 이를 포논 산란(Phonon Scattering)이라 부릅니다. 1959년 조셉 캘러웨이(Joseph Callaway)와 1963년 홀랜드(Holland)의 완화시간 모델을 거쳐, 1973년 글렌 슬랙(Glen Slack)의 고열전도도 물질 판정 기준에 이르기까지 1960~70년대에 확립된 이론 체계는 오늘날 나노 박막 열전도도의 뼈대를 형성합니다.

## 📖 Core Content

### 1. 마티센 규칙 (Matthiessen's Rule)
서로 독립적인 여러 산란 메커니즘이 동시에 존재할 때, 총 포논 산란율(이완 시간의 역수 $\tau_{\text{total}}^{-1}$)은 개별 산란율의 단순 합으로 표현됩니다:
$$\frac{1}{\tau_{\text{total}}(\omega, T)} = \frac{1}{\tau_B} + \frac{1}{\tau_D} + \frac{1}{\tau_U} + \frac{1}{\tau_N}$$
평균 자유 행로($\Lambda = v \tau$)에 대해서도 동일하게 성립:
$$\frac{1}{\Lambda_{\text{total}}} = \frac{1}{\Lambda_B} + \frac{1}{\Lambda_D} + \frac{1}{\Lambda_U}$$

### 2. 4대 핵심 포논 산란 메커니즘의 수학적 표현
1. **경계 산란 (Boundary Scattering, $\tau_B^{-1}$):**
   - 시료의 외벽이나 나노박막 표면과의 물리적 충돌:
     $$\tau_B^{-1} = \frac{v}{d} (1 - p)$$
     ($d$: 박막 두께 또는 결정립 크기, $p$: 표면 평탄도 매개변수). **나노박막 두께 효과의 지배 인자!**
2. **점결함 / 동위원소 산란 (Defect & Isotope Scattering, $\tau_D^{-1}$):**
   - 질량 불일치 원자나 점결함에 의한 레일리 산란(Rayleigh scattering):
     $$\tau_D^{-1} = A \cdot \omega^4$$
     진동수의 4승에 비례하므로 고주파 포논을 극도로 강하게 산란시킴.
3. **엄클랍 산란 (Umklapp Scattering, $\tau_U^{-1}$ - 비조화 3-포논 산란):**
   - 3개의 포논이 충돌할 때 결정 운동량 보존이 깨지고 역격자 벡터($\mathbf{G}$)가 관여하는 비탄성 산란:
     $$\mathbf{q}_1 + \mathbf{q}_2 = \mathbf{q}_3 + \mathbf{G}$$
     $$\tau_U^{-1} = B \cdot \omega^2 T \exp\left(-\frac{\theta_D}{\gamma T}\right)$$
     **고체의 고유 열저항을 만드는 근원적 메커니즘.** 온도가 오르면 지수함수적으로 증가하여 고온에서 $k \propto T^{-1}$ 거동을 유발함.
4. **정상 산란 (Normal Scattering, $\tau_N^{-1}$):**
   - $\mathbf{q}_1 + \mathbf{q}_2 = \mathbf{q}_3$. 총 운동량이 보존되므로 직접적인 열저항을 만들지 않으나 포논 모드 간 에너지를 재분배함.

### 3. 슬랙(Slack)의 4대 고열전도성 결정 판정 기준 (1973년 정립)
벨 연구소의 Glen A. Slack 교수는 1973년 고유 열전도율이 극단적으로 높은 물질의 4가지 원자론적 필수 조건을 규명하였습니다:
1. 구성 원소의 평균 원자량이 작을 것 (낮은 $\bar{M}$)
2. 원자간 결합력이 극도로 강할 것 (높은 탄성 계수, 높은 데바이 온도 $\theta_D$)
3. 단순한 결정 구조를 가질 것 (단위 포 내 원자 수가 적어야 광학 포논 분기가 적음)
4. 격자 비조화성(Anharmonicity)이 낮을 것 (낮은 Grüneisen 파라미터 $\gamma$)
$\rightarrow$ 이 4대 조건을 완벽히 충족하는 4대 물질이 바로 **다이아몬드, c-BN, BeO, 그리고 AlN**입니다.

## 🔗 Knowledge Connections
- **Parent/Higher Topic:** [[포논의 개념과 데바이 모델 (Phonon & Debye Model)]]
- **Sub-Concepts:** [[포논 볼츠만 수송 방정식 (BTE)]]
- **Advanced Transition:** [[Wurtzite AlN 결정성 및 포논 수송 메커니즘]], [[크누센 수와 탄도 열수송 (Knudsen Number & Ballistic Transport)]]

---
*Last updated: 2026-10-07*
