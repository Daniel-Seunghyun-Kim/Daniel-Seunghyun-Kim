# [[무정형 SiO2 디퓨존 이론 (Diffuson & Locon)]]

## 📌 Brief Summary
무정형 이산화규소(Amorphous $\text{SiO}_2$, a-SiO₂)는 장거리 격자 주기성이 결여된 유리질(Glassy) 구조로 인해 전통적인 평면파 포논(Phonon) 대신 알렌-펠드만(Allen-Feldman) 이론에 기반한 비전파성 확산 모드인 **디퓨존(Diffusons)**과 공간적으로 갇힌 **로콘(Locons)**에 의해 열이 수송됩니다. 이로 인해 유효 평균 자유 행로가 원자 간격($\sim 1\,\text{nm}$) 수준으로 고정되어, 나노스케일 박막에서도 두께에 따른 열전도도 변화(크기 효과)가 거의 발생하지 않는 특성을 보입니다.

## 📖 Core Content

### 1. 알렌-펠드만(Allen-Feldman) 무정형 진동 모드 분류
무정형 물질에서의 격자 진동 모드는 주파수와 공간적 확장성에 따라 3가지로 엄밀히 분류됩니다:
1. **프로파곤 (Propagons):** 극저주파 영역($< 1\,\text{THz}$)의 장파장 음향 모드로, 결정질의 음향 포논처럼 평면파 형태로 전파함 (전체 모드의 $< 2\%$).
2. **디퓨존 (Diffusons):** 중주파 영역($1 \sim 10\,\text{THz}$)의 진동 모드로, 주기적 위상을 잃고 공간적으로 무질서하게 확장되어 원자간 하모닉 커플링을 통해 진동 에너지를 깡충뛰기(Hopping) 방식으로 확산시킴 (열용량 및 열전도의 $90\%$ 이상 담당).
3. **로콘 (Locons):** 고주파 광학 모드 영역으로, Anderson 국재화(Localization) 현상에 의해 국소 원자 몇 개에 완전히 갇혀 이동하지 못하며 열전도에 기여하지 않음.

### 2. 왜 a-SiO₂는 박막 크기 효과(Size Effect)가 없는가?
- 결정질 AlN의 경우 포논 평균 자유 행로가 상온 $\Lambda \approx 110\,\text{nm}$에 달하므로, 박막 두께가 수십 nm로 얇아지면 경계 산란에 의해 열전도도가 급감합니다.
- 반면 a-SiO₂는 디퓨존의 확산 평균 거리(Diffusive hopping distance)가 규소-산소(Si-O) 사면체 결합 거리 수준인 **$\Lambda \approx 0.5 \sim 1.0\,\text{nm}$**에 불과합니다.
- 따라서 박막 두께가 $10\,\text{nm}$이든 $500\,\text{nm}$이든 관계없이 크누센 수($\mathrm{Kn} = \Lambda / t \ll 0.1$)가 항상 확산 영역에 머무르므로 열전도도는 **$k \approx 1.23 \sim 1.35\,\text{W/mK}$**로 일정하게 유지됩니다.

### 3. AlN vs SiO₂ 열저항 병목 역전 현상 (Bottleneck Inversion)
- **$t < 27\,\text{nm}$ 극초박막:**
  - AlN과 SiO₂ 모두 계면 저항($1/G$)이 전체 저항을 지배하여 둘 사이의 유효 열저항 차이가 2배 내외에 불과함.
- **$t > 100\,\text{nm}$ 영역:**
  - AlN은 계면 저항이 여전히 $86 \sim 97\%$를 차지하며 총 저항이 완만하게 증가($14 \to 15.5\,\text{m}^2\text{K/GW}$).
  - 반면 SiO₂는 박막 체적 저항($t/k_{\text{bulk}}$)이 폭증하여 계면을 압도함.
  - $500\,\text{nm}$에서 SiO₂ 열저항($390.4\,\text{m}^2\text{K/GW}$)은 AlN 대비 **25.2배 폭증**하여 극심한 자가발열(Self-Heating Penalty)을 유발함.

## 🔗 Knowledge Connections
- **Related Topics:** [[포논 볼츠만 수송 방정식 (BTE)]], [[Wurtzite AlN 결정성 및 포논 수송 메커니즘]], [[카피차 저항 및 계면 열전도도 (Kapitza Resistance & TBC)]]
- **Projects/Contexts:** [[Reserach1_향후_연구개발_계획서]], [[07_Simulation_Results_Thermal_Stack]]
- **Contradictions/Notes:**
  - SiO₂의 얇은 막을 만들면 열저항을 줄일 수 있지만, 절연 내압 파괴 및 유전 결함(Pin-hole) 한계로 인해 일정 두께 이상 확보가 필요하므로 고열유속 반도체에서 AlN 대체가 필수적임.

---
*Last updated: 2026-10-07*
