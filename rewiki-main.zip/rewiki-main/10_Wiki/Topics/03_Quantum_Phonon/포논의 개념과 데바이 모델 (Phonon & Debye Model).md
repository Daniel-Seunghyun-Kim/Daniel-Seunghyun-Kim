# [[포논의 개념과 데바이 모델 (Phonon & Debye Model)]]

## 📌 Brief Summary
포논(Phonon)은 고체 결정 내부에서 주기적으로 배열된 원자들이 집단적으로 진동할 때, 그 탄성파(Elastic wave)의 에너지를 양자역학적으로 양자화(Quantization)한 가상 입자(Quasi-particle)입니다. 빛의 입자가 광자(Photon)인 것처럼 소리의 입자가 포논이며, 1912년 피터 데바이(Peter Debye)가 정립한 데바이 모델은 고체의 비열과 포논 상태밀도를 설명하는 현대 고체 물리학의 기초입니다.

## 📖 Core Content

### 1. 포논의 본질: 소리(진동)를 입자로 보는 이유
- 결정 속의 원자들은 스프링으로 연결된 구슬들과 같습니다. 한 원자가 진동하면 스프링을 통해 이웃 원자로 파동이 전파됩니다.
- 양자역학에 따르면 각 진동 모드의 에너지는 연속적이지 않고 에너지 양자 $\hbar \omega$ 단위로 흡수되거나 방출됩니다:
  $$E_n = \left( n + \frac{1}{2} \right) \hbar \omega$$
- 여기서 $n$은 진동 에너지를 운반하는 '포논의 개수'를 의미하며, 보스-아인슈타인 통계(Bose-Einstein Statistics)를 따릅니다:
  $$n(\omega, T) = \frac{1}{\exp\left(\frac{\hbar \omega}{k_B T}\right) - 1}$$

### 2. 음향 포논(Acoustic) vs 광학 포논(Optical)
단위 격자(Primitive cell)에 2개 이상의 원자가 있는 결정(예: Si, AlN, GaAs)에서는 진동 모드가 분기됩니다:
1. **음향 포논 (Acoustic Phonon - LA, TA):**
   - 인접한 원자들이 **같은 방향(위상)**으로 진동합니다.
   - 파수가 0으로 갈수록 주파수가 0으로 수렴하며($\omega \to 0$ as $q \to 0$), 기울기가 음속($v = \frac{\omega}{q}$)이 됩니다.
   - **군속도($v_g$)가 매우 빠르고 수명이 길어 고체 열전도의 $90\%$ 이상을 담당합니다.**
2. **광학 포논 (Optical Phonon - LO, TO):**
   - 인접한 양이온과 음이온이 **서로 반대 방향(역위상)**으로 진동하여 전기 쌍극자를 만듭니다.
   - 파수와 관계없이 주파수가 높고 군속도($v_g \approx 0$)가 거의 0에 수렴하여, 직접적인 열전도에는 기여하지 못하고 주로 음향 포논을 산란시키는 저항 요소로 작용합니다.

### 3. 데바이 모델과 데바이 온도 ($\theta_D$)
데바이 모델은 결정의 격자 진동을 음속 $v$를 갖는 탄성 연속체로 단순화하여 최대 진동수(데바이 주파수 $\omega_D$)까지만 적분합니다:
- **데바이 온도 $\theta_D$:**
  $$k_B \theta_D = \hbar \omega_D = \hbar v \left( \frac{6 \pi^2 N}{V} \right)^{1/3}$$
- **물리적 의미:** $\theta_D$가 높을수록 원자간 결합력이 강하고 음속이 빠르며, 상온에서도 비조화 산란이 적어 높은 열전도도를 나타냅니다.
  - AlN: $\theta_D \approx 950 \sim 1,150\,\text{K}$ (초고열전도 세라믹)
  - 다이아몬드: $\theta_D \approx 2,230\,\text{K}$ (지구상 최고 열전도도)
  - 납(Pb): $\theta_D \approx 105\,\text{K}$ (낮은 열전도도)

## 🔗 Knowledge Connections
- **Parent/Higher Topic:** [[반도체_나노열관리_마인드맵_총괄_지식지도]]
- **Sub-Concepts (더 쉬운 개념):** [[열전도도와 푸리에 법칙 기초 (Thermal Conductivity & Fourier Law)]]
- **Advanced Transition (심화 전이):** [[포논 산란 기작의 역사와 마티센 규칙 (Phonon Scattering Mechanisms)]], [[Wurtzite AlN 결정성 및 포논 수송 메커니즘]]

---
*Last updated: 2026-10-07*
