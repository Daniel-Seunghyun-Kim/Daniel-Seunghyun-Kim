# [[Wurtzite AlN 결정성 및 포논 수송 메커니즘]]

## 📌 Brief Summary
질화알루미늄(Aluminum Nitride, AlN)은 육방정계 우르츠광(Wurtzite, 공간군 $P6_3mc$) 결정 구조를 가지는 대표적인 III-V족 와이드 밴드갭(초광대역 $E_g \approx 6.2\,\text{eV}$) 절연체입니다. 원자간 결합력이 극도로 강하고 구성 원소(Al과 N)의 질량 차이가 작아, 우수한 전기적 절연성($> 10^{14}\,\Omega\cdot\text{cm}$)과 함께 다이아몬드 및 c-BN에 필적하는 초고열전도도(단결정 벌크 상온 $k \approx 285 \sim 320\,\text{W/mK}$)를 발현하는 열전달 핵심 소재입니다.

## 📖 Core Content

### 1. 결정 구조와 음향 포논(Acoustic Phonon) 분산
- **격자 상수:** $a = 3.112\,\text{Å}$, $c = 4.982\,\text{Å}$ (상온).
- **포논 수송 주역:** 열전달의 $90\%$ 이상은 파장이 길고 군속도가 빠른 **전파성 음향 포논(Propagons / Acoustic Phonons - LA, TA1, TA2)**에 의해 수행됩니다.
  - 종파 음향 속도 ($v_{\text{LA}}$): $\sim 11,000\,\text{m/s}$ (매우 높은 음속)
  - 횡파 음향 속도 ($v_{\text{TA}}$): $\sim 6,000\,\text{m/s}$
- **포논 분산 특성:** 높은 데바이 온도($\theta_D \approx 950 \sim 1,150\,\text{K}$)로 인해 상온에서도 비조화 엄클랍 산란(Umklapp scattering)이 상대적으로 억제되어 높은 고유 열전도도를 유지합니다.

### 2. 박막에서의 $c$축 (002) 배향성과 결정립계(Grain Boundary) 산란
- **반응성 스퍼터링 증착 특성:** 저온 스퍼터링 시 기판-타깃 거리(T-S), 질소 분압, RF 바이어스에 따라 결정립이 기판 수직 방향인 $(0002)$ $c$축 배향(Columnar grain structure)을 형성합니다.
- **주상정(Columnar) 구조의 이방성:**
  - 수직 방향 열전도율 ($k_\perp$): 결정립계를 가로지르지 않고 기둥을 따라 전파하므로 상대적으로 높음 ($30 \sim 100\,\text{W/mK}$).
  - 수평 방향 열전도율 ($k_\parallel$): 주상정 사이의 수많은 결정립계(GB)에서 전단 산란이 발생하여 수직 대비 $30 \sim 50\%$ 수준으로 감소.

### 3. 산소 불순물 결함($O_N$)의 포논 산란 페널티
- AlN 결정 내 산소($\text{O}$)가 질소($\text{N}$) 자리를 치환하면서 발생하는 점결함($O_N$) 및 전하 중성 유지를 위한 알루미늄 공공($V_{\text{Al}}$):
  $$3\text{O}^{2-} \to 3\text{O}_N^+ + V_{\text{Al}}^{3-}$$
- 슬랙(Slack) 이론 모델에 따르면 산소 농도가 $1\,\text{at}\%$만 혼입되어도 포논 점결함 산란에 의해 벌크 열전도율이 $300\,\text{W/mK} \to 50\,\text{W/mK}$ 이하로 급락함.
- 따라서 스퍼터 공정 챔버의 진공도($< 10^{-7}\,\text{Torr}$)와 가스 순도 확보가 AlN 방열막 구현의 핵심 전제 조건임.

## 🔗 Knowledge Connections
- **Related Topics:** [[포논 볼츠만 수송 방정식 (BTE)]], [[카피차 저항 및 계면 열전도도 (Kapitza Resistance & TBC)]], [[저온 직접 접합 및 플라즈마 표면 활성화]]
- **Projects/Contexts:** [[00_AlN_Research_Hub_Master_Index]], [[06_Dataset_AlN_DC_Literature]]
- **Contradictions/Notes:**
  - 과거 문헌에서는 스퍼터 AlN이 무정형 또는 미세결정질로 성장하여 $k=2 \sim 30\,\text{W/mK}$에 그친다고 알려졌으나, 최근 저온 고밀도 스퍼터 기술(Perez 2023, Stanford Pop Lab)로 $100\,\text{nm}$에서도 $18.7\,\text{W/mK}$, $600\,\text{nm}$에서 $104\,\text{W/mK}$를 달성하며 상용화 가능성이 입증됨.

---
*Last updated: 2026-10-07*
