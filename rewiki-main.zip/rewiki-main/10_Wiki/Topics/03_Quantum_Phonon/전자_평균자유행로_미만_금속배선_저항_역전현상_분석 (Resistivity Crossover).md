# [[전자_평균자유행로_미만_금속배선_저항_역전현상_분석 (Resistivity Crossover)]]

## 📌 Brief Summary
본 문서는 반도체 소자의 배선 폭(CD)이 전자의 평균자유행로(Mean Free Path, $\lambda$) 미만으로 축소될 때 발생하는 양자 크기 효과(Fuchs-Sondheimer 표면 산란 및 Mayadas-Shatzkes 결정립계 산란), 배리어 층 면적 침식, 그리고 **특정 임계 선폭($CD_{crit} \approx 10\text{--}12\,\text{nm}$) 이하에서 코발트(Co) 및 루테늄(Ru)의 배선 저항이 구리(Cu)보다 오히려 낮아지는 "저항 역전 현상(Resistivity Crossover / Inversion)"의 엄밀한 수리 물리 및 학술 논문 실증**을 집대성한 전문 분석 노트입니다.

---

## 📐 1. 전자 평균자유행로 (Electron Mean Free Path, $\lambda$) 기초 물리

금속 내 자유 전자의 전기전도도 $\sigma_0$와 비저항 $\rho_0$는 드루드-조머펠트(Drude-Sommerfeld) 모델에 의해 다음과 같이 주어집니다:
$$\sigma_0 = \frac{1}{\rho_0} = \frac{n e^2 \tau}{m^*} = \frac{n e^2 \lambda}{m^* v_F}$$
여기서 페르미 표면적(Fermi Surface Area, $S_F$)을 도입하면 비저항과 평균자유행로의 곱($\rho_0 \lambda$)은 금속 고유의 전자구조 불변량(Intrinsic Constant)이 됩니다:
$$\rho_0 \lambda = \frac{12 \pi^3 \hbar}{e^2 S_F}$$

### 1.1 주요 인터커넥트 금속의 고유 물성 정밀 비교 (300 K 기준)
*(출처: Daniel Gall, Journal of Applied Physics 119, 085101 (2016) 및 JAP 127, 050901 (2020) 검증 데이터)*

| 금속 (Metal) | 벌크 비저항 $\rho_0$ ($\mu\Omega\cdot\text{cm}$) | 전자 평균자유행로 $\lambda$ ($\text{nm}$) | $\rho_0 \times \lambda$ 불변량 ($10^{-16}\,\Omega\cdot\text{m}^2$) | 녹는점 ($^\circ\text{C}$) | EM 내성 특성 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **구리 (Cu)** | **1.68** | **39.9** (약 40 nm) | **6.70** | 1,085 | 기준 (낮음) |
| **코발트 (Co)** | **5.6 ~ 6.2** | **7.7 ~ 11.8** (평균 $\sim 10$ nm) | **4.62 ~ 7.32** | 1,495 | **Cu 대비 수십 배 우수** |
| **루테늄 (Ru)** | 7.1 | 6.6 (약 6.6 nm) | 4.69 | 2,334 | 극도로 우수 |
| **텅스텐 (W)** | 5.3 | 19.1 | 10.12 | 3,422 | 우수 (Via 전용) |
| **몰리브덴 (Mo)** | 5.3 | 14.8 | 7.84 | 2,623 | 우수 |

- **핵심 물리적 차이점**:
  - 벌크 상태에서는 구리의 비저항($1.68\,\mu\Omega\cdot\text{cm}$)이 코발트($6.0\,\mu\Omega\cdot\text{cm}$)보다 **3.5배 이상 낮아** 압도적으로 우수합니다.
  - 그러나 전자의 평균자유행로는 **구리가 $39.9\,\text{nm}$로 코발트($\sim 10\,\text{nm}$)보다 4배나 깁니다**.

---

## 🔬 2. 나노 스케일 크기 효과 (Size Effect) 지배 방정식

배선 폭 $d$가 전자의 평균자유행로 $\lambda$에 접근하거나 그보다 작아지면 ($d < \lambda$), 전자가 격자 진동(포논)과 충돌하기 전에 배선의 외벽 및 결정립계와 먼저 충돌하여 유효 비저항이 폭발적으로 상승합니다.

```
                  ┌────────────────────────────────────────┐
                  │ 총 유효 비저항 ρ_eff                   │
                  │   = ρ_bulk + Δρ_surface + Δρ_grain     │
                  └──────────────────┬─────────────────────┘
                                     │
           ┌─────────────────────────┴─────────────────────────┐
           ▼                                                   ▼
┌─────────────────────────────────┐   ┌─────────────────────────────────┐
│ Fuchs-Sondheimer (FS) 표면 산란 │   │ Mayadas-Shatzkes (MS) 결정립계   │
│ ρ_FS / ρ_0 = 1 + 3/4*(1-p)*(λ/d)│   │ α = (λ / d_g) * (R / (1-R))     │
└─────────────────────────────────┘   └─────────────────────────────────┘
```

### 2.1 표면 산란: Fuchs-Sondheimer (FS) 모델
원통형/직사각형 도선에서 표면 산란에 의한 비저항 증가 (단면 치수 $d$):
$$\frac{\rho_{FS}}{\rho_0} = 1 + \frac{3}{4}(1 - p)\frac{\lambda}{d}$$
- $p$: 거울면 반사율 (Specularity Parameter, $0 \le p \le 1$).
- 실제 반도체 제조 공정의 금속 계면은 원자 단위의 거칠기를 가지므로 전자는 전방위로 난반사(Diffusive Scattering)되어 **$p \approx 0$**입니다.
- **결과**: 비저항 증가분 $\Delta \rho_{surface} \propto \frac{\lambda}{d}$ 에 정비례합니다. 따라서 **$\lambda$가 큰 구리(40 nm)는 $\lambda$가 작은 코발트(10 nm)보다 선폭 축소에 따른 비저항 폭증률이 4배 더 가파릅니다**.

### 2.2 결정립계 산란: Mayadas-Shatzkes (MS) 모델
배선 선폭이 좁아지면 금속 어닐링 시 결정립 성장(Grain Growth)이 측벽에 가로막혀 결정립 직경 $d_g$ 역시 배선 폭과 동일하게 축소됩니다 ($d_g \approx d$).
$$\frac{\rho_{MS}}{\rho_0} = \left[ 1 - \frac{3}{2}\alpha + 3\alpha^2 - 3\alpha^3 \ln\left(1 + \frac{1}{\alpha}\right) \right]^{-1}$$
여기서 무차원 산란 파라미터 $\alpha$:
$$\alpha = \frac{\lambda}{d_g} \frac{R}{1 - R} \approx \frac{\lambda}{d} \frac{R}{1 - R}$$
- $R$: 결정립계 반사율 (Grain boundary reflection coefficient, 구리에서 $R \approx 0.3\sim 0.5$).
- $\alpha \gg 1$ ($d \ll \lambda$) 영역에서 점근적 근사:
  $$\frac{\rho_{MS}}{\rho_0} \approx \frac{4}{3} \alpha = \frac{4}{3} \frac{\lambda}{d} \frac{R}{1-R}$$
- **결론**: 결정립계 산란 역시 $\lambda / d$에 정비례하여 폭증합니다.

---

## 🚫 3. 배리어 층(Barrier/Liner) 스케일링 저주와 면적 잠식

실제 반도체 칩에서 금속 배선 저항 $R_{line}$을 결정짓는 가장 결정적인 요소는 **확산 방지막(Diffusion Barrier)의 면적 잠식률**입니다.

```
       [ 10 nm Cu 배선 단면 ]                [ 10 nm Co 배선 단면 ]
  ┌───────────────────────────┐         ┌───────────────────────────┐
  │ TaN/Ta Barrier (2 nm)     │         │ TiN Liner (0.5~1 nm)      │
  │  ┌─────────────────────┐  │         │  ┌─────────────────────┐  │
  │  │  순수 Cu 코어       │  │         │  │                     │  │
  │  │  (실효 면적: 36%)   │  │         │  │  순수 Co 코어       │  │
  │  └─────────────────────┘  │         │  │  (실효 면적: 81%)   │  │
  │                           │         │  └─────────────────────┘  │
  └───────────────────────────┘         └───────────────────────────┘
```

1. **구리(Cu)의 배리어 제약**:
   - Cu 원자는 $\text{SiO}_2$나 Low-k 유전체 내부로 극도로 빠르게 확산되어 트랜지스터를 오염시키므로, **두께 $2\sim 3\,\text{nm}$의 $\text{TaN}/\text{Ta}$ 확산 방지막**이 반드시 사방을 둘러싸야 합니다.
   - 선폭 $W = 10\,\text{nm}$, 높이 $H = 20\,\text{nm}$인 트렌치에서 $2\,\text{nm}$ 배리어가 차지하는 부피를 빼면:
     $$A_{Cu, eff} = (10 - 4\,\text{nm}) \times (20 - 4\,\text{nm}) = 6\,\text{nm} \times 16\,\text{nm} = 96\,\text{nm}^2$$
     전체 배선 단면적($200\,\text{nm}^2$)의 **$48\%$만이 실제 전도체로 작동**합니다! (TaN/Ta의 비저항은 수백 $\mu\Omega\cdot\text{cm}$로 전류가 흐르지 않음).

2. **코발트(Co)의 배리어 프리/초박형 라이너 이점**:
   - Co는 Cu보다 자체 확산 및 유전체 침투 속도가 훨씬 느려, $0.5\sim 1\,\text{nm}$ 두께의 초박막 TiN 라이너만으로 충분하거나 특정 유전체에서는 **완전 무배리어(Barrierless)** 구현이 가능합니다.
   - 따라서 동일한 $10\,\text{nm}$ 트렌치에서 유효 전도 단면적 $A_{Co, eff}$가 $80\sim 90\%$ 이상 유지됩니다.

---

## ⚡ 4. 저항 역전 현상 (Resistivity & Resistance Crossover) 실증

단위 길이당 금속 배선의 실효 저항 $R_{line}$ ($\Omega/\mu\text{m}$):
$$R_{line} = \frac{\rho_{eff}(d)}{A_{metal, eff}}$$

```
   Line Resistance R_line (Ω/μm)
   ▲
   │                     / (Cu 저항 폭발: λ=40nm + 배리어 잠식)
   │                    /
   │                   /
   │                  /  
   │      Co 배선 ───/──────────── (Co 저항 완만: λ=10nm + 고유면적 유지)
   │                / 
   │               /
   │              /   ◄── Crossover Point (CD_crit ≈ 10~12 nm)
   │             /
   │            / (Cu가 더 우수한 구간: CD > 12 nm)
   └───────────┴──────────────────────► 배선 선폭 CD (nm)
              CD_crit (~11 nm)
```

### 4.1 선폭별 실측/이론 저항 정량 비교표 (Cross-sectional Data)

| 배선 선폭 (CD) | Cu 유효 비저항 $\rho_{eff}$ | Co 유효 비저항 $\rho_{eff}$ | Cu 실효 배선 저항 $R_{line}$ | Co 실효 배선 저항 $R_{line}$ | 승자 (Winner) |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **벌크 (Bulk)** | $1.68\,\mu\Omega\cdot\text{cm}$ | $5.6\,\mu\Omega\cdot\text{cm}$ | - | - | **Cu 압승 (3.5배)** |
| **$45\,\text{nm}$ 노드** | $\sim 3.2\,\mu\Omega\cdot\text{cm}$ | $\sim 7.5\,\mu\Omega\cdot\text{cm}$ | $\sim 25\,\Omega/\mu\text{m}$ | $\sim 52\,\Omega/\mu\text{m}$ | **Cu 우수 (2배)** |
| **$20\,\text{nm}$ 노드** | $\sim 6.8\,\mu\Omega\cdot\text{cm}$ | $\sim 10.2\,\mu\Omega\cdot\text{cm}$ | $\sim 180\,\Omega/\mu\text{m}$ | $\sim 210\,\Omega/\mu\text{m}$ | **Cu 근소 우수** |
| **$12\,\text{nm}$ (Crossover)** | $\sim 14.5\,\mu\Omega\cdot\text{cm}$ | $\sim 13.8\,\mu\Omega\cdot\text{cm}$ | $\sim 650\,\Omega/\mu\text{m}$ | $\sim 620\,\Omega/\mu\text{m}$ | **동등 (역전 시작점)** |
| **$7\,\text{nm}$ 노드** | $\sim 38.0\,\mu\Omega\cdot\text{cm}$ | $\sim 19.5\,\mu\Omega\cdot\text{cm}$ | $\sim 3,200\,\Omega/\mu\text{m}$ | $\sim 1,450\,\Omega/\mu\text{m}$ | **Co 압승 (2.2배 우수)** |
| **$5\,\text{nm}$ 노드** | $> 80.0\,\mu\Omega\cdot\text{cm}$ | $\sim 26.0\,\mu\Omega\cdot\text{cm}$ | $> 12,000\,\Omega/\mu\text{m}$ | $\sim 3,100\,\Omega/\mu\text{m}$ | **Co 압승 (4배 우수)** |

---

## 🏛️ 5. 산업계 및 학술 연구 실증 사례 (Intel & imec)

1. **Intel Corporation (IEDM 2017 / 2018 발표)**:
   - 인텔은 10nm 로직 공정(업계 기준 7nm 상당)에서 최하위 배선 계층인 **M0 및 M1 메탈 라인과 컨택 비아에 사상 최초로 순수 코발트(Pure Cobalt)를 채택**.
   - 실측 결과: $40\,\text{nm}$ 피치 이하에서 구리 배선 대비 **일렉트로마이그레이션(EM) 수명 4자리수(수천 배) 향상** 및 **비아 저항 $50\%$ 절감** 공식 발표.
2. **imec (Tőkei et al., IEDM 2018 / 2020 Benchmark)**:
   - imec 연구팀은 Sub-10nm 인터커넥트 벤치마크를 통해, 종횡비 $AR=2$인 트렌치에서 배선 선폭 $CD \le 12\,\text{nm}$ 진입 시 Cu와 Co의 저항 곡선이 교차(Crossover)하고, $CD \le 8\,\text{nm}$에서는 루테늄(Ru)과 코발트(Co)가 Cu를 완전히 압도함을 실험적으로 규명.

---

## 🔗 Knowledge Connections
- [[구리_식각_연구_논문_및_화학반응_총람 (Cu Dry Etch & ALE Literature)]] : Cu 감산형 식각의 난제
- [[코발트_식각_연구_논문_및_카보닐화_메커니즘 (Co Dry Etch & Carbonyl Literature)]] : sub-10nm Co 배선 건식 식각 기술
- [[석박사_연구연계_로드맵_식각난제에서_무식각_CuAlN_하이브리드본딩까지]] : 식각 난제와 저항 역전을 통합 극복하는 학위 연구 연계 로드맵
- [[크누센 수와 탄도 열수송 (Knudsen Number & Ballistic Transport)]] : 전자의 MFP($\lambda_e$)와 포논의 MFP($\lambda_{ph}$) 크기효과 상사성

*Last updated: 2026-10-07*
