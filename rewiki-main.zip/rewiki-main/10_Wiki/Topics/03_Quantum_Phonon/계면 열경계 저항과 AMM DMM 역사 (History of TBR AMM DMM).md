# [[계면 열경계 저항과 AMM DMM 역사 (History of TBR AMM DMM)]]

## 📌 Brief Summary
열경계 저항(TBR) 또는 카피차 저항(Kapitza Resistance)은 1941년 표트르 카피차(Pyotr Kapitza)의 액체 헬륨-고체 계면 발견에서 출발하여, 1959년 칼라트니코프(Khalatnikov)의 음향 불일치 모델(AMM), 1989년 스워츠와 폴(Swartz & Pohl)의 확산 불일치 모델(DMM), 2016년 모나숑(Monachon)의 포괄적 리뷰를 거쳐 2024년 니에미넨(Nieminen)의 반도체 이종접합 실측에 이르기까지 80년 이상의 물리학적 진화를 거친 현대 나노공학의 핵심 주제입니다.

## 📖 Core Content

### 1. 1940년대~1980년대: 고체물리학적 태동기
1. **1941년 (Pyotr Kapitza - 발견):**
   - 구리와 초유체 헬륨($^4\text{He}$) 계면을 가로지르는 열류가 발생할 때, 계면 양단에서 온도가 연속적이지 않고 단절되는 $\Delta T$ 불연속 점프를 최초로 발견함 (노벨 물리학상 수상 업적).
2. **1952~1959년 (I. M. Khalatnikov - AMM 모델 정립):**
   - **음향 불일치 모델 (Acoustic Mismatch Model, AMM):**
   - 물질 간의 음향 임피던스($Z = \rho v$) 차이로 인해 포논이 계면에서 음파처럼 반사 및 굴절(스넬의 법칙)한다고 가정.
   - 포논 투과 확률 $\alpha \propto \frac{4 Z_1 Z_2}{(Z_1 + Z_2)^2}$. 극저온($< 30\,\text{K}$) 완벽 평탄 계면에서 우수한 일치도.
3. **1989년 (E. T. Swartz & R. O. Pohl - DMM 모델 혁명):**
   - *Reviews of Modern Physics* 논문을 통해 상온 고체-고체 계면에서 AMM의 파탄을 증명.
   - 계면 원자 무질서도와 거칠기로 인해 포논이 계면에서 완전히 난반사(Diffusive)된다는 **확산 불일치 모델(Diffuse Mismatch Model, DMM)**을 창안하여 상온 나노 열전달의 표준 해석 프레임워크로 확립.

### 2. 2000년대~2010년대: 레이저 열측정 기술(3-omega & TDTR)의 폭발적 발전
1. **David Cahill 교수 (UIUC, 2003~2014):**
   - 피코초/펨토초 레이저 펄스를 이용한 **시간 분해 열반사법(Time-Domain Thermoreflectance, TDTR)**을 대중화하여 나노박막 및 단일 계면의 TBC($G$)를 비접촉식으로 정밀 측정하는 시대를 개막함.
2. **2016년 (Monachon, Weber, Dames - *Ann. Rev. Mater. Res.*):**
   - "Thermal Boundary Conductance: A Materials Science Perspective" 리뷰를 통해 결합 에너지(Work of Adhesion), 원자 혼합층(Interlayer), 표면 조도가 TBC에 미치는 체계적 재료과학 프레임워크 집대성.

### 3. 2020년대~2026년 최신 연구: 3D 반도체 접합 실증기
1. **2024년 (Nieminen et al., *ACS AEM* [S11]):**
   - $720\,\text{nm}$ AlN-Si 직접 접합 구조에서 증착 계면($G_1 = 95\,\text{MW/m}^2\text{K}$)과 직접 접합 계면($G_2 = 105\,\text{MW/m}^2\text{K}$)의 비대칭성을 세계 최초 수준으로 분리 실측함.
2. **2026년 (Huang et al., *Surfaces & Interfaces*):**
   - 저온 Ar 플라즈마 물리 활성화를 통해 AlN 계면 조도를 $2.85\,\text{nm}$로 줄임으로써 본딩 면적률 $>99\%$ 및 계면 결함에 의한 추가 TBR을 최소화하는 양산형 공정 메커니즘 제시.

## 🔗 Knowledge Connections
- **Parent/Higher Topic:** [[카피차 저항 및 계면 열전도도 (Kapitza Resistance & TBC)]]
- **Sub-Concepts:** [[크누센 수와 탄도 열수송 (Knudsen Number & Ballistic Transport)]]
- **Advanced Transition:** [[저온 직접 접합 및 플라즈마 표면 활성화]], [[BSPDN 후면 전력공급망 열관리 아키텍처]]

---
*Last updated: 2026-10-07*
