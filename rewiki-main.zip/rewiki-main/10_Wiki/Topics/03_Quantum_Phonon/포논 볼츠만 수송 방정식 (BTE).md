# [[포논 볼츠만 수송 방정식 (BTE)]]

## 📌 Brief Summary
포논 볼츠만 수송 방정식(Phonon Boltzmann Transport Equation, BTE)은 열 운반체인 격자 진동 양자(포논, Phonon)의 위치와 파수 벡터에 따른 분포 함수 $f(\mathbf{r}, \mathbf{q}, t)$의 시공간적 진화를 기술하는 준고전적(Semiclassical) 미시 열전달 지배 방정식입니다. 거시 푸리에 법칙이 파탄하는 서브마이크론($< 1\,\mu\text{m}$) 탄도 수송 영역에서 유효 열전도율과 비평형 온도장을 정확히 계산할 수 있는 핵심 이론 틀입니다.

## 📖 Core Content

### 1. 지배 방정식 유도 및 이완 시간 근사 (RTA)
포논의 외력이 없는 비자성 유전체에서의 정위치 볼츠만 수송 방정식:
$$\frac{\partial f}{\partial t} + \mathbf{v}_g \cdot \nabla_\mathbf{r} f = \left( \frac{\partial f}{\partial t} \right)_{\text{coll}}$$
단일 이완 시간 근사(Single Mode Relaxation Time Approximation, RTA)를 적용하면:
$$\mathbf{v}_g \cdot \nabla_\mathbf{r} f = -\frac{f - f_0}{\tau(\omega, T)}$$
여기서:
- $\mathbf{v}_g = \nabla_\mathbf{q} \omega$: 포논 군속도 (Group Velocity)
- $f_0(\omega, T) = \frac{1}{\exp\left(\frac{\hbar \omega}{k_B T}\right) - 1}$: 보스-아인슈타인 평형 분포 함수
- $\tau(\omega, T)$: 포논 산란 수명 (이완 시간)

### 2. 크누센 수(Knudsen Number)와 수송 영역의 구분
포논 평균 자유 행로(Mean Free Path, $\Lambda = |\mathbf{v}_g| \tau$)와 특성 길이($L$ 또는 박막 두께 $t$)의 비:
$$\mathrm{Kn} = \frac{\Lambda}{L}$$
- **$\mathrm{Kn} \ll 0.1$ (확산 영역, Diffusive Regime):** 푸리에 법칙($q'' = -k \nabla T$) 완벽 적용.
- **$0.1 < \mathrm{Kn} < 10$ (준탄도 영역, Quasi-Ballistic Regime):** 경계면 산란이 내부 산란을 압도하기 시작함.
- **$\mathrm{Kn} \gg 10$ (순수 탄도 영역, Ballistic Regime):** 포논이 충돌 없이 경계를 통과하며, 열유속은 온도 구배가 아닌 양단 온도의 차이에 비례하는 슈테판-볼츠만 유사 거동을 보임.

### 3. 마티센 규칙(Matthiessen's Rule)과 박막 두께별 열전도율 $k(t)$
총 유효 포논 평균 자유 행로 $\Lambda_{\text{eff}}$는 부피 내부 산란($\Lambda_{\text{bulk}}$)과 경계 산란($\Lambda_{\text{boundary}} \approx t$)의 합으로 결정:
$$\frac{1}{\Lambda_{\text{eff}}} = \frac{1}{\Lambda_{\text{bulk}}} + \frac{1}{\Lambda_{\text{boundary}}}$$
이를 적분하면 나노박막의 유효 열전도율 $k(t)$의 크기 효과 모델이 유도됩니다:
$$k(t) = \frac{k_{\text{bulk}}}{1 + \frac{\Lambda_{\text{bulk}}}{t}}$$
- **Wurtzite AlN 사례:** 상온 $\Lambda_{\text{bulk}} \approx 110\,\text{nm}$이므로, 두께 $10\,\text{nm}$에서는 벌크($285\,\text{W/mK}$) 대비 1/12 수준인 $23.8\,\text{W/mK}$로 급감함 (Stanford Perez 2023 실측치와 일치).

## 🔗 Knowledge Connections
- **Related Topics:** [[Wurtzite AlN 결정성 및 포논 수송 메커니즘]], [[카피차 저항 및 계면 열전도도 (Kapitza Resistance & TBC)]], [[무정형 SiO2 디퓨존 이론 (Diffuson & Locon)]]
- **Projects/Contexts:** [[Reserach1_향후_연구개발_계획서]], [[01_Literature_Verification_Report]]
- **Contradictions/Notes:**
  - 푸리에 법칙에 기반한 상용 FEA 해석에 벌크 상수 물성을 직접 대입하면 나노박막 영역에서 열전달 성능을 $500 \sim 1,000\%$ 이상 과대평가(Hallucination)하게 됨.

---
*Last updated: 2026-10-07*
