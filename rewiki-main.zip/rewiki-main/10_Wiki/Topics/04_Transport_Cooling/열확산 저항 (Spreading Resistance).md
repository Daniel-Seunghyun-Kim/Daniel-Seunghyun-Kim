# [[열확산 저항 (Spreading Resistance)]]

## 📌 Brief Summary
열확산 저항(Spreading Resistance, 또는 수축 저항 Constriction Resistance)은 작은 국소 열원(핫스팟 또는 미세 Cu 패드)에서 발생한 열류가 단면적이 더 넓은 기판이나 확산층으로 퍼져나갈 때, 유선(Heat flux lines)의 기하학적 굴절과 집중으로 인해 추가로 발생하는 3차원 열저항 성분입니다. 1차원 1D 푸리에 전도 모델에서는 완전히 누락되는 대표적인 3차원 공간 물리 현상입니다.

## 📖 Core Content

### 1. 물리적 정의 및 메커니즘
- 균일한 면적의 1차원 전도에서는 $R_{\text{1D}} = \frac{t}{k A}$로 단순 계산되지만, 열원의 크기($a$)가 전체 기판 너비($b$)보다 훨씬 작은 경우($a \ll b$), 열류는 수직 방향뿐만 아니라 수평 방향(In-plane)으로 퍼져나가야 합니다.
- 이때 좁은 입구로 열류가 몰리면서 발생하는 저항을 **수축 저항(Constriction Resistance)**이라 부르고, 넓은 영역으로 퍼져나가면서 발생하는 저항을 **확산 저항(Spreading Resistance)**이라 부르며, 열역학적으로 상호 가역적입니다.

### 2. 해석적 수식 (Mikic & Yovanovich 준해석해)
원형 열원(반경 $r_h$)이 반경 $r_s$, 두께 $t$, 열전도도 $k$인 원통형 기판 중심에 위치할 때의 총 열저항:
$$R_{\text{total}} = R_{\text{1D}} + R_{\text{spread}} = \frac{t}{k \pi r_s^2} + \frac{\psi(\epsilon, \tau)}{4 k r_h}$$
여기서:
- 무차원 면적비: $\epsilon = \frac{r_h}{r_s}$
- 무차원 두께비: $\tau = \frac{t}{r_s}$
- 열확산 함수 $\psi(\epsilon, \tau)$: $\epsilon \to 1$일 때 $\psi \to 0$ (확산 저항 소멸, 1D 거동), $\epsilon \ll 1$일 때 $\psi \to 1$ (최대 확산 저항 도달).

### 3. 반도체 3D 패키징 및 하이브리드 본딩에서의 중요성
1. **Pitch 독립성 오류 극복:** 1D 저항망에서는 Cu 면적비($f_{\text{Cu}}$)가 같으면 피치(Pitch)가 $6\,\mu\text{m}$이든 $12\,\mu\text{m}$이든 동일한 온도를 예측하지만, 실제 3D FEM에서는 피치가 클수록 열원 사이의 간격이 넓어져 열확산 저항이 급증합니다.
2. **소형 핫스팟의 병목:** 최신 GPU/NPU의 서브마이크론 핫스팟($q'' > 10\,\text{MW/m}^2$)에서는 벌크 두께 저항보다 수축/확산 저항이 전체 칩 온도 상승의 최대 $40 \sim 60\%$를 차지합니다.
3. **고열전도 유전체(AlN)의 역할:** 방열 절연막(AlN, $k \approx 40 \sim 100\,\text{W/mK}$)은 Cu 패드 사이의 공간에서 수평 열확산(In-plane spreading)을 보조하여 수축 저항을 획기적으로 낮춥니다.

## 🔗 Knowledge Connections
- **Related Topics:** [[포논 볼츠만 수송 방정식 (BTE)]], [[카피차 저항 및 계면 열전도도 (Kapitza Resistance & TBC)]], [[BSPDN 후면 전력공급망 열관리 아키텍처]]
- **Projects/Contexts:** [[Reserach1_향후_연구개발_계획서]], [[00_AlN_Research_Hub_Master_Index]]
- **Contradictions/Notes:**
  - 1D Lumped 모델은 수축 저항을 0으로 가정하므로 고열유속 핫스팟 환경에서 접션 온도를 심각하게 과소평가(Underestimation)하는 결함이 있음.

---
*Last updated: 2026-10-07*
