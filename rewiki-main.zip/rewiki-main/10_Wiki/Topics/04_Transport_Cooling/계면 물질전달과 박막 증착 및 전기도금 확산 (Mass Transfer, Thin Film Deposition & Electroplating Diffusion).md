# [[계면 물질전달과 박막 증착 및 전기도금 확산 (Mass Transfer, Thin Film Deposition & Electroplating Diffusion)]]

## 📌 Brief Summary
본 문서는 반도체 방열 소재 및 3D 하이브리드 본딩 인터커넥트 제조 공정(PVD, ALD, AAO 나노템플릿 Cu 전기도금)을 지배하는 **물질전달(Mass Transfer) 수송 현상과 고체 소자 신뢰성 열화(커켄달 보이드, 전자기이동 EM, 열이동 Thermomigration)**의 물리를 집대성한 지식 노트입니다.

---

## 🧪 1. 분자 확산과 나노포어 내 물질 수송 이론

### 1.1 픽의 확산 법칙 (Fick's Laws of Diffusion)
- **제1법칙 (정상상태 농도 구배에 의한 몰 플럭스)**:
  $$\mathbf{J} = -D_{AB} \nabla C$$
- **제2법칙 (비정상상태 확산 방정식)**:
  $$\frac{\partial C}{\partial t} = \nabla \cdot (D_{AB} \nabla C) = D_{AB} \nabla^2 C \quad (\text{if } D_{AB} = \text{const})$$

### 1.2 고종횡비(HARC) 및 나노포어 내 크누센 확산 (Knudsen Diffusion)
AAO(Anodic Aluminum Oxide) 나노템플릿 기공($d_p \approx 20\text{--}100\,\text{nm}$)이나 반도체 TSV/트렌치 내부에서 전구체 기체 분자의 평균자유행정 $\lambda$가 기공 직경보다 클 경우 ($Kn = \lambda / d_p \gg 1$), 분자 간 충돌보다 벽면 충돌이 지배합니다.
$$D_K = \frac{d_p}{3} \sqrt{\frac{8 R T}{\pi M}}$$
- **공정적 함의**:
  기공 직경 $d_p$가 좁아질수록 확산 계수 $D_K$가 급격히 감소하여, 깊은 기공 바닥에 전구체 가스나 반응 이온이 도달하지 못하는 **물질전달 고갈(Depletion) 현상**이 발생합니다. 이는 AlN 원자층 증착(ALD) 시 도즈 시간(Dose time)을 지수함수적으로 늘려야 하는 원인입니다.

---

## ⚡ 2. 전기화학 전기도금의 물질전달과 한계 전류 밀도

구리 인터커넥트 및 Cu@AlN 코어쉘 구조 전기도금 시, 음극(Cathode) 표면으로 $\text{Cu}^{2+}$ 이온이 수송되는 속도는 Nernst 확산층($\delta_N$)의 두께에 의해 지배됩니다.

```
       전해액 본체 (Bulk Solution) ──[ C_bulk ]──
                  │  (대류 혼합 영역)
                  ▼
       Nernst 확산 경계층 (δN) ─────[ 선형 농도 감소 ]──
                  │  (순수 분자 확산 지배)
                  ▼
       전극 계면 (Cathode Interface) ─[ C_surface ≈ 0 ]──► Cu 환원 반응
```

### 2.1 한계 전류 밀도 (Limiting Current Density, $i_{lim}$)
음극 표면의 이온 농도가 0에 도달하는 극한 상태:
$$i_{lim} = \frac{n F D_{\text{Cu}^{2+}} C_{bulk}}{\delta_N}$$
- $n$: 전하수 (구리의 경우 $n=2$)
- $F$: 패러데이 상수 ($96,485\,\text{C/mol}$)
- $\delta_N$: 확산 경계층 두께 (강한 교반/초음파 인가 시 감소)

### 2.2 물질전달 과전압 (Concentration Overpotential, $\eta_{conc}$)
인가 전류 $i$가 $i_{lim}$에 근접할 때 발생하는 농도 분극 저항:
$$\eta_{conc} = \frac{R T}{n F} \ln \left( 1 - \frac{i}{i_{lim}} \right)$$
- **핵심 공정 결함**:
  인가 전류 밀도 $i \ge i_{lim}$ 조건에서 도금을 강행하면, 전극 표면 이온 고갈로 인해 수소 가스 발생($2\text{H}^+ + 2e^- \to \text{H}_2 \uparrow$) 부반응이 일어나 덴드라이트(Dendrite) 형성 및 **치명적인 내부 보이드(Porous Void)**가 발생하여 배선 열전도도와 전기전도도가 동시에 붕괴합니다.

### 2.3 첨가제 수송 제어: 슈퍼필링 (Superfilling)
AAO 기공 바닥부터 빈틈없이 채우는 Bottom-up 충진을 위해 억제제(Suppressor, 고분자 PEG)와 가속제(Accelerator, SPS)의 물질전달 계수 차이를 이용합니다.
- 분자량이 큰 억제제는 기공 입구에 확산 저항으로 정체되어 도금을 억제.
- 작은 가속제는 기공 바닥에 빠르게 축적되어 바닥 성장 속도를 극대화.

---

## ⚠️ 3. 반도체 신뢰성 및 방열 계면 파괴 물질전달 메커니즘

### 3.1 커켄달 효과와 계면 보이드 (Kirkendall Voiding)
3D 적층 패키징의 금속 접합부(예: Cu-Sn 인터커넥트 또는 AlN-Cu 접합)에서 두 원소의 상호 확산 속도가 불일치할 때($D_{Cu} \ne D_{Sn}$), 격자 공공(Vacancy)이 한쪽으로 응집하여 마이크로 크기의 공동(Void)을 형성합니다.
- **열적 파괴**:
  접합 계면에 생성된 커켄달 보이드 라인은 실효 접촉 면적을 $50\%$ 이상 잠식하여 계면 열저항($R_{th,c}$)을 3~5배 폭증시키고 국소 박리(Delamination)를 촉발합니다.

### 3.2 전자기이동 (Electromigration, EM)
초고밀도 전류 밀도($J > 10^6\,\text{A/cm}^2$)가 흐를 때 이동 전자가 금속 격자 원자와 운동량을 교환(전자풍, Electron Wind)하여 원자를 물리적으로 밀어내는 원자 플럭스:
$$J_{EM} = \frac{D C}{k_B T} Z^* e E = \frac{D C}{k_B T} Z^* e \rho J$$
- Black의 고장 수명 공식:
  $$\text{MTTF} = \frac{A}{J^n} \exp\left( \frac{E_a}{k_B T} \right)$$
- 고온($T$)일수록 확산 계수 $D = D_0 \exp(-E_a/k_B T)$가 지수적으로 증가하므로, **효과적인 방열(온도 10℃ 저감)은 EM 수명을 2~3배 연장**시킵니다.

### 3.3 열이동 (Thermomigration, TM / Soret Effect)
반도체 패키징에서 칩과 히트싱크 사이, 또는 핫스팟과 비발열 영역 사이에 극한의 온도 구배($\nabla T > 1,000\ ^\circ\text{C/cm}$)가 형성될 때, 열역학적 구동력에 의해 원자가 고온부에서 저온부로 드리프트하는 현상:
$$J_{TM} = -\frac{D C}{k_B T} \frac{Q^*}{T} \nabla T$$
- $Q^*$: 전달 열(Heat of Transport, 금속 종류에 따라 양/음의 값)
- **악순환(Positive Feedback Loop)**:
  핫스팟 근처의 솔더 범프/Cu 패드에서 원자가 빠져나가 핫스팟 바로 아래에 보이드가 형성 $\to$ 유효 열저항 증가로 핫스팟 온도 추가 상승 $\to$ 열구배 $\nabla T$ 추가 증가 $\to$ 초고속 소자 단선 파괴.

---

## 🔗 Knowledge Connections
- [[반도체_열관리_3대_전달현상_물리개념_및_수식_총람]] : 마스터 총람
- [[반도체 전달현상 핵심 무차원수 총람 (Dimensionless Numbers in Semiconductor Cooling)]] : $Sc, Sh$ 무차원수 상사성
- [[전기도금과 AAO 나노템플릿 공정 원리 (Electroplating & AAO Templates)]] : 펄스 도금 및 템플릿 제작 공정
- [[반도체 자가발열과 열폭주 메커니즘 (Self-Heating & Thermal Runaway)]] : 줄열과 열이동(TM)의 결합
- [[카피차 저항 및 계면 열전도도 (Kapitza Resistance & TBC)]] : 보이드 형성에 따른 계면 TBC 급감

*Last updated: 2026-10-07*
