# [[미세유체역학 및 반도체 마이크로채널 냉각 (Microfluidics & On-Chip Microchannels)]]

## 📌 Brief Summary
본 문서는 고집적 AI 가속기 및 3D 적층 반도체에서 $1,000\,\text{W/cm}^2$급 극한 열유속을 제거하기 위한 **단상 액체 마이크로채널 냉각(Single-Phase Microchannel Cooling)의 유체역학적 원리, 압력 손실과 열저항 트레이드오프, 그리고 온칩 내장형 매니폴드(MMC) 최신 아키텍처**를 다룬 기술 지식 노트입니다.

---

## 📜 1. 마이크로채널 냉각의 역사적 배경과 혁신

1981년 스탠포드 대학의 **D. B. Tuckerman과 R. F. W. Pease**는 실리콘 기판 후면에 직폭 $50\,\mu\text{m}$, 깊이 $300\,\mu\text{m}$의 미세 유로를 직접 식각(DRIE)하고 물을 흘려보냄으로써, 당시 기술로 경이적인 **$790\,\text{W/cm}^2$의 방열 성능**을 세계 최초로 실증했습니다.

이 혁신의 핵심 물리는 누셀 수($Nu$)의 스케일링 법칙에 있습니다:
$$h = \frac{Nu \cdot k_f}{D_h}$$
층류 완전 발달 유동에서 $Nu$는 채널 단면 종횡비에 의해 고정된 상수($\sim 3\text{--}8$)이므로, 채널 수력 직경 $D_h$를 밀리미터($\text{mm}$)에서 마이크로미터($\mu\text{m}$) 단위로 $1/100$ 축소하면 **대류 열전달 계수 $h$가 100배 증가($h > 50,000\,\text{W/m}^2\text{K}$)**하게 됩니다.

---

## 📐 2. 마이크로채널 유체역학 및 압력 강하 수식

### 2.1 수력 직경 (Hydraulic Diameter, $D_h$)
폭 $W_c$, 깊이 $H_c$인 직사각형 마이크로채널의 수력 직경:
$$D_h = \frac{4 A_{cross}}{P_{wetted}} = \frac{4 W_c H_c}{2 (W_c + H_c)} = \frac{2 W_c H_c}{W_c + H_c}$$

### 2.2 층류 마찰계수 ($f$) 및 압력 강하 ($\Delta P$)
종횡비 $\alpha_c = H_c / W_c$ (또는 $W_c / H_c \le 1$)인 직사각형 유로의 마찰계수 $f$는 Shah & London의 근사해를 따릅니다:
$$f \cdot Re = 96 \left( 1 - 1.3553 \alpha_c + 1.9467 \alpha_c^2 - 1.7012 \alpha_c^3 + 0.9564 \alpha_c^4 - 0.2537 \alpha_c^5 \right)$$
유로 길이 $L$을 통과할 때의 마찰 압력 강하 $\Delta P_{fric}$:
$$\Delta P_{fric} = f \frac{L}{D_h} \frac{\rho u_{avg}^2}{2} = \frac{(f \cdot Re) \mu L u_{avg}}{2 D_h^2}$$
- **스케일링 저주(The Scaling Penalty)**:
  유속 $u_{avg}$가 일정할 때, $D_h$를 $1/10$로 줄이면 $\Delta P$는 **$100$배 증가**합니다.
  총 체적 유량 $Q = N_{ch} A_c u_{avg}$를 유지하면서 $D_h$를 줄일 경우 펌핑 압력 강하는 $\Delta P \propto \frac{1}{D_h^4}$로 극단적으로 폭증합니다.

---

## 🌡️ 3. 마이크로채널 총 열저항 분해 네트워크 (Thermal Resistance Network)

마이크로채널 쿨러의 칩 접션에서 냉각수 입구까지의 총 열저항 $R_{tot}$ ($^\circ\text{C/W}$):
$$R_{tot} = R_{cond} + R_{conv} + R_{cal}$$

```
   T_junction ──[ R_cond ]── T_base ──[ R_conv ]── T_fluid ──[ R_cal ]── T_in
```

1. **전도 열저항 ($R_{cond}$)**:
   실리콘 기판 두께 $t_{sub}$를 통과하는 순수 전도 저항:
   $$R_{cond} = \frac{t_{sub}}{k_{Si} A_{chip}}$$

2. **대류 열저항 ($R_{conv}$)**:
   채널 벽면 및 핀 표면을 통한 대류 전달 저항:
   $$R_{conv} = \frac{1}{\eta_o h A_{total}} = \frac{1}{h (A_b + \eta_f A_{fin})}$$
   - 여기서 핀 효율 $\eta_f = \frac{\tanh(m H_c)}{m H_c}$, 핀 파라미터 $m = \sqrt{\frac{2 h}{k_{Si} W_{fin}}}$.
   - $D_h$가 작고 $A_{fin}$이 클수록 $R_{conv}$는 극소화됩니다.

3. **열용량(가열) 열저항 ($R_{cal}$)**:
   냉각수가 채널을 통과하며 열을 흡수하여 입구에서 출구로 가면서 수온이 상승하는 저항:
   $$R_{cal} = \frac{1}{\rho c_p \dot{V}} = \frac{1}{\dot{m} c_p}$$
   - 유량이 부족하면 칩 출구 부근의 온도가 급상승하여 칩 내 열구배(Hot-to-Cold $\Delta T_{die}$)가 커집니다.

---

## ⚡ 4. 펌핑 파워와 성능 지수 (Figure of Merit, FOM)

냉각수를 순환시키기 위해 펌프가 소모해야 하는 기계적 일률 $W_{pump}$:
$$W_{pump} = \dot{V} \cdot \Delta P_{tot} = \frac{\dot{m}}{\rho} \Delta P_{tot}$$

냉각 성능(제거 열량 $\dot{Q}$) 대비 소모 동력($W_{pump}$)의 성능 지수:
$$\text{FOM} = \frac{\dot{Q}}{W_{pump}} = \frac{T_{j,max} - T_{in}}{R_{tot} \cdot \dot{V} \cdot \Delta P_{tot}}$$
- 고효율 냉각 시스템은 단순히 $R_{tot}$만 낮추는 것이 아니라, **$\Delta P$를 최소화하면서 $R_{tot}$를 낮추는 최적화 파레토 프론트(Pareto-optimal Front)**를 달성해야 합니다.

---

## 🚀 5. 최신 첨단 아키텍처 (2024~2026 트렌드)

### 5.1 매니폴드 마이크로채널 (Manifold Microchannels, MMC)
- **개념**: 기존 긴 단일 유로($L \sim 20\text{--}30\,\text{mm}$) 대신, 상부에 교대 입구/출구 매니폴드를 배치하여 유체의 유동 길이 $L_{eff}$를 $0.5\text{--}1\,\text{mm}$ 수준으로 획기적으로 단축.
- **효과**: 압력 강하 $\Delta P \propto L$이므로, **동일 열전달 성능 대비 펌핑 압력 강하를 $80\sim 90\%$ 감소**시키며 칩 전면의 온도 균일도($\Delta T_{die} < 5^\circ\text{C}$) 달성.

### 5.2 엇갈린 마이크로 핀-핀 배열 (Staggered Micro Pin-Fin Array)
- 연속 벽 채널 대신 다이아몬드, 원형, 눈물방울형(Airfoil) 핀 배열을 식각.
- 경계층이 계속 재발달(Boundary layer interruption)하여 열전달 계수 $h$가 상승하며, 국소 핫스팟 부위에 핀 밀도를 집중 배치하는 적응형(Non-uniform) 설계 가능.

### 5.3 3D Si 다이 내장 직접 냉각 (Embedded Monolithic Microfluidics)
- TIM(서멀 인터페이스 소재)의 접촉 열저항($R_{TIM} \sim 10\text{--}20\,\text{K}\cdot\text{mm}^2/\text{W}$)을 완전히 제거하기 위해, 칩 후면 실리콘(BSPDN 상부)에 직접 채널을 식각하고 글래스/실리콘 캡을 하이브리드 본딩으로 밀봉하는 모놀리식 솔루션.

---

## 🔗 Knowledge Connections
- [[반도체_열관리_3대_전달현상_물리개념_및_수식_총람]] : 마스터 총람
- [[전달현상 지배방정식과 나비에-스톡스-에너지-연속 방정식 (Navier-Stokes & Energy Equation)]] : 층류 해석 지배식
- [[상변화 열전달과 증기챔버 및 비등 냉각 (Two-Phase Heat Transfer, Vapor Chamber & Boiling)]] : 2상 유동 비등으로의 발전
- [[전기-열 상사성과 열저항 회로 (Thermal Resistance Network)]] : 열저항 회로 분해 기초
- [[BSPDN 후면 전력공급망 열관리 아키텍처]] : 후면 실리콘 내장 쿨링과의 결합

*Last updated: 2026-10-07*
