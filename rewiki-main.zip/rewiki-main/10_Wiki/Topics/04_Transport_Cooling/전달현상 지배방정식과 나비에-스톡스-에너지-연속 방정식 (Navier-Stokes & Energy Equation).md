# [[전달현상 지배방정식과 나비에-스톡스-에너지-연속 방정식 (Navier-Stokes & Energy Equation)]]

## 📌 Brief Summary
본 문서는 반도체 소자, 기판, 마이크로 채널 냉각 시스템을 연성 해석(Multiphysics)하기 위한 **3대 보존 법칙(질량, 운동량, 에너지)의 지배 방정식 유도, 텐서 표기법, 경계 조건, 그리고 고체-유체 켤레 열전달(Conjugate Heat Transfer, CHT) 수학적 정식화**를 체계화한 지식 노트입니다.

---

## 📐 1. 전달현상 미분 지배 방정식계 (Governing Differential Equations)

연속체(Continuum) 영역 ($Kn < 0.001$)에서 작동하는 유체 도메인 $\Omega_f$에 대해 뉴턴 유체(Newtonian Fluid) 및 비압축성($\rho = \text{const}$) 가정을 적용한 지배 방정식계입니다.

### 1.1 질량 보존: 연속 방정식 (Continuity Equation)
$$\frac{\partial \rho}{\partial t} + \nabla \cdot (\rho \mathbf{u}) = 0$$
- **비압축성 유체 ($\nabla \cdot \mathbf{u} = 0$) 직교 좌표계 전개**:
$$\frac{\partial u}{\partial x} + \frac{\partial v}{\partial y} + \frac{\partial w}{\partial z} = 0$$

---

### 1.2 운동량 보존: 나비에-스톡스 방정식 (Navier-Stokes Equation)
코시 운동량 방정식 $\rho \left( \frac{\partial \mathbf{u}}{\partial t} + (\mathbf{u} \cdot \nabla)\mathbf{u} \right) = -\nabla P + \nabla \cdot \boldsymbol{\tau} + \rho \mathbf{g}$ 에서 점성 응력 텐서 $\boldsymbol{\tau} = \mu (\nabla \mathbf{u} + (\nabla \mathbf{u})^T)$ 를 대입:
$$\rho \left( \frac{\partial \mathbf{u}}{\partial t} + (\mathbf{u} \cdot \nabla)\mathbf{u} \right) = -\nabla P + \mu \nabla^2 \mathbf{u} + \rho \mathbf{g} + \mathbf{f}_{ext}$$
- 여기서 $\mathbf{f}_{ext}$는 필요에 따라 전기삼투력(Electroosmotic body force $\rho_e \mathbf{E}$)이나 다공성 매질 드래그 저항($-\frac{\mu}{K}\mathbf{u}$, Darcy 항)을 포함할 수 있습니다.
- **반도체 마이크로채널 단순화 (정상상태, 낮은 Re 수 크리핑/스톡스 유동 가정 $\mathbf{u}\cdot\nabla\mathbf{u} \approx 0$, 중력 무시)**:
$$0 \approx -\nabla P + \mu \nabla^2 \mathbf{u}$$

---

### 1.3 에너지 보존: 열에너지 방정식 (Thermal Energy Equation)

#### 1) 유체 도메인 ($\Omega_f$):
$$\rho c_p \left( \frac{\partial T}{\partial t} + \mathbf{u} \cdot \nabla T \right) = \nabla \cdot (k_f \nabla T) + \mu \Phi + \dot{q}_{f}$$
- $\mathbf{u} \cdot \nabla T$: 대류(이류, Advection) 항.
- $\nabla \cdot (k_f \nabla T)$: 유체 내 열전도 항.
- $\mu \Phi$: 점성 소산 항(Viscous dissipation, 극미세 고압 마이크로채널에서는 Brinkman 수 $Br = \frac{\mu u^2}{k \Delta T}$가 커질 경우 자가발열 원인이 됨).

#### 2) 고체 도메인 ($\Omega_s$, Si 기판, 금속 Cu 배선, AlN 절연층):
유속 $\mathbf{u} = 0$ 이므로 순수 열전도-발열 방정식으로 귀결:
$$\rho_s c_{p,s} \frac{\partial T}{\partial t} = \nabla \cdot (k_s(T) \nabla T) + \dot{q}_{gen}$$
- $\dot{q}_{gen}$: 트랜지스터 능동층의 스위칭 줄열 및 누설전류 발열원 ($\dot{q}_{gen} = J^2 \rho_{elec} = \frac{P_{active}}{V_{transistor}}$).

---

### 1.4 물질 보존: 대류-확산 방정식 (Species Convection-Diffusion Equation)
전기도금 도금액이나 화학 반응기 내부의 화학종 $i$ (예: $\text{Cu}^{2+}$ 이온) 농도 $C_i$:
$$\frac{\partial C_i}{\partial t} + \mathbf{u} \cdot \nabla C_i = \nabla \cdot (D_i \nabla C_i) + R_i + \frac{z_i F D_i}{R T} \nabla \cdot (C_i \nabla \phi)$$
- $R_i$: 균일계 화학 반응 속도.
- 마지막 항: Nernst-Planck 전기영동(Migration) 항 ($\nabla \phi$: 전위 구배).

---

## 🔗 2. 켤레 열전달 (Conjugate Heat Transfer, CHT) 경계 조건

반도체 칩(고체)과 마이크로채널 냉각수(유체)가 맞닿는 계면 $\Gamma_{w}$에서는 열적·수력학적 연속성 조건이 물리적으로 만족되어야 합니다:

```
               [ Solid Domain: Silicon Chip (ks) ]
                          Temperature Ts
  ─────────────────────── Interface Γw ───────────────────────
                          Temperature Tf
              [ Fluid Domain: Microchannel (kf) ]
```

1. **유체역학 벽면 점착 조건 (No-Slip Condition)**:
   $$\left. \mathbf{u} \right|_{\Gamma_w} = 0 \quad (\text{단, } Kn > 0.001 \text{ 일 때 } u_{slip} = \left. \beta \frac{\partial u}{\partial n}\right|_{\Gamma_w})$$

2. **계면 온도 연속성 (Thermal Continuity)**:
   - 이상적인 접촉일 경우:
     $$\left. T_s \right|_{\Gamma_w} = \left. T_f \right|_{\Gamma_w}$$
   - 계면 열저항(Kapitza / TBR $R_{th,c}$)이 존재할 경우 온도 불연속 발생:
     $$q'' = \frac{T_s - T_f}{R_{th,c}} = G_c (T_s - T_f)$$

3. **계면 열유속 연속성 (Heat Flux Continuity)**:
   $$\left. -k_s \frac{\partial T_s}{\partial \mathbf{n}} \right|_{\Gamma_w} = \left. -k_f \frac{\partial T_f}{\partial \mathbf{n}} \right|_{\Gamma_w} = q''$$
   (여기서 $\mathbf{n}$은 계면의 법선 벡터)

---

## 💻 3. 수치해석 시뮬레이션(FEM/CFD) 모델링 가이드

반도체 소자 열해석을 수행할 때(Elmer FEM, COMSOL Multiphysics, Ansys Fluent, OpenFOAM 등):

1. **분리 해석(Decoupled) vs 완전 연성(Fully Coupled)**:
   - 유체의 점도 $\mu$와 밀도 $\rho$가 온도 변화($\Delta T \approx 10\text{--}30^\circ\text{C}$)에 민감하지 않은 단상 층류의 경우:
     - 1단계: 유동장($\mathbf{u}, P$)을 먼저 단독 해석 (Isothermal Flow).
     - 2단계: 구해진 $\mathbf{u}$ 필드를 에너지 방정식의 대류항에 입력하여 온도장($T$)만 선형 해석 (계산 비용 70% 절감).
   - 비등(Boiling)이나 온도에 따른 급격한 물성 변화 시에는 완전 연성 비선형 솔버(Newton-Raphson) 필수.

2. **메시(Mesh) 경계층 인플레이션 (Boundary Layer Inflation)**:
   - 유체-고체 계면에서 속도 구배와 온도 구배가 매우 가파르므로, 벽면 첫 번째 격자 두께 $y_1$을 열 경계층 두께($\delta_t \approx \delta / \sqrt[3]{Pr}$)보다 최소 5배 이상 미세하게 분할해야 $h$ 및 벽면 전단응력을 정확히 포착할 수 있습니다.

---

## 🔗 Knowledge Connections
- [[반도체_열관리_3대_전달현상_물리개념_및_수식_총람]] : 마스터 개요
- [[반도체 전달현상 핵심 무차원수 총람 (Dimensionless Numbers in Semiconductor Cooling)]] : Navier-Stokes 식의 무차원화
- [[미세유체역학 및 반도체 마이크로채널 냉각 (Microfluidics & On-Chip Microchannels)]] : Navier-Stokes의 Hagen-Poiseuille 해석해
- [[열전도도와 푸리에 법칙 기초 (Thermal Conductivity & Fourier Law)]] : 순수 고체 열전도 방정식
- [[카피차 저항 및 계면 열전도도 (Kapitza Resistance & TBC)]] : CHT 계면 온도 불연속 조건

*Last updated: 2026-10-07*
