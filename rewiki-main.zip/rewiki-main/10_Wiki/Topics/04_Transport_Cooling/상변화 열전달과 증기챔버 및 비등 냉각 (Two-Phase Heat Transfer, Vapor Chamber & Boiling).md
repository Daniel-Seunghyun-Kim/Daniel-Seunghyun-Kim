# [[상변화 열전달과 증기챔버 및 비등 냉각 (Two-Phase Heat Transfer, Vapor Chamber & Boiling)]]

## 📌 Brief Summary
본 문서는 잠열(Latent Heat)을 활용하여 초고열유속($> 500\text{--}1,000\,\text{W/cm}^2$)을 소산시키는 **이상유동(Two-Phase) 열전달, 핵비등 및 임계 열유속(CHF) 한계 물리, 그리고 초박형 증기챔버(Ultra-thin Vapor Chamber, UT-VC)의 모세관 작동 한계 설계 원리**를 다룬 전문 지식 노트입니다.

---

## 🌊 1. 상변화 열전달의 기본 물리와 잠열 메커니즘

단상(Single-phase) 냉각은 유체의 현열($c_p \Delta T$)에만 의존하므로 막대한 유량이 요구되고 흐름 방향으로 심각한 온도 구배가 발생합니다. 반면, 상변화(기화/응축) 냉각은 **기화 잠열($h_{fg}$)**을 흡수하므로 **작동 유체의 온도가 포화온도($T_{sat}$)로 일정하게 유지되면서도 단위 질량당 수십~수백 배의 열량을 운반**할 수 있습니다.

- 물의 기화 잠열 ($100^\circ\text{C}$ 기준): $h_{fg} \approx 2,257\,\text{kJ/kg}$
- FC-72 유전체 냉매: $h_{fg} \approx 88\,\text{kJ/kg}$

---

## 📈 2. 누키야마 비등 곡선과 임계 열유속 (Critical Heat Flux, CHF)

가열 표면 열유속 $q''$과 표면 과열도 $\Delta T_e = T_w - T_{sat}$의 관계 (Nukiyama Boiling Curve):

```
  Log(q'') ▲
           │                     CHF (C점)
           │                    /│
           │                   / │ ＼ (천이 비등)
           │       (핵비등 B-C)/  │   ＼
           │                 /   │     ＼
           │                /    │       \──── (막비등)
           │   (자연대류 A) /      │
           └─────────────────────┴──────────────────► 과열도 ΔTe
                                ΔTe,crit
```

1. **핵비등 영역 (Nucleate Boiling, $B \to C$)**:
   - 표면 미세 기공(Cavity)에서 기포가 연속적으로 생성·이탈하며 주변 유체를 강하게 요동(Micro-convection)시킴.
   - 열전달 계수 $h$가 $10^4 \sim 10^5\,\text{W/m}^2\text{K}$ 수준으로 극대화되는 가장 이상적인 냉각 구간.

2. **임계 열유속 (CHF, $C$점)**:
   - 기화 속도가 너무 빨라 생성된 기포들이 합쳐져 표면을 덮는 연속적인 증기 블랭킷(Vapor blanket)을 형성.
   - Zuber의 유체역학적 CHF 이론식:
     $$q''_{CHF} \approx 0.131 \rho_v^{1/2} h_{fg} \left[ \sigma g (\rho_l - \rho_v) \right]^{1/4}$$
   - **반도체에서의 치명적 영향**:
     CHF를 초과하면 증기막의 극도로 낮은 열전도도($k_v \sim 0.02\,\text{W/mK}$)로 인해 단 수 밀리초(ms) 만에 표면 온도가 수백 도 급상승하여 칩이 소손(Burnout)됩니다.

3. **마이크로채널 유동 비등에서의 조기 건조 (Premature Dryout)**:
   - 밀폐된 좁은 마이크로유로에서는 기포가 채널 직경보다 커지면서 세장형 슬러그(Confined slug)를 형성하여 채널 벽면의 액막(Liquid film)이 급격히 말라버리는 조기 건조(Dryout) 현상이 발생하므로, 다공성 친수성 코팅을 통한 액체 재공급이 필수적입니다.

---

## 🛸 3. 초박형 증기챔버 (Vapor Chamber) 작동 원리 및 설계 방정식

증기챔버는 진공 밀폐된 챔버 내부에 작동 유체(순수 탈기수)와 모세관 위크(Wick) 구조체를 내장한 평면형 히트스프레더입니다.

```
       증발부 (칩 핫스팟 발열) ───► 유체 증발 (흡열) ───► 고속 증기류 이동
           ▲                                                    │
           │                                                    ▼
       모세관 액체 환류 (다공성 위크) ◄─── 유체 응축 (방열) ◄─── 응축부 (냉각핀)
```

### 3.1 모세관 압력 수두 (Capillary Pumping Head)
위크 구조체의 유효 기공 반경 $r_{eff}$와 접촉각 $\theta$:
$$\Delta P_{cap,max} = \frac{2 \sigma \cos\theta}{r_{eff}}$$

### 3.2 유체 순환 압력 평형과 모세관 한계 (Capillary Limit)
증기챔버가 마르지 않고 정상 순환하기 위한 절대 조건:
$$\Delta P_{cap,max} \ge \Delta P_l + \Delta P_v + \Delta P_g$$

1. **액체상 유동 압력 강하 ($\Delta P_l$, Darcy의 법칙)**:
   다공성 위크 내부 층류 유동:
   $$\Delta P_l = \frac{\mu_l \dot{m} L_{eff}}{\rho_l K_{wick} A_{wick}} = \frac{\mu_l \dot{Q} L_{eff}}{\rho_l h_{fg} K_{wick} A_{wick}}$$
   - $K_{wick}$: 위크의 투과율 (Permeability, $\text{m}^2$)
   - $A_{wick}$: 위크 단면적

2. **증기상 유동 압력 강하 ($\Delta P_v$)**:
   증기 코어 공간에서의 마찰 압력 강하:
   $$\Delta P_v = \frac{12 \mu_v \dot{Q} L_{eff}}{\rho_v h_{fg} H_v^3 W_v}$$

### 3.3 4대 작동 한계선 (Operating Limits)

| 작동 한계 | 발생 메커니즘 | 지배 물성치 | 대응 설계 솔루션 |
| :--- | :--- | :--- | :--- |
| **모세관 한계 (Capillary Limit)** | 유동 압력손실이 모세관력을 초과하여 증발부 고갈 | $\Delta P_l + \Delta P_v > \Delta P_{cap}$ | 미세 기공 복합 위크(Composite Wick) 적용 |
| **비등 한계 (Boiling Limit)** | 증발부 위크 내부에서 핵비등 기포가 갇혀 열저항 급증 | $\Delta T_{wick} > \frac{2 \sigma T_{sat}}{\rho_v h_{fg} r_{nuc}}$ | 증발부 고투과율 메쉬 및 고열전도도 분말 소결 |
| **음속 한계 (Sonic Limit)** | 증기 코어 유속이 음속($Ma = 1$)에 도달하여 초크 | $q''_{sonic} = \rho_v h_{fg} \sqrt{\frac{\gamma R T_v}{2(\gamma+1)}}$ | 저온 기동 시 증기 코어 유로 단면적 확보 |
| **비말동반 한계 (Entrainment Limit)** | 고속 증기류가 반대 방향 액체 표면의 액적을 뜯어냄 | $We = \frac{\rho_v u_v^2 \lambda_w}{\sigma} > 1$ | 증기 유로와 액체 유로 간 물리적 메쉬 격벽 분리 |

---

## 🔬 4. 두께 $0.3\,\text{mm}$ 이하 스마트폰/모바일용 초박형 VC (UT-VC) 최신 공학

모바일 AP 및 초슬림 노트북에 탑재되는 $0.25\sim 0.35\,\text{mm}$ 두께의 UT-VC에서는 내부 유로 공간이 극도로 협소하여 증기 유로($H_v$)와 액체 위크($H_w$) 간의 부피 배분이 극한의 최적화 문제입니다.
- **포토 에칭 구리 메쉬 (Chemically Etched Copper Mesh)**: 균일한 기공 구조로 $r_{eff} \sim 25\,\mu\text{m}$, 두께 $50\,\mu\text{m}$ 구현.
- **초친수성 나노와이어 표면 처리**: Cu 메쉬 표면에 CuO 나노플라워/나노와이어를 화학적 산화로 형성하여 접촉각 $\theta \to 0^\circ$ 달성 $\to$ 모세관력 30% 향상 및 CHF 지연.

---

## 🔗 Knowledge Connections
- [[반도체_열관리_3대_전달현상_물리개념_및_수식_총람]] : 마스터 총람
- [[반도체 전달현상 핵심 무차원수 총람 (Dimensionless Numbers in Semiconductor Cooling)]] : $Bo, Ca, We, Ja$ 무차원수 분석
- [[미세유체역학 및 반도체 마이크로채널 냉각 (Microfluidics & On-Chip Microchannels)]] : 단상 vs 이상 쿨링 비교
- [[열확산 저항 (Spreading Resistance)]] : 국소 핫스팟의 평면 2D 열확산 저항 극복
- [[전기-열 상사성과 열저항 회로 (Thermal Resistance Network)]] : 증기챔버 등가 열전도도($k_{eff} > 3,000\,\text{W/mK}$) 모델링

*Last updated: 2026-10-07*
