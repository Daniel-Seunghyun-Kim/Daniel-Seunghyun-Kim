# [[전기-열 상사성과 열저항 회로 (Thermal Resistance Network)]]

## 📌 Brief Summary
전기-열 상사성(Electro-Thermal Analogy)은 열의 전도 현상이 전기의 옴의 법칙(Ohm's Law)과 수학적으로 완벽히 동일한 선형 미분 방정식 구조를 가진다는 원리입니다. 이를 이용하면 복잡한 3D 반도체 패키지와 칩렛의 다층 열전달 경로를 직관적인 전기 저항 회로망(Resistor Network)으로 치환하여 각 층의 접션 온도($T_j$)와 열 병목을 신속하게 계산할 수 있습니다.

## 📖 Core Content

### 1. 전기와 열의 1:1 대응 관계표 (Analogy Table)
| 물리량 | 전기계 (Electrical System) | 열계 (Thermal System) | 비유적 이해 |
| :--- | :--- | :--- | :--- |
| **구동력 (포텐셜)** | 전압차 $\Delta V$ (단위: V) | **온도차 $\Delta T$ (단위: K 또는 $^\circ\text{C}$)** | 높낮이 차이 |
| **흐름 (유량)** | 전류 $I = \frac{dQ}{dt}$ (단위: A = C/s) | **열류량 $q$ (단위: W = J/s)** | 시간당 흐르는 양 |
| **지배 법칙** | 옴의 법칙: $\Delta V = I \cdot R_e$ | **열 전도: $\Delta T = q \cdot R_{\text{th}}$** | 전압차 = 전류 $\times$ 저항 |
| **저항 (장벽)** | 전기저항 $R_e = \rho_e \frac{L}{A} = \frac{L}{\sigma_e A}$ | **열저항 $R_{\text{th}} = \frac{L}{k A}$ (단위: K/W)** | 통로가 좁고 길수록 큼 |
| **에너지 저장** | 커패시턴스 $C_e$ (단위: F) | **열용량 $C_{\text{th}} = \rho c_p V$ (단위: J/K)** | 물탱크 용량 |

### 2. 직렬 및 병렬 열저항 계산
1. **직렬 연결 (층상 적층 구조: Si / 유전체 / 방열판):**
   - 열류 $q$가 동일하게 모든 층을 관통함:
     $$R_{\text{total}} = R_1 + R_2 + R_3 + \dots = \sum_{i} \frac{L_i}{k_i A}$$
     $$\Delta T_{\text{total}} = q \cdot R_{\text{total}}$$
2. **병렬 연결 (하이브리드 본딩: Cu 패드 + 유전체 동시 존재):**
   - 양단의 온도차 $\Delta T$가 동일하며 열류가 분기됨:
     $$\frac{1}{R_{\text{total}}} = \frac{1}{R_{\text{Cu}}} + \frac{1}{R_{\text{dielectric}}}$$
     $$R_{\text{total}} = \frac{R_{\text{Cu}} R_{\text{dielectric}}}{R_{\text{Cu}} + R_{\text{dielectric}}}$$

### 3. 반도체 패키징에서의 적용: 접션 온도($T_j$) 계산
칩 내부 발열원(TDP 파워 $P$, 단위: W)과 외부 냉각수/대기 온도($T_{\text{ambient}}$) 사이의 열저항 경로:
$$T_j = T_{\text{ambient}} + P \cdot \left( R_{\text{die}} + R_{\text{TIM}} + R_{\text{spreader}} + R_{\text{sink}} \right)$$
- **핵심 목표:** 총 열저항 $R_{\text{total}}$을 $0.1 \sim 0.5\,\text{K/W}$ 이하로 낮추어야 $T_j < 85 \sim 105^\circ\text{C}$ 기준을 충족할 수 있습니다.

## 🔗 Knowledge Connections
- **Parent/Higher Topic:** [[열전도도와 푸리에 법칙 기초 (Thermal Conductivity & Fourier Law)]]
- **Sub-Concepts (더 쉬운 개념):** [[반도체 자가발열과 열폭주 메커니즘 (Self-Heating & Thermal Runaway)]]
- **Advanced Transition (심화 전이):** [[열확산 저항 (Spreading Resistance)]], [[카피차 저항 및 계면 열전도도 (Kapitza Resistance & TBC)]]
- **Contradictions/Notes:**
  - 1D 등가 회로망은 열이 수평으로 퍼져나가는 확산 저항(Spreading resistance)이나 계면의 불연속 나노 계면저항을 무시하면 $30 \sim 50\%$ 이상의 심각한 예측 오차를 유발함.

---
*Last updated: 2026-10-07*
