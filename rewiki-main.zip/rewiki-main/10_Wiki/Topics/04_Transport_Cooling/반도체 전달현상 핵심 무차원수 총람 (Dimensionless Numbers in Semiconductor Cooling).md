# [[반도체 전달현상 핵심 무차원수 총람 (Dimensionless Numbers in Semiconductor Cooling)]]

## 📌 Brief Summary
본 문서는 반도체 칩 냉각(마이크로채널, 액침, 히트파이프/증기챔버) 및 박막·패키징 공정(도금, 증착, 에칭)의 설계와 스케일링을 결정짓는 **핵심 무차원수(Dimensionless Numbers) 12종의 수학적 정의, 물리적 의미, 반도체 마이크로/나노 스케일에서의 특이 거동**을 집대성한 전문 지식 노트입니다.

---

## 📐 1. 핵심 무차원수 정의 및 반도체 스케일 물리적 함의

### 1.1 유체역학 무차원수 (Fluid Dynamics)

#### 1) 레이놀즈 수 (Reynolds Number, $Re$)
$$Re = \frac{\rho u D_h}{\mu} = \frac{u D_h}{\nu} = \frac{\text{Inertial Forces (관성력)}}{\text{Viscous Forces (점성력)}}$$
- **반도체 스케일 특성**:
  - 마이크로채널 폭/높이 $D_h \approx 50\text{--}200\,\mu\text{m}$, 냉각수 유속 $u \approx 0.5\text{--}2\,\text{m/s}$ 시:
  $$Re = \frac{(1000\,\text{kg/m}^3)(1\,\text{m/s})(100 \times 10^{-6}\,\text{m})}{1 \times 10^{-3}\,\text{Pa}\cdot\text{s}} = 100 \ll 2300$$
  - 반도체 칩 직접 냉각 채널은 전형적으로 **초층류(Deep Laminar Regime)**에 속합니다. 난류에 의한 자연적 와류 혼합이 발생하지 않으므로, 셰브론(Chevron) 립이나 핀-핀(Pin-fin) 구조를 인위적으로 도입하여 2차 와류(Dean vortex / Vortex shedding)를 유도해야 합니다.

#### 2) 크누센 수 (Knudsen Number, $Kn$)
$$Kn = \frac{\lambda}{L_c} = \frac{\text{Mean Free Path (평균자유행정)}}{\text{Characteristic Length (특성길이)}}$$
- **기체 유동 vs 포논 열전도 상사성**:
  - **기체 (MEMS/진공 챔버)**:
    - $Kn < 0.001$: 연속체 유동 (Navier-Stokes 성립)
    - $0.001 < Kn < 0.1$: 미끄럼 유동 (Slip flow, 벽면에서 $u_{slip} = \left.\beta \frac{\partial u}{\partial y}\right|_{wall}$)
    - $0.1 < Kn < 10$: 천이 유동 (Transition flow)
    - $Kn > 10$: 자유 분자 유동 (Free molecular flow, 클러스터 충돌 무시)
  - **포논 수송 (반도체 박막)**:
    - Si 포논 $\lambda_{ph} \approx 200\text{--}300\,\text{nm}$, AlN 포논 $\lambda_{ph} \approx 100\,\text{nm}$.
    - 하이브리드 본딩 박막 두께 $t \approx 100\,\text{nm}$일 때, $Kn_{ph} = \frac{100\,\text{nm}}{100\,\text{nm}} \approx 1.0$.
    - 푸리에 전도 법칙($q = -k\nabla T$)이 붕괴하고 경계 산란 및 **탄도 포논 수송(Ballistic Transport)**이 발생하여 유효 열전도도 $k_{eff}$가 급감합니다.

---

### 1.2 열전달 무차원수 (Heat Transfer)

#### 3) 프란틀 수 (Prandtl Number, $Pr$)
$$Pr = \frac{\nu}{\alpha} = \frac{\mu / \rho}{k / (\rho c_p)} = \frac{c_p \mu}{k} = \frac{\text{Momentum Diffusivity (운동량 확산계수)}}{\text{Thermal Diffusivity (열 확산계수)}}$$
- **냉각 매체별 비교**:
  - 탈이온수 (DI Water): $Pr \approx 6.0$ ($\delta > \delta_t$, 속도 경계층이 열 경계층보다 두꺼움)
  - 불소계 유전체 냉매 (Fluorinert FC-72, Novec): $Pr \approx 10\text{--}25$
  - 갈륨계 액체 금속 (EGaIn, Galinstan): $Pr \approx 0.015$ ($\delta_t \gg \delta$, 열 확산이 압도적)
  - 공기: $Pr \approx 0.71$

#### 4) 누셀 수 (Nusselt Number, $Nu$)
$$Nu = \frac{h D_h}{k_f} = \frac{\text{Convective Heat Transfer (대류 열전달)}}{\text{Pure Conduction through Fluid Layer (유체 순수전도)}}$$
- **반도체 채널 내 거동**:
  - 층류 완전 발달 영역에서 $Nu = \text{Constant}$ (예: 정사각 단면 균일 열유속 조건 $Nu \approx 3.61$, 평행 평판 $Nu \approx 8.23$).
  - 따라서 $h = \frac{Nu \cdot k_f}{D_h}$ 가 성립하여, **채널 수력직경 $D_h$를 줄일수록 대류 열전달 계수 $h$가 선형적으로 무한히 증가**합니다. 이것이 반도체 냉각에서 마이크로채널($D_h < 100\,\mu\text{m}$)을 필연적으로 채택하는 이론적 근거입니다.

#### 5) 페클레 수 (Péclet Number, $Pe$)
$$Pe = Re \cdot Pr = \frac{u D_h}{\alpha} = \frac{\text{Advective Transport Rate (이류 열수송 속도)}}{\text{Diffusive Transport Rate (분자 확산 열전도 속도)}}$$
- 반도체 채널에서 $Pe \gg 1$이면 유체의 흐름 방향 전도 열전달은 무시할 수 있고 순수 이류(Advection)에 의해 열이 칩 외부로 운반됩니다.

#### 6) 비오 수 (Biot Number, $Bi$)
$$Bi = \frac{h L_c}{k_s} = \frac{\text{Convective Resistance inside/boundary (외부 대류 저항)}}{\text{Conductive Resistance within solid (내부 고체 전도 저항)}}$$
- $Bi < 0.1$: 칩 내부 온도 구배가 없어 집중 열용량 모델(Lumped capacitance model) 적용 가능.
- $Bi \ge 1.0$: 3D 적층 칩에서는 수직 방향 실리콘 및 산화막 층간 전도 저항이 매우 커서 칩 내부 수직 열구배가 심각해집니다.

---

### 1.3 이상유동 및 상변화 무차원수 (Two-Phase & Phase Change)

#### 7) 본드 수 / 에트뵈시 수 (Bond / Eötvös Number, $Bo$)
$$Bo = \frac{g (\rho_l - \rho_v) L_c^2}{\sigma} = \frac{\text{Gravitational Body Forces (중력 체적력)}}{\text{Surface Tension Forces (표면장력)}}$$
- 모세관 특성 길이(Capillary length): $l_{cap} = \sqrt{\frac{\sigma}{g(\rho_l - \rho_v)}} \approx 1.5\text{--}2.5\,\text{mm}$ (물 기준).
- 반도체 마이크로채널 ($D_h \sim 100\,\mu\text{m}$)에서는 $L_c \ll l_{cap}$ 이므로 $Bo \ll 1$ (통상 $Bo < 0.01$).
- **결론**: **중력이나 부력의 영향은 완전히 소멸하며, 모세관력과 표면장력(Surface Tension)이 기포 탈착 및 유동 패턴을 지배**합니다. 챔버가 거꾸로 놓여도 동일하게 냉각되는 원리입니다.

#### 8) 모세관 수 (Capillary Number, $Ca$)
$$Ca = \frac{\mu u}{\sigma} = \frac{\text{Viscous Drag Forces (점성 전단력)}}{\text{Surface Tension Forces (표면장력)}}$$
- 위크(Wick) 구조 및 마이크로유로 내부의 2상 계면 안정성, 액적 분열, 기포 슬러그 유동 거동을 판별합니다.

#### 9) 웨버 수 (Weber Number, $We$)
$$We = \frac{\rho u^2 L_c}{\sigma} = \frac{\text{Inertial Forces (관성 충돌력)}}{\text{Surface Tension Forces (표면장력)}}$$
- 제트 충돌 냉각(Jet Impingement)이나 마이크로 스프레이 쿨링에서 액적의 비산, 비산액막(Liquid film) 형성 유무를 결정짓는 핵심 수입니다.

#### 10) 야콥 수 (Jakob Number, $Ja$)
$$Ja = \frac{\rho_l c_{p,l} (T_w - T_{sat})}{\rho_v h_{fg}} = \frac{\text{Sensible Heat in Superheated Liquid (액체 현열)}}{\text{Latent Heat of Vaporization (기화 잠열)}}$$
- 비등(Boiling) 시 마이크로채널 벽면에서의 기포 반경 성장 속도($R(t) \propto Ja \sqrt{\alpha_l t}$)를 결정합니다.

---

### 1.4 물질전달 무차원수 (Mass Transfer & Electrochemistry)

#### 11) 슈미트 수 (Schmidt Number, $Sc$)
$$Sc = \frac{\nu}{D_{AB}} = \frac{\text{Kinematic Viscosity (운동량 확산)}}{\text{Mass Diffusivity (분자 물질 확산)}}$$
- 액체 전해질(구리 전기도금 도금액)에서 $\nu \sim 10^{-6}\,\text{m}^2/\text{s}$, $D_{\text{Cu}^{2+}} \sim 10^{-9}\,\text{m}^2/\text{s}$ 이므로:
$$Sc \approx 1,000 \gg 1$$
- 이는 **운동량 경계층($\delta$)보다 농도 경계층($\delta_c$)이 약 $\sqrt[3]{Sc} \approx 10$배 얇음**을 의미하며, TSV나 AAO 나노포어 내부로의 이온 공급이 극심한 물질전달 저항(확산 제어)을 겪는 원인입니다.

#### 12) 셔우드 수 (Sherwood Number, $Sh$)
$$Sh = \frac{k_m D_h}{D_{AB}} = \frac{\text{Convective Mass Transfer Rate (대류 물질전달 속도)}}{\text{Diffusive Mass Transfer Rate (순수 분자 확산 속도)}}$$
- 열전달의 누셀 수($Nu$)와 정확히 상사(Analogy) 관계를 가지며, 도금 및 CVD/ALD 증착 반응기 내 확산층 두께를 산출하는 기준이 됩니다.

---

## 📊 2. 반도체 쿨링/공정 영역별 대표 무차원수 정량 비교표

| 냉각 방식 / 공정 분야 | 특성 길이 $L_c$ | 작동 유체 / 매체 | 대표 $Re$ | 대표 $Pr$ 또는 $Sc$ | 지배 무차원수 | 지배적인 물리 현상 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Si 직접 마이크로채널** | $100\,\mu\text{m}$ | DI Water | $100\text{--}300$ | $Pr \approx 6.0$ | $Nu \approx 4\text{--}8$ | 층류 강제대류, $h \propto 1/D_h$ |
| **액체금속 초고열유속 쿨러** | $200\,\mu\text{m}$ | Galinstan | $500$ | $Pr \approx 0.015$ | $Pe \ll Re$ | 점성보다 열전도가 지배 |
| **초박형 증기챔버 (VC)** | $50\,\mu\text{m}$ (위크 공극) | 고순도 수증기/물 | $Re_v \sim 50$ | - | $Bo \ll 0.01$, $Ca < 10^{-3}$ | 표면장력/모세관 한계 지배 |
| **마이크로 유동 비등 쿨링** | $150\,\mu\text{m}$ | FC-72 / HFE-7100 | $200$ | - | $We \sim 5$, $Ja \sim 0.2$ | 슬러그 기포 팽창, CHF 한계 |
| **AAO 코어쉘 Cu 전기도금** | $50\,\text{nm}$ (포어 직경) | 황산구리 전해액 | $Re \approx 0$ | $Sc \approx 1200$ | $Sh \approx 2.0$ | 순수 1차원 확산 물질전달 제어 |
| **초미세 AlN 본딩 박막** | $100\,\text{nm}$ (두께) | 격자 포논(Phonon) | - | - | $Kn_{ph} \ge 1.0$ | 탄도 포논 수송, 카피차 저항 지배 |

---

## 🔗 Knowledge Connections
- [[반도체_열관리_3대_전달현상_물리개념_및_수식_총람]] : 3대 전달현상 총괄 개요 및 마인드맵
- [[미세유체역학 및 반도체 마이크로채널 냉각 (Microfluidics & On-Chip Microchannels)]] : $Re$, $Nu$, 층류 압력강하 최적화
- [[상변화 열전달과 증기챔버 및 비등 냉각 (Two-Phase Heat Transfer, Vapor Chamber & Boiling)]] : $Bo$, $Ca$, $Ja$, CHF 한계 해석
- [[계면 물질전달과 박막 증착 및 전기도금 확산 (Mass Transfer, Thin Film Deposition & Electroplating Diffusion)]] : $Sc$, $Sh$, Fick 확산 및 한계전류밀도
- [[크누센 수와 탄도 열수송 (Knudsen Number & Ballistic Transport)]] : $Kn$ 수 기반 나노포논 열수송 이론

*Last updated: 2026-10-07*
