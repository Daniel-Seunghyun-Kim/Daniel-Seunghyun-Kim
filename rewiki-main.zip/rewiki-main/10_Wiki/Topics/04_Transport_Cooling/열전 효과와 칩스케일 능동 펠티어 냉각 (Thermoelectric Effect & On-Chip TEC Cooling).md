# [[열전 효과와 칩스케일 능동 펠티어 냉각 (Thermoelectric Effect & On-Chip TEC Cooling)]]

## 📌 Brief Summary
본 문서는 국소 핫스팟($> 1,000\,\text{W/cm}^2$)을 능동적으로 제거하기 위해 기계적 가동부 없이 전자 수송만으로 냉각을 수행하는 **열전 효과(제벡, 펠티어, 톰슨)의 물리 이론, $ZT$ 성능지수, 칩스케일 박막 마이크로 열전소자(Micro-TEC)의 열-전기 연성 지배방정식 및 설계 최적화**를 다룬 기술 지식 노트입니다.

---

## ⚡ 1. 3대 열전 효과의 기본 물리와 상호관계

열전 변환(Thermoelectric Energy Conversion)은 고체 내에서 전하 운반자(전자 및 정공)가 열과 전기를 동시에 수송하는 비가역 열역학 현상입니다.

```
       제벡 효과 (Seebeck):   온도 구배 (∇T)  ───►  열기전력 전압 (ΔV)
       펠티어 효과 (Peltier): 인가 전류 (I)   ───►  접합부 흡열/방열 (Q_p)
       톰슨 효과 (Thomson):   전류 + 온도구배 ───►  단일 도선 내부 가역 흡/방열
```

### 1.1 제벡 효과 (Seebeck Effect)
서로 다른 두 도체/반도체의 접합부에 온도차 $\Delta T$가 가해질 때 기전력 $V$가 유도되는 현상:
$$V = S \Delta T \quad \implies \quad \mathbf{E} = S \nabla T$$
- $S$: 제벡 계수 (Seebeck Coefficient, $\text{V/K}$ 또는 $\mu\text{V/K}$)
  - n형 반도체: $S < 0$ (전자가 저온부로 이동)
  - p형 반도체: $S > 0$ (정공이 저온부로 이동)

### 1.2 펠티어 효과 (Peltier Effect)
서로 다른 물질의 접합면에 전류 $I$가 통과할 때 단위 시간당 흡수 또는 방출되는 가역적 열량 $Q_P$:
$$Q_P = \Pi_{AB} I = (S_A - S_B) T I$$
- $\Pi$: 펠티어 계수 (Peltier Coefficient, $\text{W/A}$ 또는 $\text{V}$)
- **켈빈의 제1 관계식 (1st Kelvin Relation)**:
  $$\Pi = S \cdot T$$

### 1.3 톰슨 효과 (Thomson Effect)
온도 구배가 존재하는 단일 도체에 전류가 흐를 때 발생하는 흡열/방열 열유속:
$$\dot{q}_{Thomson} = -\tau \mathbf{J} \cdot \nabla T$$
- **켈빈의 제2 관계식 (2nd Kelvin Relation)**:
  $$\tau = T \frac{dS}{dT}$$

---

## 📐 2. 펠티어 냉각 성능 지수와 열-전기 연성 방정식

열전 냉각기(TEC)의 냉각단(Cold side, 온도 $T_c$)에서 외부 핫스팟으로부터 실제로 흡수하는 유효 냉각열량 $Q_c$:
$$Q_c = S T_c I - \frac{1}{2} I^2 R - K (T_h - T_c)$$

```
   [유효 흡열량 Qc] = [펠티어 흡열: S*Tc*I] - [줄열 역류: 0.5*I^2*R] - [푸리에 열전도 누설: K*ΔT]
```
- $R$: TEC 레그의 총 내부 전기저항 ($R = \frac{L}{\sigma A}$)
- $K$: TEC 레그의 총 고체 열컨덕턴스 ($K = \frac{k A}{L}$)
- **트레이드오프(Trade-off)**:
  냉각 효과를 높이려고 전류 $I$를 과도하게 올리면, 펠티어 효과($\propto I$)보다 내부 줄열 발열($\propto I^2$)이 훨씬 빠르게 증가하여 오히려 냉각단 온도가 폭등합니다.

### 2.1 최적 작동 전류 ($I_{opt}$) 및 최대 냉각 열량 ($Q_{c,max}$)
유효 냉각량 $Q_c$를 전류 $I$에 대해 미분($\frac{\partial Q_c}{\partial I} = 0$):
$$I_{opt} = \frac{S T_c}{R}$$
이때 달성 가능한 최대 냉각 열량:
$$Q_{c,max} = \frac{S^2 T_c^2}{2 R} - K (T_h - T_c)$$

### 2.2 무부하 최대 냉각 온도차 ($\Delta T_{max}$)
핫스팟 발열이 0인 상태($Q_c = 0$)에서 펠티어 소자가 만들어낼 수 있는 극한의 온도차:
$$\Delta T_{max} = T_h - T_c = \frac{1}{2} Z T_c^2$$
여기서 **$Z$ (무차원 성능지수 $ZT$)**는 다음과 같이 정의됩니다:
$$Z = \frac{S^2 \sigma}{k} = \frac{S^2}{\rho_{elec} k} \quad \implies \quad ZT = \frac{S^2 \sigma T}{k_e + k_l}$$
- $S^2 \sigma$: 열전 파워 팩터 (Power Factor, PF)
- $k_e$: 전자에 의한 열전도도 (Wiedemann-Franz 법칙에 의해 $\sigma$와 비례)
- $k_l$: 격자 포논에 의한 열전도도

---

## 🎯 3. 온칩 박막 마이크로 TEC (On-Chip Thin-Film TEC) 혁신

기존 벌크 TEC(수 밀리미터 두께)는 열용량이 커서 응답 속도가 초($\text{s}$) 단위이며 부피가 큽니다. 반면, 반도체 웨이퍼 레벨에서 직접 스퍼터링 또는 전기도금으로 제작되는 **박막 마이크로 TEC (두께 $1\text{--}10\,\mu\text{m}$)**는 반도체 열관리에 혁명적 변화를 가져옵니다.

```
       [ Silicon Active Die (Hotspot) ]
       ────────────────── Cold Side (Micro-TEC) ──────────────────
         [ p-Bi2Te3 ]  [ n-Bi2Te3 ]  (Thickness: 5~10 μm)
       ────────────────── Hot Side (Heat Sink) ───────────────────
       [ Copper Heat Spreader / Cold Plate ]
```

1. **초고속 응답 속도**:
   - 두께가 $1/100$로 축소되면서 열확산 시간 $t_{diff} \approx \frac{L^2}{\alpha}$가 수 초에서 **수 밀리초(Sub-milliseconds, $\sim 1\text{--}5\,\text{ms}$)**로 단축되어 CPU/GPU의 터보 부스트 핫스팟에 실시간 동적 대응 가능.
2. **초고밀도 국소 냉각 열유속**:
   - $Q_{c} \propto \frac{1}{L}$ 스케일링으로 단위 면적당 **$1,000\,\text{W/cm}^2$ 이상의 국소 열유속**을 핫스팟에서 즉각 빨아들여 전체 히트스프레더로 펌핑.
3. **포논 차단 초격자(Superlattice) 공학**:
   - $\text{Bi}_2\text{Te}_3 / \text{Sb}_2\text{Te}_3$ 나노 초격자를 증착하여 계면에서 음향 포논만 강력하게 산란시켜 격자 열전도도 $k_l$을 벌크 대비 $1/3$로 억제 $\to$ **$ZT > 2.4$ 달성**.

---

## 🔗 Knowledge Connections
- [[반도체_열관리_3대_전달현상_물리개념_및_수식_총람]] : 마스터 총람
- [[반도체 자가발열과 열폭주 메커니즘 (Self-Heating & Thermal Runaway)]] : 줄열과 핫스팟 메커니즘
- [[포논 산란 기작의 역사와 마티센 규칙 (Phonon Scattering Mechanisms)]] : 격자 포논 산란을 통한 $ZT$ 극대화 물리
- [[열확산 저항 (Spreading Resistance)]] : 마이크로 TEC와 히트스프레더 결합 방열
- [[전기-열 상사성과 열저항 회로 (Thermal Resistance Network)]] : 능동 열전원 포함 열회로 모델

*Last updated: 2026-10-07*
