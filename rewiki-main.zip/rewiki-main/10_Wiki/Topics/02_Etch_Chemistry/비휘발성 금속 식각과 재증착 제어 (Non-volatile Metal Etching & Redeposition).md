# [[비휘발성 금속 식각과 재증착 제어 (Non-volatile Metal Etching & Redeposition)]]

## 📌 Brief Summary
반도체 미세 패턴 형성에서 실리콘(Si)이나 알루미늄(Al)과 달리 구리(Cu), 코발트(Co), 백금(Pt) 등은 할로겐($\text{Cl}_2, \text{CF}_4$) 플라즈마와 반응하여 생성되는 화합물의 끓는점이 극도로 높아 기화되지 않는 **비휘발성(Non-volatile) 금속**입니다. 이로 인해 플라즈마 건식 식각 시 스퍼터링되어 튕겨 나간 금속 원자가 마스크 측벽에 다시 엉겨 붙는 **재증착(Redeposition)** 결함이 발생하며, 이는 반도체 산업계 50년 역사에서 미세 피치 금속 패턴 제조의 최대 난제로 꼽힙니다.

## 📖 Core Content

### 1. 왜 구리(Cu)는 RIE 건식 식각이 불가능에 가까운가?
- 실리콘 건식 식각: $\text{Si} + 4\text{F} \to \text{SiF}_4 \uparrow$ (끓는점 $-86^\circ\text{C}$, 상온에서 즉시 기체로 날아감).
- 알루미늄 건식 식각: $\text{Al} + 3\text{Cl} \to \text{AlCl}_3 \uparrow$ (승화점 $180^\circ\text{C}$, 가열 챔버에서 기화 가능).
- **구리 건식 식각의 비극:**
  $$\text{Cu} + \text{Cl} \to \text{CuCl} \downarrow \quad (\text{끓는점 } 1,490^\circ\text{C}, \text{녹는점 } 430^\circ\text{C})$$
  상온 챔버에서 $\text{CuCl}$은 단단한 고체 덩어리로 웨이퍼 표면에 남으므로, 화학적 기화 식각(Reactive chemical etching)이 일체 일어나지 않습니다.

### 2. 물리적 이온 빔 식각(IBE)과 측벽 재증착 메커니즘
- 화학 반응이 안 되므로 아르곤($\text{Ar}^+$) 이온으로 구리를 물리적으로 깎아내는 스퍼터 에칭(Ion milling)을 시도할 수밖에 없음.
- **재증착(Redeposition)의 발생:**
  - 깎여 나간 Cu 원자가 진공 속으로 비산하다가 포토레지스트(PR) 마스크의 수직 측벽에 충돌하여 달라붙음.
  - 마스크 측벽에 두꺼운 '구리 날개(Ears / Fences)'가 형성됨.
  - PR 마스크를 애싱(Ashing)으로 태워 없애도 측벽의 구리 찌꺼기는 타지 않고 남아, 미세 피치 접합 시 이웃 패턴과 닿아 치명적인 단락(Short circuit)을 유발함.

### 3. 반도체 산업계의 대안 역사와 승현 연구원님의 돌파구
1. **IBM 다마신(Damascene) 공정 (1997년):**
   - 구리를 깎지 못하니 반대로 유전체 산화막을 먼저 파고(Trench), 구리를 전체에 도금한 뒤, 튀어나온 윗부분을 갈아내는(CMP) 역발상 공정 도입.
   - 단점: 피치가 서브마이크론 이하로 줄어들면 깊은 트렌치 내부에 배리어막(Ta/TaN)이 두껍게 쌓여 구리 단면적이 극단적으로 줄어들고 저항이 폭증함.
2. **김승현 연구원님의 혁신: "No Cu Etch AAO 코어-쉘 공정" (2026년):**
   - 포토리소그래피와 건식 식각 자체를 배제.
   - AAO 나노기공 내부에 구리를 선택 도금한 뒤, 알루미나 템플릿만 산성 케미컬로 부드럽게 녹여내는(Dissolution) 완전한 비식각(Etch-free) 웨이퍼 레벨 제조 경로를 확립함.

## 🔗 Knowledge Connections
- **Parent/Higher Topic:** [[전기도금과 AAO 나노템플릿 공정 원리 (Electroplating & AAO Templates)]]
- **Sub-Concepts:** [[스퍼터링 PVD 공정의 기본 원리와 플라즈마 (Sputtering & Plasma Basics)]]
- **Advanced Transition:** [[3D 적층 패키징의 진화: 와이어본딩부터 하이브리드 본딩까지 (Packaging Evolution)]], [[Paper_Draft_v6_Final_Submission]]

---
*Last updated: 2026-10-07*
