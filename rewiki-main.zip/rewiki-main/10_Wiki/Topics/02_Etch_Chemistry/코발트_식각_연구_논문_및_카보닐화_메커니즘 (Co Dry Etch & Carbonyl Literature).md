# [[코발트_식각_연구_논문_및_카보닐화_메커니즘 (Co Dry Etch & Carbonyl Literature)]]

## 📌 Brief Summary
본 문서는 10nm 이하 최첨단 반도체 로직 노드(M0, M1 최하위 배선)에서 구리의 대체재로 부상한 코발트(Co)의 **건식 식각 난제, 카보닐화($\text{CO}/\text{NH}_3$) 기화 메커니즘, 아세톤/유기 플라즈마 RIE, 열적 원자층 식각(Thermal ALE), 그리고 핵심 학술 논문군과 150/300nm 패턴 공정 실증 데이터**를 집대성한 문헌 총람입니다.

---

## ⚡ 1. 코발트(Co) 배선 도입 배경과 건식 식각 난제

반도체 선폭이 10nm 이하로 진입하면서, 구리(Cu)의 심각한 일렉트로마이그레이션(EM) 단선 및 비저항 폭증 문제를 해결하기 위해 Intel(10nm/7nm), TSMC, imec을 중심으로 **코발트(Co) 인터커넥트**가 전격 도입되었습니다.

```
       [ 장점 ]  1. 짧은 전자 평균자유행로 (λ_Co ≈ 10 nm vs λ_Cu ≈ 39 nm)
                2. 강력한 금속간 결합력 (녹는점: Co 1,495 °C vs Cu 1,085 °C)
                3. EM 활성화 에너지가 Cu 대비 약 2배 높아 수명 수십 배 연장
                4. 초박형 라이너(TiN 1 nm) 또는 배리어-프리 적용 가능
```

### 1.1 Co 식각의 열역학적 병목
그러나 코발트 역시 염소계 플라즈마에서 생성되는 염화코발트($\text{CoCl}_2$)의 증기압이 극도로 낮습니다.
- $\text{CoCl}_2$의 융점은 $735^\circ\text{C}$, 비점은 $1,049^\circ\text{C}$에 달하여 실온에서 자발적 기화가 불가능합니다.
- 물리적 이온 스퍼터링에만 의존할 경우 심각한 마이크로 트렌칭(Micro-trenching), 마스크 선택비 저하, 측벽 재증착 및 잔류물(Residue)이 발생합니다.

---

## 🔬 2. 코발트 건식 식각 3대 기술 및 핵심 논문군

```
  [경로 1: 카보닐화 RIE]     Co + CO / NH3  ──► Co2(CO)8 / HCo(CO)4 (승화점: ~52 °C)
  [경로 2: 유기용매 ICP-RIE] Co + Acetone/Ar ──► 유기 금속 라디칼 탈착
  [경로 3: Thermal ALE]     Co + Cl2 / O2  ──► CoCl2 / CoO ──► + Hhfac ──► Co(hfac)2 ↑
```

---

### 2.1 경로 1: 카보닐화 플라즈마 식각 ($\text{CO}/\text{NH}_3$ Carbonylation)
- **핵심 반응 메커니즘**:
  몬드 공정(Mond Process)의 금속 카보닐화 반응을 플라즈마 화학에 응용. 일산화탄소($\text{CO}$)와 암모니아($\text{NH}_3$) 혼합 가스를 이용하여 상온~저온에서 증기압이 높은 **옥타카보닐다이코발트($\text{Co}_2(\text{CO})_8$, 승화점 $\approx 51.8^\circ\text{C}$)** 또는 하이드라이드 착물($\text{HCo(CO)}_4$)을 형성시켜 기화 배출:
  $$\text{Co (s)} + 4\text{CO (g)} + \frac{1}{2}\text{H}_2 \text{ (from }\text{NH}_3\text{)} \longrightarrow \text{HCo(CO)}_4 \uparrow$$
- **주요 논문**:
  - **Lee, Chang et al. (2010)**, *J. Vac. Sci. Technol. A* 28, 971: $\text{CO}/\text{NH}_3$ 유도결합 플라즈마(ICP)를 이용하여 $60^\circ\text{C}$ 이하에서 Co 박막의 화학적 건식 식각 최초 실증.
  - **Kastenmeier et al. (2011)**, *IEEE Trans. Semicond. Manuf.*: $\text{CO}/\text{NH}_3$ 가스비 및 ICP 소스 파워에 따른 식각 속도와 마스크 선택비 정량화.
  - **Chang et al. (2013)**, *Microelectron. Eng.* 106, 114: 고밀도 플라즈마에서 $\text{CO}$ 분해로 인한 표면 탄소 침적(Carbon Passivation)과 에칭 간의 경쟁 모델 제시.

---

### 2.2 경로 2: 유기 용매 플라즈마 식각 (Acetone/Ar ICP-RIE)
- **핵심 반응 메커니즘**:
  아세톤($\text{CH}_3\text{COCH}_3$) 플라즈마에서 생성되는 카보닐기($\text{C=O}$) 및 메틸 라디칼이 코발트 표면 원자와 결합하여 유기 착화합물 형태로 저온 승화 유도.
- **실증 연구 및 로컬 데이터 연계 (`D:\CuCo_Etch_Research_Package_20260706`)**:
  - 로컬 연구 패키지(`SEM_data_F_E Co PPTX set`)에서 확인된 실증 스택:
    - $\text{PR} / \text{BARC} / \text{SiO}_2 / \text{Si}_3\text{N}_4 / \text{Co} / \text{Ti} / \text{Si}$
  - **150 nm 및 300 nm 미세 패턴**에서 Acetone/Ar 및 $\text{Cl}_2/\text{Ar}$ ICP-RIE를 통한 수직 프로파일 형성 및 측벽 잔류물(Residue) 제어 조건 확립.
  - 아세톤 도입 시 $\text{Cl}_2$ 단독 조건 대비 측벽 언더컷(Undercut)을 억제하면서 잔류물 없는 매끄러운 단면 달성.

---

### 2.3 경로 3: 코발트 열적 원자층 식각 (Co Thermal ALE)
- **핵심 반응 메커니즘 (2-Step Self-limiting Etch)**:
  - **Step 1 (염화/산화 반응)**: 코발트 표면을 $\text{Cl}_2$ 가스로 노출시켜 단분자층 수준의 $\text{CoCl}_2$ 형성.
    $$\text{Co (s)} + \text{Cl}_2 \text{ (g)} \longrightarrow \text{CoCl}_2 \text{ (s)}$$
  - **Step 2 (리간드 교환 및 착화 기화)**: $\beta$-diketone 리간드인 $\text{Hhfac}$ (Hexafluoroacetylacetone) 증기를 주입하여 휘발성 착화합물 형성 배출:
    $$\text{CoCl}_2 \text{ (s)} + 2\text{Hhfac (g)} \longrightarrow \text{Co(hfac)}_2 \uparrow + 2\text{HCl} \uparrow$$
- **주요 논문**:
  - **Konh et al. (2019)**, *J. Vac. Sci. Technol. A* 37, 021004: $\text{Cl}_2$와 $\text{Hhfac}$을 이용한 코발트의 Thermal ALE 메커니즘 in-situ FTIR 및 QMS 분석. $150\text{--}190^\circ\text{C}$에서 포화된 자기제한적 식각 속도($\sim 0.5\,\text{nm/cycle}$) 입증.
  - **George et al. (2018)**, *Chem. Mater.* 30, 2469: 유기 리간드 열화학적 교환을 통한 전이금속(Co, Fe, Ni)의 선택적 표면 식각 이론.

---

## 📊 3. 코발트 식각 케미스트리별 성능 및 공정 특성 대조표

| 식각 공정군 | 화학 가스계 | 반응 온도 | 주 부산물 및 반응 메커니즘 | 장점 | 공정상 주의점 / 한계 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **카보닐화 RIE** | $\text{CO} / \text{NH}_3 / \text{Ar}$ | $50\text{--}80^\circ\text{C}$ | $\text{Co}_2(\text{CO})_8 \uparrow$, $\text{HCo(CO)}_4 \uparrow$ | 독성 할로겐 미사용, 순수 저온 기화 | $\text{CO}$ 가스 독성 및 챔버 카본 폴리머 침적 |
| **유기 RIE** | $\text{CH}_3\text{COCH}_3 / \text{Ar}$ | $40\text{--}100^\circ\text{C}$ | 유기 착화 라디칼 탈착 | 150/300nm 패턴 수직도 확보, 저온 | 플라즈마 파워 불균일 시 잔류물 발생 |
| **염소계 RIE** | $\text{Cl}_2 / \text{Ar} / \text{BCl}_3$ | $150\text{--}200^\circ\text{C}$ | 물리적 스퍼터링 + 고온 $\text{CoCl}_2$ 탈착 | 빠른 식각률 ($> 100\,\text{nm/min}$) | 심각한 측벽 재증착 및 대기 노출 시 부식(Corrosion) |
| **Thermal ALE** | $\text{Cl}_2 \to \text{Hhfac}$ | $150\text{--}190^\circ\text{C}$ | 리간드 교환: $\text{Co(hfac)}_2 \uparrow$ | 원자 수준 거칠기($R_q < 0.2\,\text{nm}$), 무손상 | 사이클 시간 길고 고가 리간드 전구체 소모 |

---

## 🔗 Knowledge Connections
- [[구리_식각_연구_논문_및_화학반응_총람 (Cu Dry Etch & ALE Literature)]] : Cu 건식 식각의 한계 및 역사
- [[전자_평균자유행로_미만_금속배선_저항_역전현상_분석 (Resistivity Crossover)]] : Co 배선이 sub-10nm에서 Cu 저항을 역전하는 근본 물리
- [[석박사_연구연계_로드맵_식각난제에서_무식각_CuAlN_하이브리드본딩까지]] : 석사 Co/Cu 식각에서 박사 무식각 아키텍처로의 도약
- [[비휘발성 금속 식각과 재증착 제어 (Non-volatile Metal Etching & Redeposition)]] : 금속 식각의 공통 재증착 이슈

*Last updated: 2026-10-07*
