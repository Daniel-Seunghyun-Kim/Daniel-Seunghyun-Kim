# [[구리_식각_연구_논문_및_화학반응_총람 (Cu Dry Etch & ALE Literature)]]

## 📌 Brief Summary
본 문서는 반도체 및 디스플레이 초미세 배선에서 구리(Cu)의 건식 식각(Dry Etch)과 원자층 식각(Atomic Layer Etch, ALE)의 **물리화학적 반응 메커니즘, 할로겐화 부산물의 비휘발성 난제, 유기 리간드 착화(Chemical/Chelation) 케미스트리, 그리고 1980년대 초기 RIE부터 2026년 최신 Thermal ALE에 이르는 핵심 논문군**을 집대성한 문헌 총람입니다.

---

## ⚗️ 1. 구리 건식 식각의 근본적인 열역학적 난제

반도체 표준 인터커넥트 금속인 구리(Cu)는 알루미늄(Al)이나 텅스텐(W)과 달리 **할로겐 플라즈마 반응 부산물이 상온에서 기화되지 않는 치명적인 열역학적 한계**를 가집니다.

```
       Al  +  3 Cl  ──►  AlCl3   (비점: 180 °C  ──► 실온 RIE 용이)
       W   +  6 F   ──►  WF6     (비점:  17 °C  ──► 실온 RIE 용이)
       Cu  +  x Cl  ──►  CuClx   (비점: 1,490 °C ──► 실온 기화 절대 불가!)
```

### 1.1 CuCl의 낮은 증기압과 재증착 (Redeposition)
- $\text{CuCl}$의 융점은 $430^\circ\text{C}$, 비점은 $1,490^\circ\text{C}$입니다. 상온($20\sim 80^\circ\text{C}$)에서 $\text{CuCl}$의 증기압은 $10^{-8}\,\text{Torr}$ 이하로 사실상 0에 가깝습니다.
- **결과적 실패 모드**:
  1. 순수 염소($\text{Cl}_2$) 플라즈마 노출 시 구리 표면에 두꺼운 $\text{CuCl}_x$ 염화물 층만 형성되고 에칭되지 않음.
  2. 높은 기판 바이어스를 걸어 물리적 스퍼터링(Physical Sputtering)을 유도할 경우, 뜯겨 나온 구리 원자가 패턴 측벽(Sidewall)에 달라붙는 **재증착(Redeposition)**이 발생하여 배선 간 전기적 단락(Bridge short) 유발.
  3. 이 물리적 한계로 인해 반도체 산업계는 1997년 IBM 주도로 감산형 식각(Subtractive Etch)을 포기하고 **CMP 기반 다마신(Damascene) 공정**으로 우회했습니다.

---

## 🔬 2. 구리 건식 식각 접근법의 기술적 진화 및 논문군

```
  [1980s~1990s] 고온 할로겐 RIE (T > 220 °C)  ──► 기판 열손상, PR 마스크 버닝
         │
  [2000s~2010s] 유기 리간드 착화 RIE (C2H5OH, CH3COOH, CH4) ──► 카르복실산/알코올
         │
  [2015s~2026s] 열적 원자층 식각 (Thermal ALE: Oxidation + Ligand Exchange)
```

---

### 2.1 고온 할로겐 반응성 이온 식각 (High-Temperature Halogen RIE)
- **핵심 원리**: 기판 온도를 $\text{CuCl}$이 승화하기 시작하는 $200\sim 250^\circ\text{C}$ 이상으로 가열하여 플라즈마 화학 에칭을 유도.
- **주요 논문**:
  - **Schwartz & Schaible (1983)**, *J. Electrochem. Soc.* 130, 1777: $\text{CCl}_4/\text{Ar}$ 플라즈마를 이용하여 $225^\circ\text{C}$ 이상에서 Cu 반응성 식각 최초 보고.
  - **Howard (1991)**, *Appl. Phys. Lett.* 58, 2073: $\text{SiCl}_4/\text{Ar}$ 및 $\text{Cl}_2$ RIE에서 기판 온도에 따른 Cu 식각률($\text{ER}$)의 아레니우스 거동 입증.
  - **한계**: $200^\circ\text{C}$ 이상의 고온에서는 유기 포토레지스트(PR)가 탄화·버닝되며, 층간 절연막(Low-k)의 열화 및 거친 표면 조도 유발.

---

### 2.2 유기 리간드 착화 RIE (Organic & Chelation Chemistries)
- **핵심 원리**: 구리와 배위 결합하여 낮은 온도에서도 증기압이 높은 유기 금속 착화합물(Organometallic Complexes)을 형성시켜 기화.
- **주요 반응 가스군 및 논문**:
  1. **$\beta$-Diketone 케미스트리 ($\text{Hfac}$, $\text{Acac}$)**:
     - **Farkas et al. (1993)**, *Appl. Phys. Lett.* 62, 3562: 구리 산화막($\text{CuO}_x$)과 Hfac(Hexafluoroacetylacetone)이 반응하여 휘발성 $\text{Cu(hfac)}_2$ 형성 및 기화 실증.
     - $\text{CuO} + 2\text{Hhfac} \to \text{Cu(hfac)}_2 \uparrow + \text{H}_2\text{O}$ (반응 온도: $120\sim 180^\circ\text{C}$).
  2. **알코올 & 카르복실산 플라즈마 ($\text{C}_2\text{H}_5\text{OH}$, $\text{CH}_3\text{COOH}$)**:
     - **Kuo et al. (2001, 2004)**, *J. Electrochem. Soc.* 148, G477: 상온 부근에서 에탄올/아르곤 및 아세트산($\text{CH}_3\text{COOH}$) 플라즈마를 이용한 Cu 박막 식각.
     - **Tamir et al. (2002)**, *Microelectron. Eng.*: 카르복실산 라디칼이 Cu와 반응하여 아세트산 구리($\text{Cu(CH}_3\text{COO)}_2$) 착물을 형성해 탈착되는 기작 제시.
  3. **메탄/수소계 플라즈마 ($\text{CH}_4/\text{Ar}$, $\text{CH}_4/\text{O}_2/\text{Ar}$)**:
     - 메틸 라디칼($\text{CH}_3^\bullet$)과 반응하여 유기 구리 중간체를 형성하되, 표면에 폴리머 보호막을 형성하여 이방성(Anisotropy)을 확보하는 메커니즘.

---

### 2.3 구리 원자층 식각 (Thermal Atomic Layer Etching, Cu ALE)
- **핵심 원리**: 자기제한적(Self-limiting) 2단계 사이클 반응을 통해 원자 단위로 구리를 정밀 제거.
  - **Step A (표면 개질)**: $\text{O}_2$, $\text{O}_3$, 또는 $\text{H}_2\text{O}_2$ 플라즈마/증기를 이용해 표면 Cu를 $\text{Cu}_2\text{O}/\text{CuO}$로 산화.
  - **Step B (착화 및 휘발)**: $\text{Hhfac}$ 또는 Formic acid, Acetic acid 기체를 주입하여 선택적으로 구리 산화물만 착화합물로 기화 배출.
- **주요 논문**:
  - **S. M. George et al. (2017)**, *ACS Nano* 11, 7008: 금속의 Thermal ALE 이론적 프레임워크 정립.
  - **Minaye Hashemi et al. (2018)**, *ACS Appl. Mater. Interfaces* 10, 34746: $\text{O}_2/\text{Hhfac}$ 사이클을 통한 구리의 열적 원자층 식각 실증 (EPC: Etch per Cycle $\sim 0.1\text{--}0.3\,\text{nm/cycle}$).
  - **Rauf et al. (2018)**, *J. Appl. Phys.*: Cu ALE 반응기 내부의 표면 반응 동역학 수치 해석.

---

## 📊 3. 구리 식각 공정군별 비교 대조표

| 공정 방식 | 대표 가스 조성 | 작동 기판 온도 | 식각 메커니즘 | 주요 장점 | 공학적 치명적 한계 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **고온 염소 RIE** | $\text{Cl}_2 / \text{Ar} / \text{BCl}_3$ | $220\text{--}300^\circ\text{C}$ | 열적 $\text{CuCl}_x$ 승화 | 높은 식각률 ($> 200\,\text{nm/min}$) | PR 탄화 버닝, Low-k 절연막 파괴 |
| **알코올/유기산 RIE** | $\text{CH}_3\text{COOH} / \text{Ar}$, $\text{C}_2\text{H}_5\text{OH}$ | $50\text{--}150^\circ\text{C}$ | 구리 카르복실레이트 착화 기화 | 저온 공정 가능, 마스크 손상 완화 | 탄소 잔류물(Carbon residue), 낮은 식각률 |
| **메탄계 ICP-RIE** | $\text{CH}_4 / \text{O}_2 / \text{Ar}$ | 상온 $\sim 80^\circ\text{C}$ | 메틸기 착화 + 측벽 탄소 패시베이션 | 우수한 수직 프로파일 (이방성) | 챔버 윈도우 탄소 폴리머 오염 심각 |
| **Thermal ALE** | $\text{O}_2 \to \text{Hhfac}$ (Cyclic) | $130\text{--}180^\circ\text{C}$ | 2단계 산화-리간드 교환 기화 | 원자단위 표면 평탄성 ($R_q < 0.3\,\text{nm}$) | 극도로 느린 생산성 ($< 1\,\text{nm/min}$) |

---

## 🔗 Knowledge Connections
- [[코발트_식각_연구_논문_및_카보닐화_메커니즘 (Co Dry Etch & Carbonyl Literature)]] : Cu의 대안인 Co 건식 식각 문헌
- [[전자_평균자유행로_미만_금속배선_저항_역전현상_분석 (Resistivity Crossover)]] : Cu 식각 한계가 미세 배선 저항 역전과 만나는 지점
- [[석박사_연구연계_로드맵_식각난제에서_무식각_CuAlN_하이브리드본딩까지]] : 석사 Cu 식각 연구에서 박사 바텀업 도금/하이브리드 본딩으로의 진화
- [[비휘발성 금속 식각과 재증착 제어 (Non-volatile Metal Etching & Redeposition)]] : CuCl 재증착 물리 기초

*Last updated: 2026-10-07*
