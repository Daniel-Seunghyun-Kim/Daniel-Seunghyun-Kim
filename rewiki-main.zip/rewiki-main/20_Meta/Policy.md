# [[Policy]] - P-Reinforce 지식 에이전트 정책 (RL Policy & Hyperparameters)

## 📌 한 줄 통찰 (The Karpathy Summary)
> "지식의 배치는 고정된 규칙이 아니라, 그래프 연결도와 사용자 피드백을 최대화하는 강화학습 정책에 의해 끊임없이 진화한다."

---

## 🧠 1. 강화학습 보상 함수 (Reward Function Formulation)

P-Reinforce 엔진이 지식 노드를 배치, 연결, 리팩토링할 때 극대화하는 목표 보상 함수:

$$R = w_1 \cdot \mathcal{S}_{\text{categorization}} + w_2 \cdot \mathcal{C}_{\text{connectivity}} + w_3 \cdot \mathcal{U}_{\text{feedback}}$$

### 1.1 보상 파라미터 및 현재 가중치 (Current Weights)
| 가중치 | 대상 요소 | 현재 값 | 최적화 목표 |
| :---: | :--- | :---: | :--- |
| **$w_1$** | **Categorization Accuracy** | **0.40** | 문서 내용과 폴더 주제 간의 시맨틱 유사도 ($\ge 85\%$) 보장 |
| **$w_2$** | **Graph Connectivity** | **0.35** | 문서당 유효 [[쌍방향 링크]] 최소 2개 이상, 고립 노드(Orphan Node) 발생 방지 |
| **$w_3$** | **User Feedback** | **0.25** | 사용자 명시적 칭찬(+1.0), 위치 수정(-0.5), 지속적 인용 및 열람 보상 |

---

## 📐 2. 행동 정책 및 상태 전이 규칙 (Action Policy & Transition Rules)

1. **카테고리 할당 규칙 (Clustering Threshold)**:
   - 코사인 유사도 $S \ge 0.85$ : 기존 하위 카테고리 자동 편입
   - 코사인 유사도 $S < 0.85$ : 신규 상위/하위 개념을 자동 도출하여 신규 폴더 생성
2. **폴더 리팩토링 임계치 (Refactoring Threshold)**:
   - 단일 폴더 내 파일 개수가 **12개 초과** 시, 정보 과밀(Cognitive Overload) 방지를 위해 세부 하위 카테고리로 자동 분기(Branching) 제안
3. **영속적 위키 템플릿 강제**:
   - 모든 신규/개정 문서는 Karpathy 규격 YAML Frontmatter (`id`, `category`, `confidence_score`, `last_reinforced`), 한 줄 통찰, 구조화된 지식, 모순/업데이트, 지식 연결(Parent/Related/Raw)을 필수 포함

---

## 📊 3. 현재 지식 지형도 상태 (Current State Vector - 2026-10-08)

```json
{
  "total_knowledge_nodes": 71,
  "total_graph_edges": 595,
  "mean_degree_connectivity": 16.76,
  "isolated_orphan_nodes": 0,
  "current_reward_score": 0.9831,
  "categorization_accuracy": 0.9577,
  "graph_connectivity_score": 1.0000,
  "clusters_identified": 7,
  "active_policy_version": "v2.2-Karpathy-RL"
}
```

---

## 📝 4. 사용자 피드백 및 정책 갱신 이력 (Reward Log)

- **2026-10-08 (Episode 10:45)**: Periodic gardening cycle (71 nodes, 595 edges) $\to$ R = 0.9831 (Accuracy: 0.96, Mesh: 1.00)
- **2026-10-08 (Episode 10:44)**: Periodic gardening cycle (71 nodes, 575 edges) $\to$ R = 0.9831 (Accuracy: 0.96, Mesh: 1.00)
- **2026-10-08 (Episode 10:43)**: Periodic gardening cycle (71 nodes, 575 edges) $\to$ R = 0.9831 (Accuracy: 0.96, Mesh: 1.00)
- **2026-10-08 (Episode 10:43)**: Migrate 65 notes into 10_Wiki hierarchy $\to$ R = 0.9831 (Accuracy: 0.96, Mesh: 1.00)
- **2026-10-08 (Episode 10:43)**: Periodic gardening cycle (71 nodes, 575 edges) $\to$ R = 0.6169 (Accuracy: 0.04, Mesh: 1.00)
- **2026-10-07 (Episode 1)**: 구리/코발트 식각 난제와 sub-12nm 전자 평균자유행로 저항 역전 현상 요청 $\to$ 클러스터 2, 3으로 정확히 분기 매핑 ($R = +1.0$)
- **2026-10-07 (Episode 2)**: 반응성 스퍼터링과 타깃 피독의 비선형 상관관계 및 Berg 모델 요청 $\to$ PVD 플라즈마 클러스터 1로 통합 ($R = +1.0$)
- **2026-10-07 (Episode 3)**: PC1(4070Ti) 및 PC2(Dual 4090) 하드웨어별 시뮬레이션 확장성 요청 $\to$ 클러스터 6 멀티스케일 시뮬레이션 포트폴리오 7종 생성 및 매핑 ($R = +1.0$)
- **2026-10-08 (Episode 4)**: P-Reinforce Skill 아키텍처 호출 $\to$ 자율 정원사(Autonomous Gardener) 모드 활성화 및 `20_Meta/` 생성

---

## 🔗 지식 연결 (Graph)
- **Parent**: [[환영합니다!]]
- **Related**: [[반도체_나노열관리_마인드맵_총괄_지식지도]], [[반도체_나노열관리_전체_지식노트_주제별_연계_클러스터_총람 (Knowledge Concept Clusters)]]
- **Raw Source**: [[P-Reinforce_Skill]]

*Last updated: 2026-10-08*
