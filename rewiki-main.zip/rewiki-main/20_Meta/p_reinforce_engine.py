#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
P-Reinforce Engine: Autonomous Knowledge Gardener
Combines Andre Karpathy's LLM-Wiki Architecture with Reinforcement Learning (RL) Policy.
"""

import os
import re
import sys
import json
import uuid
import glob
import shutil
import argparse
import subprocess
from datetime import datetime
from pathlib import Path

# Ensure UTF-8 output on Windows console
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

# Paths relative to vault root
VAULT_ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = VAULT_ROOT / "00_Raw"
WIKI_DIR = VAULT_ROOT / "10_Wiki"
META_DIR = VAULT_ROOT / "20_Meta"
GRAPH_PATH = META_DIR / "Graph.json"
POLICY_PATH = META_DIR / "Policy.md"
INDEX_PATH = META_DIR / "Index.md"

# Cluster Definition & Categorization Taxonomy
CLUSTERS = {
    "Projects": {
        "folder": "10_Wiki/Projects",
        "keywords": ["마스터플랜", "계획서", "보고서", "Draft", "연구설계", "Summary", "Index", "Hub", "자산", "스웜데몬"]
    },
    "Decisions": {
        "folder": "10_Wiki/Decisions",
        "keywords": ["로드맵", "식각난제", "무식각", "주제선별", "사다리", "하드웨어_클러스터", "PC1_및_PC2", "의사결정"]
    },
    "Skills": {
        "folder": "10_Wiki/Skills",
        "keywords": ["Skill", "가이드", "프롬프트", "매뉴얼", "실행가이드", "워크플로우", "정원사"]
    },
    "Topics/01_PVD_Sputtering": {
        "folder": "10_Wiki/Topics/01_PVD_Sputtering",
        "keywords": ["스퍼터링", "피독", "타깃", "Berg", "PVD", "히스테리시스", "플라즈마"]
    },
    "Topics/02_Etch_Chemistry": {
        "folder": "10_Wiki/Topics/02_Etch_Chemistry",
        "keywords": ["구리_식각", "코발트_식각", "ALE", "비휘발성", "재증착", "카보닐", "식각"]
    },
    "Topics/03_Quantum_Phonon": {
        "folder": "10_Wiki/Topics/03_Quantum_Phonon",
        "keywords": ["평균자유행로", "저항_역전", "포논", "데바이", "마티센", "크누센", "BTE", "TBR", "카피차", "Wurtzite", "디퓨존", "AMM", "DMM"]
    },
    "Topics/04_Transport_Cooling": {
        "folder": "10_Wiki/Topics/04_Transport_Cooling",
        "keywords": ["전달현상", "무차원수", "나비에-스톡스", "미세유체", "마이크로채널", "상변화", "증기챔버", "비등", "물질전달", "확산", "열전", "펠티어", "푸리에", "열확산", "열저항"]
    },
    "Topics/05_Packaging_Bonding": {
        "folder": "10_Wiki/Topics/05_Packaging_Bonding",
        "keywords": ["패키징", "하이브리드", "하이브리드본딩", "본딩", "전기도금", "AAO", "직접 접합", "표면 활성화", "BSPDN", "자가발열", "열폭주", "3D 적층"]
    },
    "Topics/06_Multiscale_Sim": {
        "folder": "10_Wiki/Topics/06_Multiscale_Sim",
        "keywords": ["시뮬레이션", "DFT", "MD", "LAMMPS", "DeepMD", "ShengBTE", "OpenBTE", "FEM", "CFD", "Elmer", "OpenFOAM", "전산모사", "PIC-MCC"]
    },
    "Topics/07_DigitalTwin_AI": {
        "folder": "10_Wiki/Topics/07_DigitalTwin_AI",
        "keywords": ["디지털 트윈", "디지털트윈", "머신러닝", "ROM", "PINN", "DTPM", "RUL", "AI", "폐루프"]
    }
}

# Hyperparameters for RL Policy
RL_WEIGHTS = {
    "w1_categorization": 0.40,
    "w2_connectivity": 0.35,
    "w3_feedback": 0.25
}

def clean_wikilink(link_str):
    """Strip alias and brackets from wikilink: [[Target|Alias]] -> Target"""
    link = link_str.strip()
    if link.startswith("[[") and link.endswith("]]"):
        link = link[2:-2]
    if "|" in link:
        link = link.split("|")[0]
    return link.strip()

def find_all_markdown_notes():
    """Find all markdown notes in vault excluding .obsidian and .git"""
    notes = []
    for root, dirs, files in os.walk(VAULT_ROOT):
        # Skip hidden and cache folders
        dirs[:] = [d for d in dirs if not d.startswith(".") and d != "__pycache__"]
        for file in files:
            if file.endswith(".md"):
                notes.append(Path(root) / file)
    return notes

def parse_wikilinks(content):
    """Find all wikilinks [[...]] in content"""
    raw_links = re.findall(r'\[\[(.*?)\]\]', content)
    cleaned = []
    for rl in raw_links:
        t = clean_wikilink(rl)
        if t and not t.startswith("#") and not t.endswith((".png", ".jpg", ".jpeg", ".webp", ".svg")):
            cleaned.append(t)
    return list(dict.fromkeys(cleaned))

def build_knowledge_graph():
    """Scan all markdown files and build Graph.json with connectivity metrics"""
    notes = find_all_markdown_notes()
    node_map = {}
    note_names = {}
    
    for note_path in notes:
        stem = note_path.stem
        # Map both exact stem and normalized name
        note_names[stem] = note_path
        # Extract relative category path
        rel_parent = note_path.parent.relative_to(VAULT_ROOT)
        node_map[stem] = {
            "id": stem,
            "filename": note_path.name,
            "rel_path": str(note_path.relative_to(VAULT_ROOT)).replace("\\", "/"),
            "category": str(rel_parent).replace("\\", "/") if str(rel_parent) != "." else "Root",
            "size_bytes": note_path.stat().st_size,
            "out_links": [],
            "in_links": []
        }

    edges = []
    for stem, node_data in node_map.items():
        note_path = note_names[stem]
        try:
            content = note_path.read_text(encoding="utf-8")
        except Exception:
            continue
        
        links = parse_wikilinks(content)
        for target in links:
            # Handle potential filename alias or target resolution
            target_stem = Path(target).stem
            node_data["out_links"].append(target_stem)
            edges.append({
                "source": stem,
                "target": target_stem
            })

    # Compute in-degrees
    for edge in edges:
        tgt = edge["target"]
        if tgt in node_map:
            node_map[tgt]["in_links"].append(edge["source"])

    # Build node list with degree statistics
    nodes_list = []
    for stem, data in node_map.items():
        in_deg = len(set(data["in_links"]))
        out_deg = len(set(data["out_links"]))
        nodes_list.append({
            "id": stem,
            "label": stem,
            "category": data["category"],
            "path": data["rel_path"],
            "in_degree": in_deg,
            "out_degree": out_deg,
            "total_degree": in_deg + out_deg
        })

    # Sort nodes by total degree descending
    nodes_list.sort(key=lambda x: x["total_degree"], reverse=True)

    # Compute graph metrics
    num_nodes = len(nodes_list)
    num_edges = len(edges)
    orphans = [n["id"] for n in nodes_list if n["total_degree"] == 0]
    avg_deg = round((2.0 * num_edges / num_nodes), 2) if num_nodes > 0 else 0.0

    graph_data = {
        "metadata": {
            "engine": "P-Reinforce Autonomous Gardener v2.1",
            "last_generated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_nodes": num_nodes,
            "total_edges": num_edges,
            "average_degree": avg_deg,
            "orphan_nodes_count": len(orphans),
            "orphan_nodes": orphans
        },
        "nodes": nodes_list,
        "edges": edges
    }

    META_DIR.mkdir(parents=True, exist_ok=True)
    with open(GRAPH_PATH, "w", encoding="utf-8") as f:
        json.dump(graph_data, f, ensure_ascii=False, indent=2)

    return graph_data

def evaluate_reward(graph_data, user_feedback_score=1.0):
    """
    Evaluate RL reward R = w1*S_cat + w2*C_conn + w3*U_fb
    S_cat: categorization accuracy (ratio of categorized notes)
    C_conn: normalized graph connectivity density
    U_fb: user satisfaction score (-1.0 to 1.0)
    """
    nodes = graph_data["nodes"]
    num_nodes = len(nodes)
    if num_nodes == 0:
        return 0.0, {}

    # 1. Categorization accuracy S_cat
    categorized_count = sum(1 for n in nodes if n["category"] != "Root" or " 환영합니다!" in n["id"] or "README" in n["id"])
    s_cat = min(1.0, categorized_count / max(1, num_nodes))

    # 2. Graph connectivity C_conn (penalize orphans, reward balanced mesh)
    orphan_ratio = graph_data["metadata"]["orphan_nodes_count"] / num_nodes
    avg_deg = graph_data["metadata"]["average_degree"]
    # Target avg_degree is ~6.0 for rich semantic vault
    c_conn = max(0.0, min(1.0, (avg_deg / 6.0) * (1.0 - orphan_ratio)))

    # 3. User feedback
    u_fb = max(0.0, min(1.0, (user_feedback_score + 1.0) / 2.0))

    r_total = (
        RL_WEIGHTS["w1_categorization"] * s_cat +
        RL_WEIGHTS["w2_connectivity"] * c_conn +
        RL_WEIGHTS["w3_feedback"] * u_fb
    )

    metrics = {
        "r_total": round(r_total, 4),
        "s_cat": round(s_cat, 4),
        "c_conn": round(c_conn, 4),
        "u_fb": round(u_fb, 4),
        "avg_deg": avg_deg,
        "orphan_count": graph_data["metadata"]["orphan_nodes_count"],
        "num_nodes": num_nodes,
        "num_edges": graph_data["metadata"]["total_edges"]
    }
    return r_total, metrics

def check_folder_refactoring():
    """Check if any folder exceeds the 12 files threshold"""
    warnings = []
    for root, dirs, files in os.walk(VAULT_ROOT):
        # Exclude hidden, 00_Raw, 20_Meta
        if any(p in root for p in [".obsidian", ".git", "00_Raw", "20_Meta"]):
            continue
        md_files = [f for f in files if f.endswith(".md")]
        rel_path = Path(root).relative_to(VAULT_ROOT)
        if len(md_files) > 12:
            warnings.append({
                "folder": str(rel_path).replace("\\", "/"),
                "file_count": len(md_files),
                "threshold": 12,
                "action": "Sub-branching refactoring recommended"
            })
    return warnings

def git_commit(message):
    """Run git add . and git commit with message"""
    try:
        subprocess.run(["git", "add", "."], cwd=VAULT_ROOT, check=True, capture_output=True)
        res = subprocess.run(
            ["git", "commit", "-m", f"[P-Reinforce] {message}"],
            cwd=VAULT_ROOT,
            capture_output=True,
            text=True,
            encoding="utf-8"
        )
        return res.stdout or res.stderr
    except Exception as e:
        return f"Git commit notice: {e}"

def update_policy_log(reward, metrics, action_summary):
    """Update 20_Meta/Policy.md with new state vector and reward log"""
    if not POLICY_PATH.exists():
        return
    try:
        content = POLICY_PATH.read_text(encoding="utf-8")
        today = datetime.now().strftime("%Y-%m-%d")
        
        # Update state vector in Policy.md
        state_block = f'''```json
{{
  "total_knowledge_nodes": {metrics['num_nodes']},
  "total_graph_edges": {metrics['num_edges']},
  "mean_degree_connectivity": {metrics['avg_deg']},
  "isolated_orphan_nodes": {metrics['orphan_count']},
  "current_reward_score": {reward:.4f},
  "categorization_accuracy": {metrics['s_cat']:.4f},
  "graph_connectivity_score": {metrics['c_conn']:.4f},
  "clusters_identified": 7,
  "active_policy_version": "v2.2-Karpathy-RL"
}}
```'''
        content = re.sub(r'```json\s*\{[\s\S]*?\}\s*```', state_block, content)
        
        # Append to Reward Log
        new_log = f"- **{today} (Episode {datetime.now().strftime('%H:%M')})**: {action_summary} $\\to$ R = {reward:.4f} (Accuracy: {metrics['s_cat']:.2f}, Mesh: {metrics['c_conn']:.2f})\n"
        if "## 📝 4. 사용자 피드백 및 정책 갱신 이력 (Reward Log)" in content:
            parts = content.split("## 📝 4. 사용자 피드백 및 정책 갱신 이력 (Reward Log)")
            header = parts[0] + "## 📝 4. 사용자 피드백 및 정책 갱신 이력 (Reward Log)\n\n"
            rest = parts[1].lstrip()
            content = header + new_log + rest
        
        POLICY_PATH.write_text(content, encoding="utf-8")
    except Exception as e:
        print(f"Policy update notice: {e}")

def get_file_cluster_mapping():
    """Exact mapping of notes to 10_Wiki hierarchy"""
    mapping = {
        # Root Keepers
        "환영합니다!.md": "Root",
        "README.md": "Root",
        "반도체_나노열관리_마인드맵_총괄_지식지도.md": "Root",
        "반도체_나노열관리_전체_지식노트_주제별_연계_클러스터_총람 (Knowledge Concept Clusters).md": "Root",
        
        # Decisions
        "석박사_연구연계_로드맵_식각난제에서_무식각_CuAlN_하이브리드본딩까지.md": "10_Wiki/Decisions",
        "대학연구실규모_반도체열관리_연구주제선별_및_지식계층사다리.md": "10_Wiki/Decisions",
        "PC1_및_PC2_하드웨어_클러스터_시뮬레이션_배치_및_스웜_실행_로드맵.md": "10_Wiki/Decisions",

        # Skills
        "P-Reinforce_Skill.md": "10_Wiki/Skills",
        "2단계_PC1_스웜데몬_런치_및_실행가이드.md": "10_Wiki/Skills",
        "치타 사람 이미지 프롬프트.md": "10_Wiki/Skills",

        # Topics/01_PVD_Sputtering
        "반응성_스퍼터링과_타깃_피독_메커니즘_및_논문_총람 (Reactive Sputtering & Target Poisoning).md": "10_Wiki/Topics/01_PVD_Sputtering",
        "타깃_피독_물리화학_메커니즘_및_재료_영향_분석 (Target Poisoning Physics).md": "10_Wiki/Topics/01_PVD_Sputtering",
        "반응성_스퍼터링_공정제어_및_히스테리시스_극복_기술 (Reactive Sputtering Process Control).md": "10_Wiki/Topics/01_PVD_Sputtering",
        "스퍼터링 PVD 공정의 기본 원리와 플라즈마 (Sputtering & Plasma Basics).md": "10_Wiki/Topics/01_PVD_Sputtering",

        # Topics/02_Etch_Chemistry
        "구리_식각_연구_논문_및_화학반응_총람 (Cu Dry Etch & ALE Literature).md": "10_Wiki/Topics/02_Etch_Chemistry",
        "코발트_식각_연구_논문_및_카보닐화_메커니즘 (Co Dry Etch & Carbonyl Literature).md": "10_Wiki/Topics/02_Etch_Chemistry",
        "비휘발성 금속 식각과 재증착 제어 (Non-volatile Metal Etching & Redeposition).md": "10_Wiki/Topics/02_Etch_Chemistry",

        # Topics/03_Quantum_Phonon
        "전자_평균자유행로_미만_금속배선_저항_역전현상_분석 (Resistivity Crossover).md": "10_Wiki/Topics/03_Quantum_Phonon",
        "포논의 개념과 데바이 모델 (Phonon & Debye Model).md": "10_Wiki/Topics/03_Quantum_Phonon",
        "포논 산란 기작의 역사와 마티센 규칙 (Phonon Scattering Mechanisms).md": "10_Wiki/Topics/03_Quantum_Phonon",
        "크누센 수와 탄도 열수송 (Knudsen Number & Ballistic Transport).md": "10_Wiki/Topics/03_Quantum_Phonon",
        "포논 볼츠만 수송 방정식 (BTE).md": "10_Wiki/Topics/03_Quantum_Phonon",
        "계면 열경계 저항과 AMM DMM 역사 (History of TBR AMM DMM).md": "10_Wiki/Topics/03_Quantum_Phonon",
        "카피차 저항 및 계면 열전도도 (Kapitza Resistance & TBC).md": "10_Wiki/Topics/03_Quantum_Phonon",
        "Wurtzite AlN 결정성 및 포논 수송 메커니즘.md": "10_Wiki/Topics/03_Quantum_Phonon",
        "무정형 SiO2 디퓨존 이론 (Diffuson & Locon).md": "10_Wiki/Topics/03_Quantum_Phonon",

        # Topics/04_Transport_Cooling
        "반도체_열관리_3대_전달현상_물리개념_및_수식_총람.md": "10_Wiki/Topics/04_Transport_Cooling",
        "반도체 전달현상 핵심 무차원수 총람 (Dimensionless Numbers in Semiconductor Cooling).md": "10_Wiki/Topics/04_Transport_Cooling",
        "전달현상 지배방정식과 나비에-스톡스-에너지-연속 방정식 (Navier-Stokes & Energy Equation).md": "10_Wiki/Topics/04_Transport_Cooling",
        "미세유체역학 및 반도체 마이크로채널 냉각 (Microfluidics & On-Chip Microchannels).md": "10_Wiki/Topics/04_Transport_Cooling",
        "상변화 열전달과 증기챔버 및 비등 냉각 (Two-Phase Heat Transfer, Vapor Chamber & Boiling).md": "10_Wiki/Topics/04_Transport_Cooling",
        "계면 물질전달과 박막 증착 및 전기도금 확산 (Mass Transfer, Thin Film Deposition & Electroplating Diffusion).md": "10_Wiki/Topics/04_Transport_Cooling",
        "열전 효과와 칩스케일 능동 펠티어 냉각 (Thermoelectric Effect & On-Chip TEC Cooling).md": "10_Wiki/Topics/04_Transport_Cooling",
        "열전도도와 푸리에 법칙 기초 (Thermal Conductivity & Fourier Law).md": "10_Wiki/Topics/04_Transport_Cooling",
        "열확산 저항 (Spreading Resistance).md": "10_Wiki/Topics/04_Transport_Cooling",
        "전기-열 상사성과 열저항 회로 (Thermal Resistance Network).md": "10_Wiki/Topics/04_Transport_Cooling",

        # Topics/05_Packaging_Bonding
        "3D 적층 패키징의 진화_와이어본딩부터 하이브리드 본딩까지 (Packaging Evolution).md": "10_Wiki/Topics/05_Packaging_Bonding",
        "전기도금과 AAO 나노템플릿 공정 원리 (Electroplating & AAO Templates).md": "10_Wiki/Topics/05_Packaging_Bonding",
        "저온 직접 접합 및 플라즈마 표면 활성화.md": "10_Wiki/Topics/05_Packaging_Bonding",
        "반도체 직접 접합과 표면 활성화 연대기 (Direct Bonding History 1986-2026).md": "10_Wiki/Topics/05_Packaging_Bonding",
        "BSPDN 후면 전력공급망 열관리 아키텍처.md": "10_Wiki/Topics/05_Packaging_Bonding",
        "반도체 자가발열과 열폭주 메커니즘 (Self-Heating & Thermal Runaway).md": "10_Wiki/Topics/05_Packaging_Bonding",

        # Topics/06_Multiscale_Sim
        "반도체_열관리_및_공정_전체_시뮬레이션_포트폴리오_총람 (All Simulation Portfolio).md": "10_Wiki/Topics/06_Multiscale_Sim",
        "반도체_열관리_멀티스케일_시뮬레이션_및_디지털트윈_통합_총람.md": "10_Wiki/Topics/06_Multiscale_Sim",
        "멀티스케일 전산모사 기법 총람 (DFT, MD, BTE, FEM, CFD).md": "10_Wiki/Topics/06_Multiscale_Sim",
        "제1원리_DFT_전자구조_및_포논_시뮬레이션_가이드 (DFT & Phonon QE VASP).md": "10_Wiki/Topics/06_Multiscale_Sim",
        "분자동역학_MD_계면_TBR_및_머신러닝포텐셜_시뮬레이션 (LAMMPS & DeepMD).md": "10_Wiki/Topics/06_Multiscale_Sim",
        "포논_BTE_및_메조스케일_열수송_몬테카를로_시뮬레이션 (ShengBTE & OpenBTE).md": "10_Wiki/Topics/06_Multiscale_Sim",
        "연속체_3D_FEM_열응력_및_CFD_미세유체_시뮬레이션 (Elmer FEM & OpenFOAM).md": "10_Wiki/Topics/06_Multiscale_Sim",
        "플라즈마_화학_스퍼터링_PVD_및_식각_공정_시뮬레이션 (PIC-MCC, kMC & TCAD).md": "10_Wiki/Topics/06_Multiscale_Sim",

        # Topics/07_DigitalTwin_AI
        "반도체_공정_머신러닝_종류_적용방법_및_데이터규모별_학습이론_총람.md": "10_Wiki/Topics/07_DigitalTwin_AI",
        "반도체 열관리 디지털 트윈 5대 핵심 아키텍처 및 구현 기술.md": "10_Wiki/Topics/07_DigitalTwin_AI",
        "물리기반 차수축소모델(ROM)과 PINN 및 서스테인 AI 서베이.md": "10_Wiki/Topics/07_DigitalTwin_AI",
        "동적 전력-열 관리(DTPM)와 폐루프 제어 및 잔여수명(RUL) 예측.md": "10_Wiki/Topics/07_DigitalTwin_AI",

        # Projects
        "통합_연구_마스터플랜_멀티스케일_반도체_열관리.md": "10_Wiki/Projects",
        "Paper_Draft_v6_Final_Submission.md": "10_Wiki/Projects",
        "D드라이브_통합연구자산_마스터플랜_2026.md": "10_Wiki/Projects",
        "Reserach1_향후_연구개발_계획서.md": "10_Wiki/Projects",
        "3단계_신규테마_AlN_표면전달성_및_저온본딩_연구설계서.md": "10_Wiki/Projects",
        "1단계_Paper_Draft_v5_정밀점검_보고서.md": "10_Wiki/Projects",
        "00_AlN_Research_Hub_Master_Index.md": "10_Wiki/Projects",
        "01_Literature_Verification_Report.md": "10_Wiki/Projects",
        "02_ML_Model_Performance_Summary.md": "10_Wiki/Projects",
        "03_Simulation_Results_Analysis.md": "10_Wiki/Projects",
        "04_System_Integration_Strategy.md": "10_Wiki/Projects",
        "05_Data_Validation_Protocol.md": "10_Wiki/Projects",
        "06_Dataset_AlN_DC_Literature.md": "10_Wiki/Projects",
        "07_Simulation_Results_Thermal_Stack.md": "10_Wiki/Projects",
        "08_Final_Project_Summary.md": "10_Wiki/Projects",
        "09_AlN_Core_Research_Parameters_Index.md": "10_Wiki/Projects"
    }
    return mapping

def migrate_notes():
    """Migrate root markdown files into 10_Wiki standard hierarchy using git mv"""
    print("=" * 65)
    print("🚀 P-Reinforce Autonomous Vault Migration Activated")
    print("=" * 65)
    mapping = get_file_cluster_mapping()
    moved_count = 0

    for filename, target_dir_rel in mapping.items():
        if target_dir_rel == "Root":
            continue
        src_path = VAULT_ROOT / filename
        if not src_path.exists():
            continue
        
        target_dir = VAULT_ROOT / target_dir_rel
        target_dir.mkdir(parents=True, exist_ok=True)
        dst_path = target_dir / filename

        # Try git mv first, fallback to shutil.move
        res = subprocess.run(["git", "mv", str(src_path), str(dst_path)], cwd=VAULT_ROOT, capture_output=True)
        if res.returncode != 0:
            shutil.move(str(src_path), str(dst_path))
        moved_count += 1
        print(f"   ✓ Moved: {filename} -> {target_dir_rel}/")

    print(f"\n▶ Total {moved_count} notes successfully migrated into 10_Wiki hierarchy.")
    
    # Rebuild graph & update reward
    graph_data = build_knowledge_graph()
    r_val, m = evaluate_reward(graph_data, user_feedback_score=1.0)
    update_policy_log(r_val, m, f"Migrate {moved_count} notes into 10_Wiki hierarchy")
    
    # Git commit
    commit_out = git_commit(f"Migrate vault to 10_Wiki hierarchy ({moved_count} notes, R={r_val:.3f})")
    print(f"   ✓ Git Commit: {commit_out.strip() if commit_out else 'Committed.'}")
    print(f"   ★ New Reinforcement Reward R = {r_val:.4f} (Categorization: {m['s_cat']:.2f})")
    print("=" * 65)

def run_garden():
    """Main execution entrypoint for P-Reinforce Autonomous Gardener"""
    print("=" * 65)
    print("🌿 P-Reinforce Autonomous Gardener Engine Activated")
    print(f"   Vault Root: {VAULT_ROOT}")
    print("=" * 65)

    # 1. Build Knowledge Graph
    print("▶ 1. Parsing Knowledge Graph and Bidirectional Links...")
    graph_data = build_knowledge_graph()
    print(f"   ✓ Nodes: {graph_data['metadata']['total_nodes']}")
    print(f"   ✓ Edges: {graph_data['metadata']['total_edges']}")
    print(f"   ✓ Mean Degree: {graph_data['metadata']['average_degree']}")
    print(f"   ✓ Orphan Nodes: {graph_data['metadata']['orphan_nodes_count']}")

    # 2. Check Refactoring Thresholds
    print("\n▶ 2. Checking Category Volume & Refactoring Thresholds (Limit: 12)...")
    refactor_warnings = check_folder_refactoring()
    if refactor_warnings:
        for w in refactor_warnings:
            print(f"   ⚠️  Alert in '{w['folder']}': {w['file_count']} files (Exceeds limit {w['threshold']})")
    else:
        print("   ✓ All folders are within the 12-file optimal cognitive threshold.")

    # 3. Evaluate RL Reward Function
    print("\n▶ 3. Calculating Reinforcement Learning Reward...")
    r_val, m = evaluate_reward(graph_data, user_feedback_score=1.0)
    print(f"   ★ Total Reward R = {r_val:.4f}")
    print(f"     - Categorization Accuracy (w1=0.40): {m['s_cat']:.4f}")
    print(f"     - Graph Connectivity (w2=0.35):      {m['c_conn']:.4f}")
    print(f"     - User Feedback Score (w3=0.25):    {m['u_fb']:.4f}")

    # 4. Update Policy
    update_policy_log(r_val, m, f"Periodic gardening cycle ({m['num_nodes']} nodes, {m['num_edges']} edges)")

    # 5. Git Synchronize
    print("\n▶ 4. Running Git Sync Protocol...")
    summary = f"Update graph ({m['num_nodes']} nodes, {m['num_edges']} edges, R={r_val:.3f})"
    commit_out = git_commit(summary)
    print(f"   ✓ {commit_out.strip() if commit_out else 'Committed changes.'}")

    print("\n" + "=" * 65)
    print("🌱 P-Reinforce Gardening Cycle Completed Successfully.")
    print("=" * 65)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="P-Reinforce Autonomous Knowledge Gardener")
    parser.add_argument("--action", default="garden", choices=["garden", "graph", "reward", "commit", "migrate"], help="Gardener action")
    parser.add_argument("--feedback", type=float, default=1.0, help="User feedback score (-1.0 to 1.0)")
    args = parser.parse_args()

    if args.action == "garden":
        run_garden()
    elif args.action == "migrate":
        migrate_notes()
    elif args.action == "graph":
        g = build_knowledge_graph()
        print(f"Graph rebuilt: {g['metadata']['total_nodes']} nodes, {g['metadata']['total_edges']} edges.")
    elif args.action == "reward":
        g = build_knowledge_graph()
        r, m = evaluate_reward(g, args.feedback)
        print(f"Reward: {r:.4f}, Metrics: {m}")
    elif args.action == "commit":
        git_commit("Manual sync")

